#include "win2lin.h"
#include "debug_trace.h"

void InitializeCriticalSection(pthread_mutex_t* pm ){
  		//create mutex attribute variable
  		pthread_mutexattr_t mAttr;

      //init mutex attribute
  		pthread_mutexattr_init(&mAttr);

      // setup recursive mutex for mutex attribute
      pthread_mutexattr_settype(&mAttr,PTHREAD_MUTEX_NORMAL );//PTHREAD_MUTEX_RECURSIVE_NP // PTHREAD_MUTEX_NORMAL

      // Use the mutex attribute to create the mutex
      pthread_mutex_init(pm, &mAttr);

      // Mutex attribute can be destroy after initializing the mutex variable
      pthread_mutexattr_destroy(&mAttr);
}

int WaitForSem(sem_t* pSem, unsigned long ulMSDelay)
{
  struct timeval tv;
  if((gettimeofday(&tv, NULL)) == -1)
  {
  	// Handle error
  }
  struct timespec ts;
  ts.tv_sec = tv.tv_sec;
  ts.tv_nsec = tv.tv_usec * 1000;

 	uint32_t uiSec = ulMSDelay /1000;
 	long int  lNsec = ulMSDelay * 1000000 - uiSec * 1000000000;

 	ts.tv_sec += uiSec;
 	ts.tv_nsec += lNsec;

 	int ret = sem_timedwait(pSem, &ts);

  return ret;
}

int WaitForSingleObject(pthread_t thread, uint32_t uiMSTimeout)
{
	struct timeval tv;
	if((gettimeofday(&tv, NULL)) == -1)
	{
		// Handle error
	}
	struct timespec ts;
	ts.tv_sec = tv.tv_sec;
	ts.tv_nsec = tv.tv_usec * 1000;

	uint32_t uiSec = uiMSTimeout/1000;
	long int  lNsec = uiMSTimeout * 1000000 - uiSec * 1000000000;

	ts.tv_sec += uiSec;
	ts.tv_nsec += lNsec;
	//TRACE_PRINT2("sec: %d, nsec: %d",uiSec, lNsec);
	int ret = pthread_timedjoin_np(thread, NULL, &ts);
	//TRACE_PRINT1("pthread_timedjoin_np returned %d",ret);

	return ret;
}

bool TerminateThread(pthread_t thread, uint32_t rc)
{
	bool ret =  (bool)pthread_cancel(thread);
	return ret;
}

void DeleteCriticalSection(pthread_mutex_t* pm)
{
	pthread_mutex_destroy (pm);
}

void LeaveCriticalSection(pthread_mutex_t* pm)
{
	//TRACE_PRINT1("leaving CS: %d", pm);
	pthread_mutex_unlock (pm);
	//TRACE_PRINT("left CS");
}

int TryCriticalSection(pthread_mutex_t* pm)
{
//TRACE_PRINT1("leaving CS: %d", pm);
	return pthread_mutex_trylock(pm);
	//TRACE_PRINT("left CS");
}

void EnterCriticalSection(pthread_mutex_t* pm)
{
	//TRACE_PRINT1("entering CS: %d", pm);
	pthread_mutex_lock (pm);
	//TRACE_PRINT("entered CS");
}
