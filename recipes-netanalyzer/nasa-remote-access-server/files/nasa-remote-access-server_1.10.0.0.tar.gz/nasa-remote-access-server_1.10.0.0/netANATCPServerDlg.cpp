#include "win2lin.h"
#include "netANATCPServerDlg.h"

#include "SDK/netana_user.h"
#include "Marshaller/netANAAPI_Wrapper.h" // for netana_signal_driver_error

#include "Marshaller/MarshallerConfig.h"
//#include "Marshaller/MarshallerVersion.h"
#include "version.h"
#include "Marshaller/MarshallerInternal.h"

#include "TCPConnector.h"

#include "SDK/netana_errors.h"

#include "debug_trace.h"
#include <unistd.h>

#include <fcntl.h> 									// for file operations
#include <semaphore.h>

#include "trace_states.h"

//#include <deque>

/* global structur for dll information and function tabel declared in naANAAPI_Wrapper.h */
NETX_ANALYZER_DLL_INFO_T s_tAPIInfo = { 0 };

// global object of the server class
CnetANATCPServerDlg cnetANATCPServerDlg;


void OnTimerWrapper(int signum) {
  //TRACE_PRINT_TYPE(LOG_SIG,"wrapper Timer SIGNAL %d",signum);
	cnetANATCPServerDlg.OnTimer(signum);
}
void OnDestroyWrapper(int signum) {
  TRACE_PRINT_TYPE(LOG_SIG,"wrapper Destroy SIGNAL %d",signum);
  cnetANATCPServerDlg.OnDestroy(signum);

}


/* define static varibles */
void* CnetANATCPServerDlg::m_pvMarshaller = NULL;
sem_t CnetANATCPServerDlg::m_sem = {{0}};


/*****************************************************************************/
/*! Marshaller Timer                                                         */
/*****************************************************************************/
void CnetANATCPServerDlg::OnTimer(int signum) {
	HilMarshallerTimer(CnetANATCPServerDlg::m_pvMarshaller);
}

/////////////////////////////////////////////////////////////////////////////////////////
/// LoadNetANAAPIDLL
///   \param ps_tConnectorInfo Connector Information structure
///   \return true on success
/////////////////////////////////////////////////////////////////////////////////////////
bool CnetANATCPServerDlg::LoadNetANAAPIDLL(
		NETX_ANALYZER_DLL_INFO_T* ptConnectorInfo) {
	bool fRet = true;

	/* Read the netX API driver functions from the driver DLL */
	PDRIVER_FUNCTIONS pfnFnc = &ptConnectorInfo->tFncTable;

	/* reset error value */
	ptConnectorInfo->szError = NETANA_NO_ERROR;

	pfnFnc->pfn_netana_open_device 						= (PFN_netana_open_device) netana_open_device;
	pfnFnc->pfn_netana_close_device 					= (PFN_netana_close_device) netana_close_device;
	pfnFnc->pfn_netana_driver_information 		=	(PFN_netana_driver_information) netana_driver_information;
	pfnFnc->pfn_netana_device_info 						= (PFN_netana_device_info) netana_device_info;
	pfnFnc->pfn_netana_get_error_description 	= (PFN_netana_get_error_description) netana_get_error_description;
	pfnFnc->pfn_netana_enum_device 						= (PFN_netana_enum_device) netana_enum_device;
	pfnFnc->pfn_netana_mngmt_exec_cmd 				= (PFN_netana_mngmt_exec_cmd) netana_mngmt_exec_cmd;
	//pfnFnc->pfn_netana_file_info							= (PFN_NETANA_FILE_INFO) netana_file_info;
	pfnFnc->pfn_netana_get_filter 						= (PFN_netana_get_filter) netana_get_filter;
	pfnFnc->pfn_netana_set_filter 						= (PFN_netana_set_filter) netana_set_filter;
	pfnFnc->pfn_netana_get_gpio_mode 					=	(PFN_netana_get_gpio_mode) netana_get_gpio_mode;
	pfnFnc->pfn_netana_set_gpio_mode 					=	(PFN_netana_set_gpio_mode) netana_set_gpio_mode;
	pfnFnc->pfn_netana_get_portstat 					= (PFN_netana_get_portstat) netana_get_portstat;
	pfnFnc->pfn_netana_get_state 							= (PFN_netana_get_state) netana_get_state;
	pfnFnc->pfn_netana_access_phy_reg 				=	(PFN_netana_access_phy_reg) netana_access_phy_reg;
	//pfnFnc->pfn_netana_set_filelist   				= (PFN_NETANA_SET_FILE_LIST) netana_set_filelist;
	pfnFnc->pfn_netana_start_capture 					= (PFN_netana_start_capture) netana_start_capture;
	pfnFnc->pfn_netana_stop_capture 					= (PFN_netana_stop_capture) netana_stop_capture;
	pfnFnc->pfn_netana_resync_time 						= (PFN_netana_resync_time) netana_resync_time;
	pfnFnc->pfn_netana_set_gpio_output 				=	(PFN_netana_set_gpio_output) netana_set_gpio_output;
	pfnFnc->pfn_netana_config_pi_controller 	=	(PFN_netana_config_pi_controller) netana_config_pi_controller;
	pfnFnc->pfn_netana_set_device_ident  			= (PFN_netana_set_device_ident) netana_set_device_ident;
	pfnFnc->pfn_netana_check_device_ident     = (PFN_netana_check_device_ident) netana_check_device_ident;
	pfnFnc->pfn_netana_get_device_ident       = (PFN_netana_get_device_ident) netana_get_device_ident;
	pfnFnc->pfn_netana_set_gpio_voltage       = (PFN_netana_set_gpio_voltage) netana_set_gpio_voltage;
	pfnFnc->pfn_netana_get_gpio_voltage       = (PFN_netana_get_gpio_voltage) netana_get_gpio_voltage;
	pfnFnc->pfn_netana_signal_driver_error    = (PFN_netana_signal_driver_error) netana_signal_drv_error;
  pfnFnc->pfn_netana_get_packet             = (PFN_netana_get_packet) netana_get_packet;
  pfnFnc->pfn_netana_put_packet             = (PFN_netana_put_packet) netana_put_packet;
  pfnFnc->pfn_netana_get_mbx_state          = (PFN_netana_get_mbx_state) netana_get_mbx_state;
	return fRet;
}

/*****************************************************************************/
/*! Request Thread                                                         */
/*****************************************************************************/
bool CnetANATCPServerDlg::RequestThread(void* pvUser)
{
	CnetANATCPServerDlg* pcDlg = reinterpret_cast<CnetANATCPServerDlg*>(pvUser);
	HIL_MARSHALLER_DATA_T*  ptMarshaller = (HIL_MARSHALLER_DATA_T*)pcDlg->m_pvMarshaller;

	while(pcDlg->m_fRequestThreadRunning)
	{
		sem_wait(&m_sem);//wait<-event
		//lock-cs
		while(!STAILQ_EMPTY(&(ptMarshaller->tPendingRequests)))
		{
			HilMarshallerMain(m_pvMarshaller);
			//OnMarshallerRequest(m_pvMarshaller);
		}
	}
	return true;
}

/*****************************************************************************/
/*! Initialization the Marshallar                                         */
/*****************************************************************************/
uint32_t CnetANATCPServerDlg::InitMarshaller() {
	HIL_MARSHALLER_PARAMS_T tParams = {{0}};
	HIL_MARSHALLER_CONNECTOR_PARAMS_T tTCPConnector = {0};
	uint32_t eRet = RESULT_OK;

	tTCPConnector.pfnConnectorInit = TCPConnectorInit;
	//tTCPConnector.pfnConnectorShutdown = TCPConnectorShutdown;
	tTCPConnector.pvConfigData = NULL;
	tTCPConnector.ulDataBufferCnt = 5;
  tTCPConnector.ulDataBufferSize = 10000;
	tTCPConnector.ulTxBufferCnt = 5; //for Callback sending data
	tTCPConnector.ulTxBufferSize = 600000; //sendbuffer to take full datacallback buffer of netana card
	tTCPConnector.ulTimeout = 1000;

	TRANSPORT_LAYER_CONFIG_T tnetANATransport = {0};
	netANA_TRANSPORT_CONFIG tnetANAConfig = {{0}};

	/* load library dynamically */
	if (LoadNetANAAPIDLL(&s_tAPIInfo))
		tnetANAConfig.tDRVFunctions = s_tAPIInfo.tFncTable;
	else
		return (uint32_t) NETANA_CONNECTOR_FUNCTIONS_READ_ERROR;

	tnetANATransport.pfnInit = netANATransportInit;
	tnetANATransport.pvConfig = &tnetANAConfig;

  tParams.ulMaxConnectors = 5;                      /* maximum incomming connections */
	tParams.atTransports = &tnetANATransport;
	tParams.ulTransportCnt = 1;

	tParams.ptConnectors = &tTCPConnector;
	tParams.ulConnectorCnt = 1;

	sem_init(&m_sem, 0, 0); 		// semaphore_name, share_with_processes, initial_value

	//if (RESULT_OK
	//		== (eRet = HilMarshallerStart(&tParams, &m_pvMarshaller,
	//				MarshallerRequestWrapper, this))) {
	if (RESULT_OK == (eRet = HilMarshallerStart(&tParams, &m_pvMarshaller, MarshallerRequestWrapper, this)))
	{
		m_fRequestThreadRunning = true;
		if(RESULT_OK == (eRet = pthread_create( &(m_hRequesThread), NULL, (PFN_PTHREAD)CnetANATCPServerDlg::RequestThread, this)))
		{



      //register OnDestroy as ceanup
      signal(SIGINT, OnDestroyWrapper);

      struct itimerval newvalueCycl;
      newvalueCycl.it_interval.tv_sec = 0;
      newvalueCycl.it_interval.tv_usec = 10 * 1000;
      newvalueCycl.it_value.tv_sec = 0;
      newvalueCycl.it_value.tv_usec = 10 * 1000;

      /* Create timer event to periodically call marshaller timer */
      //SetTimer(IDT_CYCLIC, 10, NULL);

      signal(SIGALRM, OnTimerWrapper);
      setitimer(ITIMER_REAL, &newvalueCycl, NULL);

		}

	}

	return eRet;
}

/*****************************************************************************/
/*! Destroy the Marshaller                                                   */
/*****************************************************************************/
void CnetANATCPServerDlg::DeinitMarshaller() {
  TRACE_PRINT("DeinitMarshaller");
	sem_destroy(&m_sem);

	if(0 != m_hRequesThread)
	{
		m_fRequestThreadRunning = false;
		if(RESULT_OK != WaitForSingleObject(m_hRequesThread, 2000))
			TerminateThread(m_hRequesThread, MAXDWORD);
	}
	this->m_hRequesThread = 0;

	if (NULL != m_pvMarshaller)
		HilMarshallerStop(m_pvMarshaller);

}

/*****************************************************************************/
/*! This function is called in response to the WM_INITDIALOG message.        */
/*****************************************************************************/
bool CnetANATCPServerDlg::OnInitDialog() {

	uint32_t	eRet = InitMarshaller();

	if (RESULT_OK != eRet) {
		char szErrorText[MAX_PATH] = {0};
		if (s_tAPIInfo.tFncTable.pfn_netana_get_error_description != 0)
		{
			if (NETANA_NO_ERROR == s_tAPIInfo.tFncTable.pfn_netana_get_error_description(eRet, sizeof(szErrorText), szErrorText))
			{

			} else
			{
				strcpy(szErrorText, "<no error description available>");
			}
			//char szErrorMSG[256]
			fprintf(stderr, "Marshaller Startup Error!\n\n%s \n(eRet = 0x%08X",
					szErrorText,
					eRet);
		} else {
			// no api functions found
			fprintf(stderr, "Could not load natANALYZER_API");
		}
	}
	return true;// return TRUE  unless you set the focus to a control
}


/*****************************************************************************/
/*! Marshaller Request Wrapper                                               */
/*****************************************************************************/
void CnetANATCPServerDlg::MarshallerRequestWrapper(void* /*pvMarshaller*/,void* pvUser) {
	//CnetANATCPServerDlg* pcDlg = reinterpret_cast<CnetANATCPServerDlg*>(pvUser);

	sem_post(&(CnetANATCPServerDlg::m_sem));
	/* empty parameters */
	//unsigned int tempa;
	//long int tampb;
	//pcDlg->OnMarshallerRequest(&tempa, &tampb);
  //TRACE_ENTER("MarshallerRequestWrapper");
	/*
	if(0 != pcDlg->m_hRequesThread)
	{
		if(RESULT_OK != WaitForSingleObject(pcDlg->m_hRequesThread, 20000))
		{
			TRACE_PRINT("WaitForSingleObject Terminetingd");
			TerminateThread(pcDlg->m_hRequesThread, MAXDWORD);
			TRACE_PRINT("WaitForSingleObject Termineated");
		}
	}
	//pcDlg->m_hRequesThread = NULL;
	TRACE_PRINT("WaitForSingleObject m_hRequesThread");

	//start a new thread for requests so that the connection mechanism is not blocked
	//pthread_create(&(pcDlg->m_hRequesThread), NULL, (PFN_PTHREAD)CnetANATCPServerDlg::OnMarshallerRequest, pcDlg->m_pvMarshaller);

	TRACE_EXIT("MarshallerRequestWrapper");*/
	//CnetANATCPServerDlg::OnMarshallerRequest( pcDlg->m_pvMarshaller);
}


/*****************************************************************************/
/*! Marshaller Requests                                                      */
/*****************************************************************************/
bool CnetANATCPServerDlg::OnMarshallerRequest(void* m_pvMarshaller /*unsigned int* wParam,	long* lParam*/) {
	HilMarshallerMain(m_pvMarshaller);
	//pthread_exit(NULL);
	return true;
}

/*****************************************************************************/
/*! This function is called to inform the TCP server dialog object that 
 *   it is being destroyed.                                                   */
/*****************************************************************************/
void CnetANATCPServerDlg::OnDestroy(int signum) {
	TRACE_PRINT("CnetANATCPServerDlg::OnDestroy");
	DeinitMarshaller();
	TRACE_PRINT("Good bye...");
  printf("Good bye...\n");
#ifdef _DEBUG_TO_FILE
	CloseLogfile();
#endif
}

FILE* g_LogFileHandle;

int main(void){

	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

/* show debug flags in welcome string */
#ifdef DEBUG
#define BUILD_DEBUG_INFO "Debug "
#else
#define BUILD_DEBUG_INFO
#endif
#ifdef TARGET_IOTGW
#define BUILD_TARGET_INFO "IOT-Gateway "
#else
#define BUILD_TARGET_INFO
#endif

  printf("\nnetANATCPServer Version %d.%d.%d.%d " BUILD_TARGET_INFO BUILD_DEBUG_INFO "\n\n",
         VERSION_MAJOR,
         VERSION_MINOR,
         VERSION_BUILD,
         VERSION_REVISION);

#ifdef _DEBUG_TO_FILE
  printf("loggin to file ./netANATCPServer_log.txt\n");
  char filepath[] = "./netANATCPServer_log.txt";
  OpenLogfile(filepath);
#endif

  TRACE_PRINT("Starting!");


	/*struct timeval tv1;
	gettimeofday(&tv1, NULL);
	set_next_sample(&tCallbackHistory, tv1, 0x00000001, &tPortstatHistory);
	set_next_sample(&tCallbackHistory, tv1, 0x00000021, &tPortstatHistory);
	write_history_to_file( "CallbackTrace.csv",  &tCallbackHistory);
	while (1);*/

	//int fildes2 = open("/mnt/netANATCPServer_error.txt",O_RDWR | O_CREAT | O_SYNC, S_IRUSR | S_IRGRP | S_IROTH);
  //dup2(fildes2,2);

	CnetANATCPServerDlg* pcnetANATCPServerDlg;

	/*
	 * the class as pointer makes the OnTimer function incompatible
	 * as a parameter for the signalhandler
	 */
	//pcnetANATCPServerDlg = new CnetANATCPServerDlg();

	pcnetANATCPServerDlg = &cnetANATCPServerDlg;
	pcnetANATCPServerDlg->OnInitDialog();

	while (1)
	{
		sleep(1);
	}
	//pcnetANATCPServerDlg->OnDestroy;

	return 0;
}


