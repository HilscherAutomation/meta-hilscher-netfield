
#ifndef __TRACE_STATES__H
#define __TRACE_STATES__H

#include <stdlib.h>
#include <time.h>

#define HISTORY_DEEPTH 10000

typedef struct TRACE_SAMPLE_Ttag
{
	struct timeval 	tv;
	uint32_t 				ulIdentifier;
	uint32_t				ulOpposingTraceNextIdx;
}TRACE_SAMPLE_T, *PTRACE_SAMPLE;

typedef struct TRACE_Ttag
{
	TRACE_SAMPLE_T  aHistory[HISTORY_DEEPTH];
	uint32_t 			  ulNextIdx;
} TRACE_T, *PTRACE_T;

TRACE_T tPortstatHistory;
TRACE_T tCallbackHistory;

void set_next_sample(PTRACE_T ptHistory, struct timeval tv, uint32_t ulIdentifie, PTRACE_T ptRefHistory)
{
	/* write the kurrent sample to the history  */
	uint32_t ulNextIdx =ptHistory->ulNextIdx;
	ptHistory->aHistory[ulNextIdx].tv	= tv;
	ptHistory->aHistory[ulNextIdx].ulIdentifier = ulIdentifie;
	ptHistory->aHistory[ulNextIdx].ulOpposingTraceNextIdx = ptRefHistory->ulNextIdx;

	/* increment index */
	ulNextIdx++;
	if (ulNextIdx >= HISTORY_DEEPTH)
	{
		ulNextIdx = ulNextIdx - HISTORY_DEEPTH;
	}
	// save new index with history
	ptHistory->ulNextIdx = ulNextIdx;
}

void write_history_to_file(char* szPathAndName, PTRACE_T ptHistory)
{
	uint32_t ulSampleIdx = 0;
	FILE* TraceFileHandle = fopen(szPathAndName, "w+");
	fprintf(TraceFileHandle, "IDX; TIME_S,TIME_US; IDENTIFIER; OPPOSINGIDX;\n");
	for(ulSampleIdx = 0; ulSampleIdx < HISTORY_DEEPTH; ulSampleIdx++)
	{
													// "IDX; TIME; IDENTIFIER; OPPOSINGIDX;\n"
		fprintf(TraceFileHandle, "%d; %d,%06d; %X; %d;\n",
														  ulSampleIdx,
                              (int)ptHistory->aHistory[ulSampleIdx].tv.tv_sec,
                              (int)ptHistory->aHistory[ulSampleIdx].tv.tv_usec,
														  ptHistory->aHistory[ulSampleIdx].ulIdentifier,
														  ptHistory->aHistory[ulSampleIdx].ulOpposingTraceNextIdx);
	}
	fclose(TraceFileHandle);
}



























#endif // __TRACE_STATES__H
