#include "win2lin.h"
//#include "Marshaller/MarshallerInternal.h"
#include "TCPConnector.h"
#include "debug_trace.h"

#define SEND_BUFF_LEN_OPTIMUM 131071

//400 ms timeout to workaround the stopcapture timeout problem with diverging states (driver / firmware) TODO: put this next to the rx timout
#define SEND_TIMOUT_MS 400

typedef struct TCP_CONN_LIST_Ttag
{
  CRITICAL_SECTION     tcsConnListLock;                            /* Locks the list against simultainious access */
  uint32_t             ulEntries;                                  /* number of elements in the following list */
  LIST_HEAD(TCP_CONN_LIST, TCP_CONN_INTERNAL_Ttag) tTCPConnList;   /* list of known and active connections */
}TCP_CONN_LIST_T;

TCP_CONN_LIST_T g_tTCPConnList;                              /* instance of list of the known connections */

CRITICAL_SECTION             tcsSendData;
CRITICAL_SECTION            tcsRecvData;

/*****************************************************************************/
/*! Function called from marshaller when data is to be sent to interface
*   \param ptBuffer   Buffer to send
*   \param pvUser     TCP connector internal data                            */
/*****************************************************************************/
static uint32_t TCPConnectorSend(HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser)
{
  TCP_CONN_INTERNAL_T* ptTcpData = (TCP_CONN_INTERNAL_T*)pvUser;
  unsigned long        ulDataLen = sizeof(ptBuffer->tTransport) + 
                                   ptBuffer->tMgmt.ulUsedDataBufferLen;
  int iRet = 0;
  uint32_t ulRet = RESULT_OK; // RESULT_ERROR

  TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorSend entering tcsSendData");
  EnterCriticalSection(&tcsSendData);
  TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorSend entered tcsSendData");
  if (ptTcpData->hClient ==-1)
  {
    //perror("skip sendig because we dont have a socket\n");
    TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS|LOG_ERR,"sip sendig because we dont have a socket");
    ulRet = RESULT_ERROR;
  }
  else
  {

    // TRACE_PRINT1("sequence %d", ptBuffer->tTransport.bSequenceNr);
    // TRACE_PRINT("entering send CS TCPConnectorSend");

    // TRACE_PRINT("entered send CS TCPConnectorSend");

    TRACE_PRINT_TYPE(LOG_COM,"start sending on sock %d",ptTcpData->hClient);
    iRet = send(ptTcpData->hClient,
                  (char*)&ptBuffer->tTransport,
                  ulDataLen,
                  MSG_NOSIGNAL);

    if (iRet == -1)
    {
      perror("something unexpected happend in send");
      TRACE_PRINT("something unexpected happend in send");
      ulRet = RESULT_ERROR;
    }
    else if((unsigned long)iRet != ulDataLen)
    {
      fprintf(stderr,"send length missmatch: %d vs. %d\n", (unsigned int)ulDataLen, iRet);
      TRACE_PRINT2("send length missmatch: %d vs. %d", (unsigned int)ulDataLen, iRet);
      ulRet = RESULT_ERROR;
    }
  }


  TRACE_PRINT_TYPE(LOG_COM|LOG_BUFF,"freebuffer after Send %p", (void*)ptBuffer);
  HilMarshallerConnTxComplete(ptBuffer->tMgmt.pvMarshaller,
                              ptTcpData->ulConnectorIdx, 
                              ptBuffer);
  TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorSend leaving tcsSendData");
  LeaveCriticalSection(&tcsSendData);

  return ulRet; // RESULT_OK;
}

/*****************************************************************************/
/*! Function called from marshaller when data is to be sent to interface
 *  like TCPConnectorSend but with additional parameter to specify a pointer for a direct read buffer
*   \param ptBuffer   Buffer to send
*   \param pvUser     TCP connector internal data                            */
/*****************************************************************************/
static uint32_t TCPConnectorSendData(HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvBuffer,unsigned long ulLength, void* pvUser)
{
  TCP_CONN_INTERNAL_T* ptTcpData = (TCP_CONN_INTERNAL_T*)pvUser;
  int iRet = 0;
  uint32_t ulRet = RESULT_OK;

  unsigned long        ulDataLen;


  ulDataLen = sizeof(ptBuffer->tTransport) + ptBuffer->tMgmt.ulUsedDataBufferLen;
  TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorSendData entering tcsSendData");
  EnterCriticalSection(&tcsSendData);
  TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorSendData entered tcsSendData");
  if (ptTcpData->hClient ==-1)
  {
    TRACE_PRINT("skip sendig because we lost the socket");
    ulRet = RESULT_ERROR;
  }else
  {
    TRACE_PRINT_TYPE(LOG_COM, "start sending on sock %d SendData",ptTcpData->hClient);
    iRet = send(ptTcpData->hClient,
         (char*)&ptBuffer->tTransport,
         ulDataLen,
         MSG_NOSIGNAL);

    if (iRet == -1)
    {
      //perror("something unexpected happend in sendData");
      TRACE_PRINT("something unexpected happend in sendData");
      ulRet = RESULT_ERROR;
    }
    else if((unsigned long)iRet != ulDataLen)
    {
      //fprintf(stderr,"header send length missmatch: %d vs. %d\n", (unsigned int)ulDataLen, (int)iRet);
      TRACE_PRINT2("header send length missmatch: %d vs. %d", (unsigned int)ulDataLen, iRet);
      ulRet = RESULT_ERROR;
    }
    else
    {    //send the data
      TRACE_PRINT_TYPE(LOG_COM,"start sending data on sock %d SendData",ptTcpData->hClient);
      iRet = send(ptTcpData->hClient,
                    (char*)pvBuffer,
                    ulLength,
                    MSG_NOSIGNAL);

      if (iRet == -1)
      {
        perror("something unexpected happend in sendData buffer");
        TRACE_PRINT("something unexpected happend in sendData buffer");
        ulRet = RESULT_ERROR;
      }
      else if((unsigned long)iRet != ulLength)
      {
        fprintf(stderr,"data send length missmatch: %d vs. %d\n", (unsigned int)ulLength, iRet);
        TRACE_PRINT2("data send length missmatch: %d vs. %d", (unsigned int)ulLength, iRet);
        ulRet = RESULT_ERROR;
      }
    }
  }

  //clear tx bufferr
  TRACE_PRINT_TYPE(LOG_COM|LOG_BUFF,"freebuffer after dadacallback %p",(void*)ptBuffer);
  HilMarshallerConnTxComplete(ptBuffer->tMgmt.pvMarshaller, 
                              ptTcpData->ulConnectorIdx, 
                              ptBuffer);
  TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorSendData leave tcsSendData");
  LeaveCriticalSection(&tcsSendData);

  return ulRet;
}

/*****************************************************************************/
/*! Cleans up the tcp Data from list an unregisters any attached connections
  \param ptTCPData Pointer to internal TCP data                              */
/*****************************************************************************/
void CleanupClientThreadData(TCP_CONN_INTERNAL_T* ptTCPData)
{
  /* Clenaup Data */
  TRACE_ENTER_TYPE(LOG_COM,"CleanupClientThreadData");
  EnterCriticalSection(&g_tTCPConnList.tcsConnListLock);
  if (g_tTCPConnList.ulEntries != 0)
  {
    /* cleanup connection Data */
    if (ptTCPData->ulConnectorIdx != (uint32_t)~0)
    {
      TRACE_PRINT_TYPE(LOG_COM,"HilMarshallerUnregisterConnector %d", ptTCPData->ulConnectorIdx);
      HilMarshallerUnregisterConnector(ptTCPData->pvMarshaller,ptTCPData->ulConnectorIdx);
      ptTCPData->ulConnectorIdx = (uint32_t)~0;
    }

    /* Remove this Tcp Data from list */
    TRACE_PRINT_TYPE(LOG_COM,"LIST_REMOVE TCP_Data %p", (void*)ptTCPData);
    LIST_REMOVE(ptTCPData,tList);
    g_tTCPConnList.ulEntries--;
    OS_FREE(ptTCPData);
    ptTCPData = NULL;
  }
  LeaveCriticalSection(&g_tTCPConnList.tcsConnListLock);
  TRACE_EXIT_TYPE(LOG_COM,"CleanupClientThreadData");
}

/*****************************************************************************/
/*! TCP connector uninitialization
*   \param pvUser Pointer to internal connector data                         */
/*****************************************************************************/

static void TCPConnectorDeinit(void* pvUser)
{
  static bool fDeinitActive = false;
  TCP_CONN_INTERNAL_T* ptTcpData = (TCP_CONN_INTERNAL_T*)pvUser;
  TRACE_PRINT("TCPConnectorDeinit");

  if (!fDeinitActive)
  {
    fDeinitActive = true;
    TRACE_PRINT("TCPConnectorDeinit ACTIVE\n");
    /* Check if data is valid */
    if(NULL != ptTcpData)
    {
      HANDLE hClientThread = ptTcpData->hClientThread;
      ptTcpData->fClientRunning  = 0;
      ptTcpData->fRunning = 0;

      //deinitLog();

      if(0 != hClientThread)
      {
        if(RESULT_OK != WaitForSingleObject(hClientThread, 2000))
          TerminateThread(hClientThread, MAXDWORD);

        //CloseHandle(hClientThread);
      }

      if(INVALID_SOCKET != ptTcpData->hClient)
      {
        TRACE_PRINT("entering cs send data");
        EnterCriticalSection(&tcsSendData);
        TRACE_PRINT("entered cs send data");

        close(ptTcpData->hClient);

        ptTcpData->hClient = INVALID_SOCKET;
        TRACE_PRINT("leaving cs send data");
        LeaveCriticalSection(&tcsSendData);
      }

      if(0 != ptTcpData->hServerThread)
      {
        if(RESULT_OK != WaitForSingleObject(ptTcpData->hServerThread, 2000))
          TerminateThread(ptTcpData->hServerThread, MAXDWORD);

        //CloseHandle(ptTcpData->hServerThread);
      }

      if(INVALID_SOCKET != ptTcpData->hListen)
        close(ptTcpData->hListen);

      //CleanupClientThreadData(ptTcpData);
    }
    DeleteCriticalSection(&tcsSendData);

  } // if !DeinitActive
}


/*****************************************************************************/
/*! Thread handling connection with client
*   \param pvParam Pointer reference to TCP connection structure
*   \return        Always 0                                                  */
/*****************************************************************************/
static void ClientThread(void* pvParam)
{
  TCP_CONN_INTERNAL_T* ptTcpData = (TCP_CONN_INTERNAL_T*)pvParam;
  HIL_MARSHALLER_DATA_T* ptMarshaller = NULL;
  int hClient = INVALID_SOCKET;
  ptMarshaller = (HIL_MARSHALLER_DATA_T*)ptTcpData->pvMarshaller;
  printf("entered ClientThread ID: 0x%X   ConnIdx: %d   Socket: %d   Running=%d\n", (unsigned int)pthread_self(), ptTcpData->ulConnectorIdx, ptTcpData->hClient, ptTcpData->fClientRunning );
  while(ptTcpData->fClientRunning)
  {
    fd_set  tRead, tExcept;
    timeval tTimeout = {0};

#ifdef _NO_KEEP_ALIVE
    tTimeout.tv_sec = 12000;   //allows debuging of host and server independantly
#else
    tTimeout.tv_sec = 5;
#endif

    FD_ZERO(&tRead);
    FD_ZERO(&tExcept);

    /* get filedescriptor savely */
    TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread entering tcsSendData");
    EnterCriticalSection(&tcsSendData);
    TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread entered tcsSendData");
    hClient = ptTcpData->hClient;
    TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread leaving tcsSendData");
    LeaveCriticalSection(&tcsSendData);

    if (hClient == INVALID_SOCKET)
    {
      TRACE_PRINT_TYPE(LOG_COM,"invalid socket in client thread before select");
      break;
    }

    FD_SET(hClient, &tRead);
    FD_SET(hClient, &tExcept);

    int iErr = select(hClient + 1, &tRead, NULL, &tExcept, &tTimeout);
    TRACE_PRINT_TYPE(LOG_COM,"select returned %d", iErr);
    if(0 < iErr)
    {

      // TRACE_PRINT("select returned > 0");
      if(FD_ISSET(hClient, &tRead))
      {
        /* We have data to read */
        unsigned long  ulDataLen = 0;
        unsigned char* pbData;
        int            iRecv;

        TRACE_PRINT_TYPE(LOG_COM,"before ioctrl");
        ioctl(hClient, FIONREAD, &ulDataLen);
        TRACE_PRINT_TYPE(LOG_COM, "after ioctrl %d", ulDataLen);

        pbData    = (unsigned char*)OS_MALLOC(ulDataLen);
        if(pbData == NULL)
        {
            TRACE_PRINT_TYPE(LOG_COM|LOG_ERR,"no pbData alloc");
        }

        // TRACE_PRINT("entering recv");
        iRecv = recv(hClient, (char*)pbData, ulDataLen, 0);
        TRACE_PRINT_TYPE(LOG_COM, "recv returned %d", iRecv);

        if( (SOCKET_ERROR == iRecv) ||
            (0            == iRecv) )
        {
          /* Gracefully closed int */
          //iRecv = close(ptTcpData->hClient);
          TRACE_PRINT_TYPE(LOG_COM,"closing conectionIdx %d Socket: %d", ptTcpData->ulConnectorIdx, hClient);
          if (iRecv == SOCKET_ERROR)
            TRACE_PRINT_TYPE(LOG_ERR,"Error: %s", strerror(errno));
          TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread closing conection entering tcsSendData");
          EnterCriticalSection(&tcsSendData);
          TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread closing conection entered tcsSendData");
          close(hClient);
          ptTcpData->hClient = INVALID_SOCKET;
          hClient = INVALID_SOCKET;
          OS_FREE(pbData);
          pbData = NULL;
          TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread closing conection leaving tcsSendData");
          LeaveCriticalSection(&tcsSendData);
          // TRACE_PRINT("gracefully closed conection");
          /* stop capturing and close all open devices */
          break;
        } else
        {
          unsigned long ulDataLen = (unsigned long)iRecv;

          TRACE_ENTER_TYPE(LOG_COM,"HilMarshallerConnRxData");
          //printf("pid 0x%08X    ##############################\n", getpid());

          ptMarshaller->atConnectors[ptTcpData->ulConnectorIdx].tConn.pvUser = ptTcpData;
          HilMarshallerConnRxData(ptTcpData->pvMarshaller,
                                  ptTcpData->ulConnectorIdx,
                                  pbData,
                                  ulDataLen);
          //printf("pid 0x%08X    ##########__________##########\n", getpid());
          TRACE_EXIT_TYPE(LOG_COM,"HilMarshallerConnRxData");
        }
        TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread pbData entering tcsSendData");
        EnterCriticalSection(&tcsSendData);
        TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread pbData entered tcsSendData");

        OS_FREE(pbData);
        pbData = NULL;

        TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread pbData leaving tcsSendData");
        LeaveCriticalSection(&tcsSendData);
      }

      if(FD_ISSET(hClient, &tExcept))
      {
        /* socket has been closed */
        TRACE_PRINT_TYPE(LOG_COM,"FD_ISSET ptTcpData->hClient has exception\n");
        TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread except entering tcsSendData");
        EnterCriticalSection(&tcsSendData);
        TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread except entered tcsSendData");

        close(ptTcpData->hClient);
        ptTcpData->hClient = INVALID_SOCKET;
        hClient = INVALID_SOCKET;
        TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread except leaving tcsSendData");
        LeaveCriticalSection(&tcsSendData);
        break;
      }
    } else if (iErr == 0)
    {
      TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS,"clientthread timed out\n");
      /*stop capturing and close all open devices*/
      // TRACE_PRINT("selekt returned 0");
      TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread timeout entering tcsSendData");
      EnterCriticalSection(&tcsSendData);
      TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread timeout entered tcsSendData");
      hClient = ptTcpData->hClient;
      if (hClient != INVALID_SOCKET)
      {
        TRACE_PRINT_TYPE(LOG_COM,"clientthread shutdown");
        shutdown(hClient, SHUT_RDWR );
        TRACE_PRINT_TYPE(LOG_THREADS,"clientthread close    ");
        close(hClient); //dead after here
        ptTcpData->hClient = INVALID_SOCKET;
        hClient = INVALID_SOCKET;
      }
      TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread timeout leaving tcsSendData");
      LeaveCriticalSection(&tcsSendData);
      TRACE_PRINT_TYPE(LOG_THREADS,"break clientthread\n");
      break;
    }
    else
    {
      //printf("select returned with error %\n");
      perror("client select returned with error");
      //printf("0x%X",errno);
      //break;
    }
  }
  TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread exit entering tcsSendData");
  EnterCriticalSection(&tcsSendData);
  TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread exit entered tcsSendData");
  ptTcpData->fClientRunning = 0;
  // ptTcpData->hClientThread = 0; /this is done in the cleanup
  if(ptTcpData->hClient != INVALID_SOCKET)
    close(ptTcpData->hClient);
  ptTcpData->hClient = INVALID_SOCKET;
  hClient = INVALID_SOCKET;
  TRACE_PRINT_TYPE(LOG_LOCK,"ClientThread exit leaving tcsSendData");
  LeaveCriticalSection(&tcsSendData);

  TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS,"exit ClientThread %d",ptTcpData->ulConnectorIdx);
  printf("exit ClientThread %d\n",ptTcpData->ulConnectorIdx);
  pthread_exit(NULL);
}

/*****************************************************************************/
/*! handling incomming TCP connection requests
 * it creates a new ClientThread and Structure for TCP-Data to be used by the thread
*   \param                                                                                           pvParam Pointer reference to TCP connection structure
*   \return        0 on success                                                 */
/*****************************************************************************/
static uint32_t CreateNewClientThread(int hClient, sockaddr_in* ptSockAddr, TCP_CONN_INTERNAL_T* ptTCPListenData)
{
  uint32_t ulRet = RESULT_OK;
  int  fNoDelay = 1;
  int iRes = 0;
  linger tLinger = {1,0};
  struct timeval timeout;
  timeout.tv_sec = 0;
  timeout.tv_usec = SEND_TIMOUT_MS * 1000; // 400 ms timeout to workaround the stopcapture timeout problem with diverging states (driver / firmware)

  /*Sockets setup*/
  iRes = setsockopt(hClient, SOL_SOCKET,  SO_LINGER,   (const char*)&tLinger,  sizeof(tLinger));
  if (iRes != 0)
  {
    fprintf(stderr,"no linger failed with error: ");
    ulRet = (unsigned int)iRes;
  }
  iRes = setsockopt(hClient, IPPROTO_TCP, TCP_NODELAY, (const void*)&fNoDelay, sizeof(fNoDelay));
  if (iRes != 0)
  {
    fprintf(stderr,"no_delay failed with error: ");
    ulRet = (unsigned int)iRes;
  }

  iRes = setsockopt (hClient, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(timeout));
  if (iRes != 0)
  {
    fprintf(stderr,"set sendtimeout failed with error: ");
    ulRet = (unsigned int)iRes;
  }

  if (!ulRet && !iRes)
  {
    uint32_t                    ulConnectorIdx = (uint32_t)~0;                    // mark as invalid
    HIL_MARSHALLER_DATA_T*      ptMarsh        = (HIL_MARSHALLER_DATA_T*)ptTCPListenData->pvMarshaller;
    HIL_MARSHALLER_CONNECTOR_T* ptListenConn   = &ptMarsh->atConnectors[ptTCPListenData->ulConnectorIdx].tConn;

    /* register the connection */
    ulRet =  HilMarshallerRegisterConnector(ptTCPListenData->pvMarshaller,
                                            &ulConnectorIdx,
                                            ptListenConn);

    if (ulRet == RESULT_OK && ulConnectorIdx != (uint32_t)~0)
    {
      /* create new Structure containing all data that a client thread needs */
      TCP_CONN_INTERNAL_T* ptTcpData = NULL;
      ptTcpData = (TCP_CONN_INTERNAL_T*)OS_MALLOC(sizeof(TCP_CONN_INTERNAL_T));

      if (NULL == ptTcpData)
      {
        ulRet = HIL_MARSHALLER_E_OUTOFMEMORY;
      }
      else
      {
        TRACE_PRINT_TYPE(LOG_LOCK,"CreateNewClientThread copy entering tcsSendData");
        EnterCriticalSection(&tcsSendData);
        TRACE_PRINT_TYPE(LOG_LOCK,"CreateNewClientThread copy entered tcsSendData");
        memset(ptTcpData, 0, sizeof(TCP_CONN_INTERNAL_T));
        ptTcpData->hClient       = hClient;
        ptTcpData->ulConnectorIdx =  ulConnectorIdx;
        ptTcpData->pvMarshaller   =  ptTCPListenData->pvMarshaller;
        ptTcpData->fRunning       =  ptTCPListenData->fRunning;
        TRACE_PRINT_TYPE(LOG_LOCK,"CreateNewClientThread copy leaving tcsSendData");
        LeaveCriticalSection(&tcsSendData);

        /* create client thread */
        ptTcpData->fClientRunning  = 1;
        TRACE_PRINT3("start client thread %d for IP: %s Port: %d ", ulConnectorIdx, inet_ntoa(ptSockAddr->sin_addr), ptSockAddr->sin_port );
        printf("start client thread %d for IP: %s Port: %d  \n", ulConnectorIdx, inet_ntoa(ptSockAddr->sin_addr), ptSockAddr->sin_port );

        /* put client thread handle in data as well */
        ulRet = pthread_create(&ptTcpData->hClientThread, NULL, (PFN_PTHREAD)ClientThread, (void*)ptTcpData);

        /* put data to global array */
        if (ulRet == RESULT_OK)
        {
          EnterCriticalSection(&g_tTCPConnList.tcsConnListLock);
          LIST_INSERT_HEAD(&g_tTCPConnList.tTCPConnList, ptTcpData , tList);
          g_tTCPConnList.ulEntries++;
          LeaveCriticalSection(&g_tTCPConnList.tcsConnListLock);
        }
        else
        {
          /* thread creation failed */
          ulRet = HIL_MARSHALLER_E_OUTOFMEMORY;
          OS_FREE(ptTcpData);
          ptTcpData = NULL;
        }
      }
      if (ulRet != RESULT_OK)
      {
        HilMarshallerUnregisterConnector(ptTCPListenData->pvMarshaller,ulConnectorIdx);
      }
    }
  }
  return ulRet;
}

void CleanupClientThreads(void* pvMarshaller)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*) pvMarshaller;
  //TRACE_ENTER_TYPE(LOG_COM,"CleanupClientThreads");
  /* Clenaup Data */
  EnterCriticalSection(&g_tTCPConnList.tcsConnListLock);
  if (g_tTCPConnList.ulEntries != 0)
  {
    TRACE_ENTER_TYPE(LOG_COM,"CleanupClientThreads");
    TCP_CONN_INTERNAL_T* ptTcpData = NULL;
    LIST_FOREACH(ptTcpData, &g_tTCPConnList.tTCPConnList, tList)
    {
      TRACE_PRINT_TYPE(LOG_COM,"iterating ptTcpData %p", (void*)ptTcpData);
      if( ptTcpData != NULL && !ptTcpData->fClientRunning)
      {
        /* we found an unused tcp client thread so we */
        /* join the thread */
        /* we need to unlock here so the thread may not deadlock */

        LeaveCriticalSection(&g_tTCPConnList.tcsConnListLock);

        TRACE_PRINT_TYPE(LOG_LOCK,"CleanupClientThreads handle entering tcsSendData");
        EnterCriticalSection(&tcsSendData);
        TRACE_PRINT_TYPE(LOG_LOCK,"CleanupClientThreads handle entered tcsSendData");
        HANDLE hClientThread = ptTcpData->hClientThread;
        TRACE_PRINT_TYPE(LOG_LOCK,"CleanupClientThreads handle leaving tcsSendData");
        LeaveCriticalSection(&tcsSendData);

        if(hClientThread) pthread_join(hClientThread, NULL);

        /* clear the tcpdata */
        TRACE_PRINT_TYPE(LOG_LOCK,"CleanupClientThreads cleanup entering tcsSendData");
        EnterCriticalSection(&tcsSendData);
        TRACE_PRINT_TYPE(LOG_LOCK,"CleanupClientThreads cleanup entered tcsSendData");
        CleanupClientThreadData(ptTcpData);
        TRACE_PRINT_TYPE(LOG_LOCK,"CleanupClientThreads cleanup leaving tcsSendData");
        LeaveCriticalSection(&tcsSendData);


        /* we reenter the section to have consistent state in our list iteration */
        EnterCriticalSection(&g_tTCPConnList.tcsConnListLock);

        /* cleanup device state if we just closed the last connection */
        TRACE_PRINT_TYPE(LOG_COM,"openconnections %d\n",g_tTCPConnList.ulEntries);
        if(g_tTCPConnList.ulEntries == 0)
        {
          /* we are the last active connection */
          ptMarshaller->ptTransports->pfnCloseDev(ptMarshaller);
        }
        else
        {
            TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS|LOG_NETANAAPI,"not cleaning netANALYZER state because we have %d active connections\n",g_tTCPConnList.ulEntries);
        }
      }
    }
  }
  LeaveCriticalSection(&g_tTCPConnList.tcsConnListLock);
  //TRACE_EXIT_TYPE(LOG_COM,"CleanupClientThreads");
  /* we dont have any unclosed threads and unused tcp data related to it */
}

/*****************************************************************************/
/*! Thread serving incoming TCP connections
*   \param pvParam Pointer reference to TCP connection structure
*   \return        Always 0                                                  */
/*****************************************************************************/
static uint32_t ServerThread(void* pvParam)
{
  uint32_t ulRes = RESULT_OK;
  TCP_CONN_INTERNAL_T* ptTcpData = (TCP_CONN_INTERNAL_T*)pvParam;
  TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS,"tcp listening thread started");
  while(ptTcpData->fRunning)
  {
    int ret  = 0;
    fd_set  tRead;
    timeval tTimeout = {0};

    tTimeout.tv_sec = 1;

    FD_ZERO(&tRead);
    FD_SET(ptTcpData->hListen, &tRead);
    if( 0 < (ret = select(ptTcpData->hListen + 1, &tRead, NULL, NULL, &tTimeout)))
    {
      // TRACE_PRINT("incomming tcp connection request");
      if(FD_ISSET(ptTcpData->hListen, &tRead))
      {
        /* We have a client to accept */
        sockaddr_in tSockAddr    = {0};
        uint        iSockAddrLen = sizeof(tSockAddr);
        int         hClient      = accept(ptTcpData->hListen, (sockaddr*)&tSockAddr, &iSockAddrLen);
        printf("tcp connection request from: %s port: %d \n", inet_ntoa(tSockAddr.sin_addr), tSockAddr.sin_port);
        TRACE_PRINT2("tcp connection request from: %s port: %d", inet_ntoa(tSockAddr.sin_addr), tSockAddr.sin_port);

        /* we cleanup old connections before we connect*/
        CleanupClientThreads(ptTcpData->pvMarshaller);

        /* we create now a new thread for this connection ant give it the required data */
        ulRes =  CreateNewClientThread(hClient, &tSockAddr, ptTcpData);
        if (ulRes != RESULT_OK)
        {
          //fprintf(stderr, "Creating thread failed \n");
          TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS|LOG_ERR,"Creating Client thread failed ");
          close(hClient);
        }
      }
      else
      {
        fprintf(stderr, "socket is not part of readset\n");
      }
    }
    else if(ret < 0)
    {
      //printf("select returned with error 0x%X\n",ret);
      perror("select returned with error");
    }
    else
    {

      /* we cleanup old connections */
      /* this is the timeout of select */
      CleanupClientThreads(ptTcpData->pvMarshaller);

    }
  }
  TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS,"tcp listening thread Stopped\n");

  return 0;
}

/*****************************************************************************/
/*! TCP connector initialization
*   \param ptParams     Marshaller specific parameters (e.g. timeout)
*   \param ptConfigData UART configuration data
*   \param pvMarshaller Handle to the marshaller, this connector should be added
*   \return RESULT_OK on success                                              */
/*****************************************************************************/
uint32_t TCPConnectorInit(const HIL_MARSHALLER_CONNECTOR_PARAMS_T* ptParams, void* pvMarshaller)
{
  HIL_MARSHALLER_CONNECTOR_T tMarshConn;
  uint32_t                   eRet;
  TCP_CONN_INTERNAL_T*       ptTcpData = NULL;

  InitializeCriticalSection(&tcsSendData);

  TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS,"TCPConnectorInit");


  /* this list holds established connections not the listening data*/
  memset(&g_tTCPConnList,0,sizeof(TCP_CONN_LIST_T));
  LIST_INIT(&g_tTCPConnList.tTCPConnList);
  InitializeCriticalSection(&g_tTCPConnList.tcsConnListLock);

  /* we create listening data */
  if(NULL == (ptTcpData = (TCP_CONN_INTERNAL_T*)OS_MALLOC(sizeof(*ptTcpData))))
  {
    eRet = HIL_MARSHALLER_E_OUTOFMEMORY;
  } else
  {
    sockaddr_in tSockAddr = {0};

    memset(&tMarshConn, 0, sizeof(tMarshConn));
    memset(ptTcpData, 0, sizeof(*ptTcpData));

    ptTcpData->ulConnectorIdx = (uint32_t)~0;
    ptTcpData->pvMarshaller   = pvMarshaller;
    ptTcpData->fRunning       = 1;
    ptTcpData->hClient        = INVALID_SOCKET;
    ptTcpData->fClientRunning = 0;

    tSockAddr.sin_addr.s_addr = INADDR_ANY;

    unsigned short usPortAddr = HIL_TRANSPORT_IP_PORT;
    tSockAddr.sin_port = htons(usPortAddr);// htons() does not work under CE
    
    //initLog();
 
    tSockAddr.sin_family      = AF_INET;

    if(INVALID_SOCKET == (ptTcpData->hListen = socket(AF_INET, SOCK_STREAM, 0)))
    {
      fprintf(stderr, "could not create socket");
      eRet = HIL_MARSHALLER_E_OUTOFRESOURCES;

    } else if(SOCKET_ERROR == bind(ptTcpData->hListen, (sockaddr*)&tSockAddr, sizeof(tSockAddr)))
    {
      fprintf(stderr, "could not bind marshaller port");
      eRet = HIL_MARSHALLER_E_OUTOFRESOURCES;

    } else if(SOCKET_ERROR == listen(ptTcpData->hListen, 0))
    {
      fprintf(stderr, "could not start listening on marshaller port");
      eRet = HIL_MARSHALLER_E_OUTOFRESOURCES;

    }
    else if(0 != pthread_create(  &ptTcpData->hServerThread,
                                  NULL,
                                  (PFN_PTHREAD)ServerThread,
                                  (void*)ptTcpData ))
    {
      fprintf(stderr, "server thread creation failed");
      eRet = HIL_MARSHALLER_E_OUTOFRESOURCES;

    }
    else
    {
      tMarshConn.pfnTransmit      = TCPConnectorSend;
      tMarshConn.pfnTransmitData  = TCPConnectorSendData;
      tMarshConn.pfnDeinit        = TCPConnectorDeinit;
      tMarshConn.pfnShutdown       = TCPConnectorShutdown;
      tMarshConn.pvUser           = ptTcpData;
      tMarshConn.ulDataBufferSize = ptParams->ulDataBufferSize;
      tMarshConn.ulDataBufferCnt  = ptParams->ulDataBufferCnt;
      tMarshConn.ulTxBufferCnt    = ptParams->ulTxBufferCnt;
      tMarshConn.ulTxBufferSize   = ptParams->ulTxBufferSize;
      tMarshConn.ulTimeout        = ptParams->ulTimeout;
      //tMarshConn.pfnDeinit

      eRet = HilMarshallerRegisterConnector(pvMarshaller, 
                                            &ptTcpData->ulConnectorIdx, 
                                            &tMarshConn);

    }

    /* Something has failed, so uninitialize this connector instance */
    if(eRet != RESULT_OK)
    {
      TCPConnectorDeinit(ptTcpData);
    }
  }
  
  return eRet;
}

/*****************************************************************************/
/*! terminate any outstanding sending opperations
*   \param  ptTcpInfo Buffer for TCP connector information
*   \return RESULT_OK on success                                              */
/*****************************************************************************/
int32_t TCPConnectorShutdown(void* pvUser)
{
  TCP_CONN_INTERNAL_T* ptTcpData = (TCP_CONN_INTERNAL_T*)pvUser;
  int32_t lRet = 0;
  int hClient = INVALID_SOCKET;
  //static bool fDeinitActive = false;
  TRACE_ENTER_TYPE(LOG_COM|LOG_THREADS,"TCPConnectorShutdown");

  //if (!fDeinitActive)
  {
    //fDeinitActive = true;

    /* Check if data is valid */
    if(NULL != ptTcpData)
    {
      /* lock access to Sockets */
      TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorShutdown entering tcsSendData");
      EnterCriticalSection(&tcsSendData);
      TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorShutdown entered tcsSendData");
      hClient = ptTcpData->hClient;

      if (hClient != INVALID_SOCKET)
      {
          TRACE_PRINT_TYPE(LOG_COM,"shutdown client socket");
        lRet = shutdown(hClient, SHUT_RDWR );
        if (lRet)
        {
          TRACE_PRINT_TYPE(LOG_COM|LOG_ERR, "socket shutdown error %d",errno);
          //perror("error in shutdown\n");
        }
        TRACE_PRINT_TYPE(LOG_COM,"closing socket %d", hClient);
        close(hClient);  // we have shutt it down so we force closing
        hClient = INVALID_SOCKET;
        ptTcpData->hClient = hClient;
      }
      else
      {
          TRACE_PRINT_TYPE(LOG_COM|LOG_ERR,"shutdown invalid socket");
      }
      //deinitLog();
      /* this is done in the cleanup in the thread
      HIL_MARSHALLER_DATA_T* ptMarshaller    = (HIL_MARSHALLER_DATA_T*)ptTcpData->pvMarshaller;
      CONNECTOR_DATA_T*  ptConnectorData = NULL;
      ptConnectorData = &ptMarshaller->atConnectors[ptTcpData->ulConnectorIdx];
      if (0 == ptConnectorData)
      {
        TRACE_PRINT("No Connector in marshaller (ptConnectorData == NULL)");
        lRet = RESULT_ERROR;
      }
      */
      ptTcpData->fClientRunning  = 0; // only terminate the client thread
      TRACE_PRINT_TYPE(LOG_LOCK,"TCPConnectorShutdown leaving tcsSendData");
      LeaveCriticalSection(&tcsSendData);
    }
    //fDeinitActive = false;
  } // if !DeinitActive

  TRACE_EXIT_TYPE(LOG_COM|LOG_THREADS,"TCPConnectorShutdown");
  return lRet;
}

