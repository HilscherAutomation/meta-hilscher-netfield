/*
 * Copyright (c) 2005 - 2006
 * CACE Technologies LLC, Davis (CA)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the company (CACE Technologies LLC) nor the
 * names of its contributors may be used to endorse or promote products
 * derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef __PACKET_DEBUG_393073863432093179878957
#define __PACKET_DEBUG_393073863432093179878957

#ifdef __cplusplus
extern "C"
{
#endif
//#ifdef _DEBUG_TO_SYSLOG
//  #include <syslog.h>
//#endif //_DEBUG_TO_SYSLOG
//
//#ifdef _DEBUG_TO_SYSLOG
//  //setlogmask (LOG_UPTO (LOG_NOTICE));
//  openlog ("App", LOG_CONS | LOG_PID | LOG_NDELAY, LOG_LOCAL1);
//  syslog (LOG_NOTICE, "SysLog started by User %d", getuid ());
//#endif //_DEBUG_TO_SYSLOG
//
//#ifdef _DEBUG_TO_SYSLOG
//  closelog ();
//#endif //_DEBUG_TO_SYSLOG
//
//#ifdef _DEBUG_TO_SYSLOG
//  sprintf(buf, Format, Marker);
//  syslog(LOG_INFO, "%s", buf);
//#endif //_DEBUG_TO_SYSLOG

#ifdef _DEBUG_TO_FILE

//#include <cstdarg>
#include <stdio.h>
#include <stdarg.h>
#include "win2lin.h"

extern uint32_t g_ulTempRxBufferKA;
extern uint32_t g_ulTempRxBufferCB;
extern uint32_t g_ulTempAckBuffer;


#define MAX_LOG_LINES 1000

extern FILE* g_LogFileHandle;
static char g_szFilename[40] = {0};


static FILE* OpenLogfile(char* szFilename){
  g_LogFileHandle = fopen(szFilename, "r+");
  if (!g_LogFileHandle)
  {
    fprintf(stderr, "unable to open file --> creating\n");
    g_LogFileHandle = fopen(szFilename, "w+");
  }else
  {
    fprintf(stdout, "file open\n");
  }
  strcpy(g_szFilename, szFilename);
  return g_LogFileHandle;
}

static void CloseLogfile(void)
{
  fclose(g_LogFileHandle);
  g_LogFileHandle = NULL;
}

static void OutputDebugStringVA(const char* Format, ...)
{
  static uint32_t ulLineCnt = 0; // counting the lines currently in the logfile;
  static struct timeval tvLast;
  va_list Marker;
  unsigned int dwThreadId;
  int iRet = 0;

  if (g_LogFileHandle == NULL)
    return;

  ulLineCnt++; // beginning at front of file after MAX_LOG_LINES
  if (ulLineCnt > MAX_LOG_LINES)
  {
    // continuosly to log to file and keep the same size  even if drive is full
    ulLineCnt = 0;
    fseek( g_LogFileHandle , 0 , SEEK_SET );
  }

  struct timeval tv, tvD;
  time_t nowtime;
  struct tm *nowtm;
  char tmbuf[64], buf[64];


  dwThreadId = pthread_self();

  gettimeofday(&tv, NULL);
  nowtime = tv.tv_sec;

  timersub(&tv, &tvLast, &tvD);
  tvLast = tv;

  nowtm = localtime(&nowtime);
  strftime(tmbuf, sizeof tmbuf, "%Y-%m-%d %H:%M:%S", nowtm); // create timestamp
  snprintf(buf, sizeof buf, "[%.08X] %s.%06d  dt:%10d.%06d  ", dwThreadId, tmbuf, (int)tv.tv_usec, (int)tvD.tv_sec, (int)tvD.tv_usec);   // prepend threadid and append micro seconds and delta t

  va_start(Marker, Format);     /* Initialize variable arguments. */

  iRet = fprintf(g_LogFileHandle, "%s", buf);

  iRet += vfprintf(g_LogFileHandle, Format, Marker);


  iRet = fflush(g_LogFileHandle);
  va_end(Marker);
}

//#pragma warning(pop)

#elif defined (_DBG)

#include <strsafe.h>

static VOID OutputDebugStringVA(LPCSTR Format, ...)
{
  va_list Marker;
  CHAR string[1024];
  DWORD dwLastError = GetLastError();

  va_start( Marker, Format );     /* Initialize variable arguments. */

  StringCchVPrintfA(string, sizeof(string), Format, Marker);

  OutputDebugStringA(string);

  va_end(Marker);

  SetLastError(dwLastError);
}
#endif


#if defined(_DBG) || defined(_DEBUG_TO_FILE)

#ifdef _DBG
#define TRACE_PRINT_DLLMAIN(_x)      OutputDebugStringVA ("    " _x "\n")
#else
#define TRACE_PRINT_DLLMAIN(_x)      //we cannot use the _DEBUG_TO_FILE stuff from DllMain!!
#endif

#define LOG_ERR           0x01
#define LOG_COM           0x02
#define LOG_LOCK          0x04
#define LOG_BUFF          0x08
#define LOG_NETANAAPI     0x10
#define LOG_CLB           0x20
#define LOG_THREADS       0x40
#define LOG_SIG           0x80

//#define _DEBUG_TYPE_MASK         (LOG_SIG|LOG_ERR|LOG_LOCK|LOG_BUFF|LOG_COM|LOG_NETANAAPI|LOG_CLB)

#ifndef _DEBUG_TYPE_MASK
#define _DEBUG_TYPE_MASK 0xFFFFFFFF
#endif


#define TRACE_ENTER(_x)                                OutputDebugStringVA ("--> " _x "\n")
#define TRACE_EXIT(_x)                                 OutputDebugStringVA ("<-- " _x "\n")
#define TRACE_PRINT(_x)                                OutputDebugStringVA("    " _x "\n")
#define TRACE_PRINT1(_x, _y)                           OutputDebugStringVA("    " _x "\n", _y)
#define TRACE_PRINT2(_x, _p1, _p2)                     OutputDebugStringVA("    " _x "\n", _p1, _p2)
#define TRACE_PRINT3(_x, _p1, _p2, _p3)                OutputDebugStringVA("    " _x "\n", _p1, _p2, _p3)
#define TRACE_PRINT4(_x, _p1, _p2, _p3, _p4)           OutputDebugStringVA("    " _x "\n", _p1, _p2, _p3, _p4)
#define TRACE_PRINT6(_x, _p1, _p2, _p3, _p4, _p5, _p6) OutputDebugStringVA("    " _x "\n", _p1, _p2, _p3, _p4, _p5, _p6 )

#define TRACE_ENTER_TYPE(_type,_x)                     if((_type) & _DEBUG_TYPE_MASK) TRACE_ENTER(_x)
#define TRACE_EXIT_TYPE(_type,_x)                      if((_type) & _DEBUG_TYPE_MASK) TRACE_EXIT(_x)

#define TRACE_PRINTVA(_x, ...)                         OutputDebugStringVA("    %s  " _x "\n" , __func__ , ##__VA_ARGS__)
#define TRACE_PRINT_TYPE(_type, _x, ...)               if ((_type) & _DEBUG_TYPE_MASK) TRACE_PRINTVA( _x , ##__VA_ARGS__)

#else

#define TRACE_ENTER(_x)
#define TRACE_ENTER_TYPE(_type,_x)
#define TRACE_PRINT_DLLMAIN(_x)
#define TRACE_EXIT(_x)
#define TRACE_EXIT_TYPE(_type,_x)
#define TRACE_PRINT(_x)
#define TRACE_PRINT1(_x, _y)
#define TRACE_PRINT2(_x, _p1, _p2)
#define TRACE_PRINT3(_x, _p1, _p2, _p3)
#define TRACE_PRINT4(_x, _p1, _p2, _p3, _p4)
#define TRACE_PRINT6(_x, _p1, _p2, _p3, _p4, _p5, _p6)

#define TRACE_PRINTVA(...)
#define TRACE_PRINT_TYPE(_type, ...)

#define TRACE_PRINT_OS_INFO()

#endif

#ifdef __cplusplus
}
#endif

#endif //__PACKET_DEBUG_393073863432093179878957
