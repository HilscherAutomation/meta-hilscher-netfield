/******************************************************************************



*******************************************************************************

  Last Modification:

  Description:
    Declarations for  netANALYZER Marshaller Linux ported from windows

  Changes:
    Date        Author        Description
  ---------------------------------------------------------------------------
    2012-6-26   JAK           File created.

*******************************************************************/

#ifndef __WIN2LIN_H
#define __WIN2LIN_H


// this helps the va_ macros
#define ECLIPSEBUILD = 1
#ifdef ECLIPSEBUILD // this part is just to fix spurious Eclipse errors
    typedef __builtin_va_list va_list;
    #define va_start(v,l)   __builtin_va_start(v,l)
    #define va_end(v)   __builtin_va_end(v)
    #define va_arg(v,l) __builtin_va_arg(v,l)
    #if !defined(__STRICT_ANSI__) || __STDC_VERSION__ + 0 >= 199900L || defined(__GXX_EXPERIMENTAL_CXX0X__)
    #define va_copy(d,s)    __builtin_va_copy(d,s)
    #endif
    #define __va_copy(d,s)  __builtin_va_copy(d,s)
    typedef __builtin_va_list __gnuc_va_list;
    typedef __gnuc_va_list va_list;
    typedef va_list __va_list;
#endif

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdbool.h>
#include <string.h>
//#include <dlfcn.h>
#include <signal.h>
#include <semaphore.h>


#include <limits.h>
#include <sys/time.h>
#include <time.h>
#include <sys/utsname.h>
#include <errno.h>

#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <net/if.h>

#include <pthread.h>

//
////#include "ofstream"

#define RESULT_ERROR true
#define RESULT_OK false

#ifndef MAXDWORD
#define MAXDWORD UINT_MAX
#endif


#ifndef SOCKET
#define SOCKET 								int
#define SOCKADDR_IN 					struct sockaddr_in
#define SOCKADDR						 	struct sockaddr
#define HOSTENT								struct hostent
#define WINAPI
#endif

#define OS_MALLOC malloc
#define OS_FREE free

#define BYTE byte

#ifndef INVALID_SOCKET
#define INVALID_SOCKET        -1
#endif

#ifndef SOCKET_ERROR
#define SOCKET_ERROR          -1
#endif

#define HANDLE pthread_t
typedef void* (*PFN_PTHREAD)(void*);

#define CRITICAL_SECTION pthread_mutex_t


#ifdef __cplusplus
  extern "C" {
#endif

void InitializeCriticalSection(pthread_mutex_t* pm );

void EnterCriticalSection(pthread_mutex_t* pm);

void LeaveCriticalSection(pthread_mutex_t* pm);

int TryCriticalSection(pthread_mutex_t* pm);

void DeleteCriticalSection(pthread_mutex_t* pm);

int WaitForSem(sem_t* pSem, unsigned long ulMSDelay);

int WaitForSingleObject(pthread_t thread, uint32_t uiMSTimeout);

bool TerminateThread(pthread_t thread, uint32_t rc);

/*
 * uiMSTimeout in milliseconds to wait for thread
 * returns 0 on succes
 */

/*
bool CreateThread(	void* lpThreadAttributes,
							 	 	 	uint32_t dwStackSize,
							 	 	 	void* (*lpStartAddress)(void*),
							 	 	 	void* lpParameter,
							 	 	 	uint32_t dwCreationFlags,
							 	 	 	void * lpThreadId)
{
	pthread_create((unsigned long int*) lpThreadId,
									(pthread_attr_t*) lpThreadAttributes,
									lpStartAddress,
									lpParameter);
	return lpThreadId;
}*/

#ifdef __cplusplus
  }
#endif

#endif /* #ifndef __WIN2LIN_H */

