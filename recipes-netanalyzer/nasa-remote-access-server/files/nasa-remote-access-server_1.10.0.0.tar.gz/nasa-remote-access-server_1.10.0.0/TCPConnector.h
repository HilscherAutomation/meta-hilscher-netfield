/**************************************************************************************

   Copyright (c) Hilscher GmbH. All Rights Reserved.

 **************************************************************************************

   Filename:
    $Id: TCPConnector.h 1917 2010-07-16 15:51:16Z stephans $
   Last Modification:
    $Author: stephans $
    $Date: 2010-07-16 17:51:16 +0200 (Fr, 16 Jul 2010) $
    $Revision: 1917 $

   Targets:
     Win32        : yes

   Description:
    TCP/IP connector for Hilscher marshaller package

   Changes:

     Version   Date        Author   Description
     ----------------------------------------------------------------------------------
     1        25.05.2009   MT       initial version

**************************************************************************************/

//#pragma once
#ifndef __TCPCONNECTOR__H
#define __TCPCONNECTOR__H

#include "win2lin.h"
//#include "TcpipNetident.h"

#include "Marshaller/MarshallerInternal.h"
//#include "Marshaller/MarshallerConfig.h"

/*****************************************************************************/
/*! TCP connector data                                                       */
/*****************************************************************************/
typedef struct TCP_CONN_INTERNAL_Ttag
{
  LIST_ENTRY(TCP_CONN_INTERNAL_Ttag) tList;
  uint32_t    ulConnectorIdx;
  void*       pvMarshaller;

  int         fRunning;
  int         fClientRunning;

  SOCKET      hListen;
  HANDLE      hServerThread;
  SOCKET      hClient;
  HANDLE      hClientThread;
  uint32_t    ulKeepaliveID;    /* !!!! this needs to be used instead of the keepaliveid in the connector */
} TCP_CONN_INTERNAL_T;

uint32_t TCPConnectorInit       (const HIL_MARSHALLER_CONNECTOR_PARAMS_T* ptParams, void* pvMarshaller);
int32_t  TCPConnectorShutdown   (void* ptConn);

#endif /* __TCPCONNECTOR__H */
