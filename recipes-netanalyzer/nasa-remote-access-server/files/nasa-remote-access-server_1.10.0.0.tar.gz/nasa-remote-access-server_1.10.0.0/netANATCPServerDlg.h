#pragma once
#include <map>
#include "Marshaller/netANATransport.h"
#include "TCPConnector.h"

#define SUBITEM_HOSTNAME   1
#define SUBITEM_RXCOUNT    2
#define SUBITEM_TXCOUNT    3
#define MARSHALLER_REQUEST (WM_USER + 1)
#define IDT_CYCLIC         (WM_USER + 2)
#define IDT_TCPINFO        (WM_USER + 3)

#define MAX_PATH 128

/*****************************************************************************/
/*! \class CnetANATCPServerDlg
 * This is the main dialog class for the TCPServer application               */
/*****************************************************************************/
class CnetANATCPServerDlg
{
// Construction
public:
  uint32_t   InitMarshaller       ( void);
  void       DeinitMarshaller     ( void);
  bool			 OnInitDialog					();
  void 			 OnTimer(int signum);
  void 			 OnDestroy(int signum);


// Implementation
protected:
  static sem_t 			 m_sem;
  static void*       m_pvMarshaller;
  void*              m_pvDev;
  HANDLE						 m_hRequesThread;
  bool 		   				 m_fRequestThreadRunning;

  static  void    MarshallerRequestWrapper(void* pvMarshaller, void* pvUser);
  static  bool 		RequestThread				(void* pvUser);

  void UnloadDLL        ( NETX_ANALYZER_DLL_INFO_T* ptConnectorInfo);
  bool LoadNetANAAPIDLL ( NETX_ANALYZER_DLL_INFO_T* ptConnectorInfo);

  static bool 					OnMarshallerRequest(void* m_pvMarshaller/*unsigned int* wParam, long* lParam*/);
};

