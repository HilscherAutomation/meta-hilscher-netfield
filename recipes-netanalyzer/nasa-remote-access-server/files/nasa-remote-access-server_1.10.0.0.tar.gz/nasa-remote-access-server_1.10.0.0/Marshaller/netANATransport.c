/**************************************************************************************

   Copyright (c) Hilscher GmbH. All Rights Reserved.

 **************************************************************************************

   Filename:
    $Workfile: netANATransport.c $
   Last Modification:
    $Author: sebastiand $
    $Modtime: $
    $Revision: 1776 $

   Targets:
     Win32/ANSI   : yes
     Win32/Unicode: yes (define _UNICODE)
     WinCE        : yes

   Description:
    Imlpementation of Marshaller function call interpretation

   Changes:

     Version   Date        Author   Description
     ----------------------------------------------------------------------------------
     5              28.06.2010  SD         Change:
                                            - new types for 64-bit support
     4              19.08.2009  MS         Corrected destination addresses in confirmation data copy operations for
                                            - xChannelFindFirstFile / xChannelFindNextFile
                                            - xSysdeviceFindFirstFile / xSysdeviceFindNextFile
     3              18.08.2009  MS         Initialize data buffer tChannelInfo before calling xDriverEnumChannels().
     2              08.07.2009  MT         Added functions:
                                            - xChannelIOInfo
                                            - xChannelFindFirstFile / xChannelFindNextFile
                                            - xSysdeviceFindFirstFile / xSysdeviceFindNextFile
     1              26.05.2009  PL         intitial version

 **************************************************************************************/

/*****************************************************************************/
/*! \file netANATransport.c
 *   netANA marshalling via Hilscher Transport Protocol                                                                  */
/*****************************************************************************/


#include "../win2lin.h"

#include "../debug_trace.h"

//#include "../TcpipNetident.h" // netident version 2 is standalone

#include "netANATransport.h"        // include "TLR_Types.h" "TLR_Results.h" "HilTransport.h"

#include "MarshallerInternal.h"      // "netANAAPI_Wrapper.h""MarshallerConfig.h""HilTransport.h"<sys/queue.h>

//#include "MarshallerVersion.h"
#include "../version.h"

#include "../SDK/netana_errors.h"

#include "../SDK/netana_user.h"

#include "../TCPConnector.h"        // "TcpipNetident.h""MarshallerConfig.h"

#include "netANA_MarshallerFrame.h" // after osincludes need windows.h

#include <sys/stat.h>               // for file permissions

#include <fcntl.h>                   // for file operations
 // #include <sys/socket.h>             // required for getsockname already included by win2lin.h


//#include "../trace_states.h"           // debuging with tracing



#ifndef min
#define min(a,b) ((a > b) ? b : a)
#endif

#ifdef TARGET_IOTGW
#define VERSION_FILE_PATH "/opt/nasa/version"
#else
#define VERSION_FILE_PATH "/opt/version"
#endif

#define OS_RELEASE_PATH "/etc/os-release"

#define MAX_VERSION_LEN 64
#define MAX_OS_INFO_LEN 128


#define  HANDLE_IS_VALID(a)        (0 != (a & MSK_MARSHALLER_HANDLE_VALID))
#define  HANDLE_GET_OBJSUBIDX(a)   ((a & MSK_MARSHALLER_HANDLE_OBJECTSUBIDX) >> SRT_MARSHALLER_HANDLE_OBJECTSUBIDX)
#define  HANDLE_GET_OBJIDX(a)      ((a & MSK_MARSHALLER_HANDLE_OBJECTIDX) >> SRT_MARSHALLER_HANDLE_OBJECTIDX)
#define  HANDLE_GET_OBJTYPE(a)     ((a & MSK_MARSHALLER_HANDLE_OBJECTTYPE) >> SRT_MARSHALLER_HANDLE_OBJECTTYPE)
#define  SEQ_GET_REQUEST(a)        ((a & MSK_MARSHALLER_SEQUENCE_REQUEST) >> SRT_MARSHALLER_SEQUENCE_REQUEST)
#define  SEQ_GET_SUPPORTED(a)      ((a & MSK_MARSHALLER_SEQUENCE_SUPPORTED) >> SRT_MARSHALLER_SEQUENCE_SUPPORTED)
#define  SEQ_GET_NUMBER(a)         ((a & MSK_MARSHALLER_SEQUENCE_NUMBER) >> SRT_MARSHALLER_SEQUENCE_NUMBER)

#define  HANDLE_SET_VALID(a)       (a |= ((uint32_t)1 << SRT_MARSHALLER_HANDLE_VALID))
#define  HANDLE_SET_OBJSUBIDX(a,b) (a |= ((uint32_t)b << SRT_MARSHALLER_HANDLE_OBJECTSUBIDX))
#define  HANDLE_SET_OBJIDX(a,b)    (a |= ((uint32_t)b << SRT_MARSHALLER_HANDLE_OBJECTIDX))
#define  HANDLE_SET_OBJTYPE(a,b)   (a |= ((uint32_t)b << SRT_MARSHALLER_HANDLE_OBJECTTYPE))
#define  SEQ_SET_REQUEST(a)        (a |= ((uint32_t)1 << SRT_MARSHALLER_SEQUENCE_REQUEST))
#define  SEQ_SET_SUPPORTED(a)      (a |= ((uint32_t)1 << SRT_MARSHALLER_SEQUENCE_SUPPORTED))
#define  SEQ_SET_RESPONSE(a)       (a &= ~((uint32_t)1 << SRT_MARSHALLER_SEQUENCE_REQUEST))

/*****************************************************************************/
/*! \addtogroup NETX_MARSHALLER_netANA
 *   \{                                                                       */
/*****************************************************************************/

/*****************************************************************************/
/*! Data for a channel object                                                */
/*****************************************************************************/
typedef struct MARSH_netANA_CHANNEL_DATA_Ttag
{
  NETANA_HANDLE    hChannel;   /*!< Handle returned from xChannelOpen       */
  unsigned long ulOpenCnt;  /*!< Number of times xChannelOpen was called */
  int           fValid;

} MARSH_netANA_CHANNEL_DATA_T, *PMARSH_netANA_CHANNEL_DATA_T;

/*****************************************************************************/
/*! Data for a board/device object                                           */
/*****************************************************************************/
typedef struct MARSH_netANA_DEVICE_DATA_Ttag
{
  int                         fValid;         /*!< !=0 if the device is valid                     */
  unsigned long               ulBoard;        /*!< Board number (Idx in our array)                */
  NETANA_HANDLE               hDev;
  NETANA_DEVICE_INFORMATION_T tBoardInfo;     /*!< netANA Board information                       */
  MARSH_netANA_CHANNEL_DATA_T   tSysDevice;   /*!< System device object                           */
  PMARSH_netANA_CHANNEL_DATA_T  ptChannels;   /*!< Array of channel objects                       */
  unsigned long               ulChannelCount; /*!< Number of entries in channel objects array     */
} MARSH_netANA_DEVICE_DATA_T, *PMARSH_netANA_DEVICE_DATA_T;


/*****************************************************************************/
/*! Structure to handle more than one instance of marshaller                 */
/*****************************************************************************/
typedef struct MARSH_HANDLE_INSTANCE_Ttag
{
  unsigned long             ulDriverOpenCnt;    /*!< Number of times the driver was opened via Marshaller Calls       */
  unsigned long             ulDeviceCnt;        /*!< Number of known devices/board, initialized in MarshallerInit     */
  NETANA_HANDLE             hDriver;            /*!< Driver handle                                                    */
  DRIVER_FUNCTIONS          tDRVFunctions;      /*!< Function list of netANA API                                       */
  PMARSH_netANA_DEVICE_DATA_T ptDevices;        /*!< List of available devices, initialized in MarshallerInit         */

} MARSH_HANDLE_INSTANCE_T, *PMARSH_HANDLE_INSTANCE_T;

struct FILE_DOWNLOAD_STATE
{
  int hFile;
  uint32_t uiTotalSize;
  uint32_t uiCurrentSize;
  uint32_t uiTotalBlocks;
  int32_t iLastBlock;
  uint32_t uiBlockSize;
} tFileState;

typedef uint8_t ETH_ADDRESS[6];

static int32_t HandleCommunicationCommand(HIL_MARSHALLER_BUFFER_T* ptBuffer);
static int32_t HandleDriverCommand      (HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser);
static int32_t HandleSysdeviceCommand   (HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser);
static int32_t HandleManagementCommand  (HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser);
//static int32_t HandleChannelCommand     (HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser);

// static PMARSH_netANA_DEVICE_DATA_T FindDevice(char* szBoard, void* pvUser);

static void HilMarshallerDeInitModul(void* pvUser);
static void HilMarshallerCloseUsedDevices(void* pvMarshaller);
static void HilMarshallerHandlePacket(void* pvMarshaller, HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser);


/*****************************************************************************/
/*! Initialize netANA API transport layer
 *   \param pvMarshaller     Marshaller handle
 *   \param pvConfig         netANA API specific configuration data
 *   \return !=0 on success                                                   */
/*****************************************************************************/
uint32_t netANATransportInit(void* pvMarshaller, void* pvConfig)
{
  uint32_t               eRet = RESULT_OK;
  PMARSH_HANDLE_INSTANCE_T ptInstance;

  /* Invalid parameter*/
  if( (!pvMarshaller) || (!pvConfig))
    return HIL_MARSHALLER_E_INVALIDPARAMETER;

  if(NULL == (ptInstance = OS_MALLOC(sizeof(MARSH_HANDLE_INSTANCE_T))))
  {
    eRet = HIL_MARSHALLER_E_OUTOFMEMORY;
  } else
  {
    TRANSPORT_LAYER_DATA_T  tLayerData  = {0};
    netANA_TRANSPORT_CONFIG*  ptConfig    = (netANA_TRANSPORT_CONFIG*)pvConfig;
    //DRIVER_INFORMATION      tDriverInfo;

    NETANA_DRIVER_INFORMATION_T tNetAnaDriverInfo;


    memset(ptInstance, 0, sizeof(*ptInstance));

    tLayerData.usDataType = HIL_TRANSPORT_TYPE_NETANALYZER;     //HIL_TRANSPORT_TYPE_MARSHALLER;
    tLayerData.pfnHandler = HilMarshallerHandlePacket;
    tLayerData.pfnDeinit  = HilMarshallerDeInitModul;
    tLayerData.pfnCloseDev= HilMarshallerCloseUsedDevices;
    tLayerData.pvUser     = ptInstance;
    tLayerData.pfnPoll    = NULL;

    ptInstance->tDRVFunctions = ptConfig->tDRVFunctions;
    TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_driver_information");
    if( (NETANA_NO_ERROR==ptInstance->tDRVFunctions.pfn_netana_driver_information( sizeof(tNetAnaDriverInfo),&tNetAnaDriverInfo)))//NETANA_NO_ERROR == ptInstance->tDRVFunctions.pfnxDriverOpen(&ptInstance->hDriver)) &&
      //(NETANA_NO_ERROR == ptInstance->tDRVFunctions.pfnxDriverGetInformation(ptInstance->hDriver, sizeof(tDriverInfo), &tDriverInfo)) )
    {
      /* set device filter */
      NETANA_MNGMT_SET_DEV_CLASS_FILTER_IN_T tDeviceClassFilter;
      tDeviceClassFilter.ulDeviceClass = NETANA_DEV_CLASS_NANL_500 | NETANA_DEV_CLASS_NSCP_100 | NETANA_DEV_CLASS_CIFX;

      eRet = ptInstance->tDRVFunctions.pfn_netana_mngmt_exec_cmd(NETANA_MNGMT_CMD_SET_DEV_CLASS_FILTER,
                                          &tDeviceClassFilter,    sizeof(tDeviceClassFilter),
                                          NULL, 0);

      if(0 != (ptInstance->ptDevices = OS_MALLOC(sizeof(*ptInstance->ptDevices) * tNetAnaDriverInfo.ulCardCnt)))
      {
        uint32_t                  ulBoard;
        PMARSH_netANA_DEVICE_DATA_T ptDevice = ptInstance->ptDevices;

        memset(ptInstance->ptDevices, 0, sizeof(*ptInstance->ptDevices) *tNetAnaDriverInfo.ulCardCnt);
        ptInstance->ulDeviceCnt = tNetAnaDriverInfo.ulCardCnt;

        for(ulBoard = 0; ulBoard < tNetAnaDriverInfo.ulCardCnt; ulBoard++)
        {
          TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_enum_device for TCP_init");
          if(NETANA_NO_ERROR == ptInstance->tDRVFunctions.pfn_netana_enum_device(ulBoard,sizeof(ptDevice->tBoardInfo),&ptDevice->tBoardInfo))
          {
            // we do not breakbut walk through all devices

          }
          ptDevice++;
        }
      }

      eRet = HilMarshallerRegisterTransport(pvMarshaller, &tLayerData);

    } else
    {
      eRet = (uint32_t)NETANA_DRIVER_NOT_RUNNING;
    }

    if(RESULT_OK != eRet)
    {
      HilMarshallerDeInitModul(ptInstance);
    }
  }

  return eRet;
}



/*****************************************************************************/
/*! Close used devices
 *    \param pvMarshHandle  Marshaller handle                                 */
/*****************************************************************************/
void HilMarshallerCloseUsedDevices(void* pvMarshHandle)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshHandle;

  TRACE_PRINT_TYPE(LOG_COM|LOG_NETANAAPI,"in CloseUsedDev");
  if(NULL != ptMarshaller->ptTransports)
  {
    uint32_t ulTrans;


    for(ulTrans = 0; ulTrans < ptMarshaller->ulTransports; ++ulTrans)
    {
      TRANSPORT_LAYER_DATA_T* ptTransport = &ptMarshaller->ptTransports[ulTrans];
      PMARSH_HANDLE_INSTANCE_T ptInstance = (PMARSH_HANDLE_INSTANCE_T) ptTransport->pvUser;

      /* stop capture and close device if open*/
      if (ptInstance->ptDevices->hDev != NULL)
      {
        uint32_t ulRet = 0;
        uint32_t ulState = 0;
        uint32_t ulError = 0;
        NETANA_HANDLE hDev = ptInstance->ptDevices->hDev; // debug temp helper workaround for kernel panik
        TRACE_PRINT_TYPE(LOG_NETANAAPI,"netana_get_state");
        netana_get_state(hDev, &ulState, &ulError);

        if (ulError != NETANA_NO_ERROR && ulState == NETANA_CAPTURE_STATE_RUNNING)
        {
          TRACE_PRINT_TYPE(LOG_ERR|LOG_NETANAAPI,"error while capturing found in CloseUsedDev 0x%X", ulError);
          while (ulState != NETANA_CAPTURE_STATE_STOP_PENDING)
          {
            TRACE_PRINT_TYPE(LOG_NETANAAPI,"sleep for 10ms then netana_get_state");
            usleep(100000);
            netana_get_state(hDev, &ulState, &ulError);
          }
        }
        /* stop capture */

        TRACE_PRINT_TYPE(LOG_NETANAAPI,"CloseUsedDevices netana_stop_capture hDev: 0x%08X", hDev);
        ulRet = ptInstance->tDRVFunctions.pfn_netana_stop_capture(hDev); // workaround for kernal pannik if we dnont have a statekallback
        TRACE_PRINT_TYPE(LOG_NETANAAPI,"CloseUsedDevices stop_capture returned: 0x%08X", ulRet);

        /* close device */
        TRACE_PRINT_TYPE(LOG_NETANAAPI,"CloseUsedDevices netana_close_device");
        ulRet = ptInstance->tDRVFunctions.pfn_netana_close_device(hDev);
        TRACE_PRINT_TYPE(LOG_NETANAAPI,"CloseUsedDevices close_device returned: 0x%08X", ulRet);

        if (ulRet == 0)
        {
          ptInstance->ptDevices->hDev  = NULL;
        }
      }
      else
      {
        TRACE_PRINT_TYPE(LOG_NETANAAPI,"CloseUsedDevices no handle for device");
      }
    }
  }
  else
  {
    TRACE_PRINT_TYPE(LOG_NETANAAPI,"no more transports");
  }
}


/*****************************************************************************/
/*! De-Initialize Marshaller
 *   \param pvUser Transport data                                             */
/*****************************************************************************/
void HilMarshallerDeInitModul( void* pvUser )
{
  PMARSH_HANDLE_INSTANCE_T ptInstance = (PMARSH_HANDLE_INSTANCE_T) pvUser;
  uint32_t               ulDevice;

  if(NULL != ptInstance)
  {
    /* Check, that all structures are cleaned */
    for(ulDevice = 0; ulDevice < ptInstance->ulDeviceCnt; ++ulDevice)
    {
      PMARSH_netANA_DEVICE_DATA_T ptDevice = &ptInstance->ptDevices[ulDevice];

      if(NULL != ptDevice->ptChannels)
        OS_FREE(ptDevice->ptChannels);
    }


    if(NULL != ptInstance->ptDevices)
      OS_FREE(ptInstance->ptDevices);
    OS_FREE(ptInstance);

  }
  TRACE_PRINT("Done with HilMarshallerDeInitModul");
}

/*****************************************************************************/
/*! Handle incoming packets
 *   \param pvMarshaller Marshaller instance this packet was received from
 *   \param ptBuffer     Pointer receive buffer (also used for response packet)
 *   \param pvUser       Pointer to netANA Internal instance data
 *   \return NETANA_MARSHALLER_NO_ERROR on success                                                                    */
/*****************************************************************************/
void HilMarshallerHandlePacket( void* pvMarshaller, HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser )
{
  PNETANA_MARSHALLER_DATA_FRAME_HEADER_T ptMarshallerHeader  = (PNETANA_MARSHALLER_DATA_FRAME_HEADER_T) &ptBuffer->abData[0];
  int32_t                         lRet;
  TRACE_PRINT_TYPE(LOG_NETANAAPI,"entering HilMarshallerHandlePacket");
  /* Check Communication */;
  if( (ptMarshallerHeader->ulHandle == 0) ||
      ((HANDLE_GET_OBJTYPE(ptMarshallerHeader->ulHandle) == NETANA_MARSHALLER_OBJECT_TYPE_COMMUNICATION)
          && (HANDLE_IS_VALID(ptMarshallerHeader->ulHandle))))
  {
    /* This is a request for the Communication */
    //TRACE_ENTER("entering HandleCommunicationCommand");
    lRet = HandleCommunicationCommand(ptBuffer);
    //TRACE_EXIT("leave HandleCommunicationCommand");

  }else if(!HANDLE_IS_VALID(ptMarshallerHeader->ulHandle))
  {
    /* This is not a valid handle, so reject */
    // TRACE_PRINT("HANDLE_IS_VALID");
    lRet = NETANA_INVALID_HANDLE;
    ptMarshallerHeader->ulDataSize = 0;

  }else
  {
    /* Check object type */
    switch(HANDLE_GET_OBJTYPE(ptMarshallerHeader->ulHandle))
    {
    case NETANA_MARSHALLER_OBJECT_TYPE_DRIVER:
      //// TRACE_PRINT("NETANA_MARSHALLER_OBJECT_TYPE_DRIVER Object in HilMarshallerHandlePacket");
      lRet = HandleDriverCommand(ptBuffer, pvUser);
      break;

    case NETANA_MARSHALLER_OBJECT_TYPE_DEVICE:
      //// TRACE_PRINT("NETANA_MARSHALLER_OBJECT_TYPE_DEVICE Object in HilMarshallerHandlePacket");
      lRet = HandleSysdeviceCommand(ptBuffer, pvUser);
      break;

    case NETANA_MARSHALLER_OBJECT_TYPE_MNGMT:           // this is the new managment function
      //// TRACE_PRINT("NETANA_MARSHALLER_OBJECT_TYPE_MNGMT Object in HilMarshallerHandlePacket");
      lRet = HandleManagementCommand(ptBuffer, pvUser);
      break;

      /* case NETANA_MARSHALLER_OBJECT_TYPE_CHANNEL:
        lRet = HandleChannelCommand(ptBuffer, pvUser);
        break;*/

    default:
      /* Unsupported Object Type */
      // TRACE_PRINT("unsopported object in HilMarshallerHandlePacket");
      lRet = NETANA_INVALID_HANDLE;
      ptMarshallerHeader->ulDataSize = 0;
      break;
    }
  }

  /* Enter marshaller return code into answer */
  ptBuffer->tMgmt.ulUsedDataBufferLen                = ptMarshallerHeader->ulDataSize + sizeof(*ptMarshallerHeader);
  ptMarshallerHeader->ulError                        = lRet;
  SEQ_SET_RESPONSE(ptMarshallerHeader->ulSequence);
  //ptMarshallerHeader->ulSequence =  0;

  /* Call send function, to send a answer  */
  HilMarshallerConnTxData(pvMarshaller, ptBuffer->tMgmt.ulConnectorIdx , ptBuffer);
}

/*****************************************************************************/
/*! Handle  packets which includes a class factory command
 *   \param ptBuffer  Reference to the give marshaller packet
                    print Note: The given reference is also used to save the confirmation
 *   \return NETANA_MARSHALLER_NO_ERROR  on success                                  */
/*****************************************************************************/
static int32_t HandleCommunicationCommand ( HIL_MARSHALLER_BUFFER_T* ptBuffer)
{
  int32_t                         lRet;
  PNETANA_MARSHALLER_DATA_FRAME_HEADER_T ptMarshallerHeader  = (PNETANA_MARSHALLER_DATA_FRAME_HEADER_T) &ptBuffer->abData[0];

  switch(ptMarshallerHeader->ulMethodID)
  {
  case NETANA_MARSHALLER_COM_METHODID_SERVERVERSION:
  {
    PCOM_SERVERVERSION_CNF_T ptServerVersionCnf = (PCOM_SERVERVERSION_CNF_T)ptMarshallerHeader;

    /* Check Size of buffer */
    if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof( NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= sizeof(ptServerVersionCnf->tData))
    {
      // create version of server to tell client
      uint32_t ulVersion = 0x00000000;
      ulVersion = ( 0x00000000  | ( (  VERSION_MAJOR  << ( 5*4 ) )       // schift to 5th position
          |   (  VERSION_MINOR  << ( 4*4 ) )       // to 4th
          |   (  VERSION_BUILD  << ( 3*4 ) )       // to 3rd
          |   (  VERSION_REVISION          ) ) );  // least signifficant

      ptServerVersionCnf->tData.ulVersion     = ulVersion;
      ptServerVersionCnf->tHeader.ulDataSize  = sizeof(COM_SERVERVERSION_CNF_DATA_T);
      lRet                                    = NETANA_NO_ERROR;
    }else
    {
      lRet = NETANA_INVALID_PARAMETER;
      ptMarshallerHeader->ulDataSize = 0;
    }
  }
  break;

  case NETANA_MARSHALLER_COM_METHODID_CREATEINSTANCE:
  {
    PCOM_CREATEINSTANCE_REQ_T ptCreateInstReq = (PCOM_CREATEINSTANCE_REQ_T)ptMarshallerHeader;
    PCOM_CREATEINSTANCE_CNF_T ptCreateInstCnf = (PCOM_CREATEINSTANCE_CNF_T)ptMarshallerHeader;

    if(ptMarshallerHeader->ulDataSize != sizeof(ptCreateInstReq->tData))
    {
      lRet = NETANA_INVALID_PARAMETER;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      switch(ptCreateInstReq->tData.ulObjectType)
      {
      case NETANA_MARSHALLER_OBJECT_TYPE_COMMUNICATION:
        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= sizeof(ptCreateInstCnf->tData))
        {
          ptCreateInstCnf->tData.uHandle.ulHandle                       = 0;
          HANDLE_SET_OBJTYPE(ptCreateInstCnf->tData.uHandle.ulHandle, NETANA_MARSHALLER_OBJECT_TYPE_COMMUNICATION);
          HANDLE_SET_VALID(ptCreateInstCnf->tData.uHandle.ulHandle);
          ptCreateInstCnf->tHeader.ulDataSize                   = sizeof(ptCreateInstCnf->tData);
          lRet                                                  = NETANA_NO_ERROR;
        }else

        {
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
        break;

      case NETANA_MARSHALLER_OBJECT_TYPE_DRIVER:
        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= sizeof(ptCreateInstCnf->tData))
        {
          ptCreateInstCnf->tData.uHandle.ulHandle = 0;
          HANDLE_SET_OBJTYPE(ptCreateInstCnf->tData.uHandle.ulHandle, NETANA_MARSHALLER_OBJECT_TYPE_DRIVER);
          HANDLE_SET_VALID(ptCreateInstCnf->tData.uHandle.ulHandle);
          ptCreateInstCnf->tHeader.ulDataSize                  = sizeof(ptCreateInstCnf->tData);
          lRet = NETANA_NO_ERROR;
        } else
        {
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
        break;

      case NETANA_MARSHALLER_OBJECT_TYPE_MNGMT:
        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= sizeof(ptCreateInstCnf->tData))
        {
          ptCreateInstCnf->tData.uHandle.ulHandle = 0;
          HANDLE_SET_OBJTYPE(ptCreateInstCnf->tData.uHandle.ulHandle, NETANA_MARSHALLER_OBJECT_TYPE_MNGMT);
          HANDLE_SET_VALID(ptCreateInstCnf->tData.uHandle.ulHandle);
          ptCreateInstCnf->tHeader.ulDataSize                  = sizeof(ptCreateInstCnf->tData);
          lRet = NETANA_NO_ERROR;
        } else
        {
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
        break;

      default:
        lRet = NETANA_INVALID_PARAMETER;
        ptMarshallerHeader->ulDataSize = 0;
        break;
      }
    }
  }
  break;

  default:
    lRet = NETANA_TRANSPORT_UNSUPPORTED_FUNCTION;
    ptMarshallerHeader->ulDataSize = 0;
    break;
  }

  return lRet;
}

/*****************************************************************************/
/*! Handle packets which includes a Managment command
 *   \param ptBuffer  Reference to the received packet
 *                    Note: The given memory of the packet is also
 *                          used to save the confimation
 *   \param pvUser       Pointer to netANA Internal instance data
 *   \return NETANA_MARSHALLER_NO_ERROR  on success                                  */
/*****************************************************************************/
static int32_t HandleManagementCommand ( HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser)
{
  int32_t                         lRet;
  PNETANA_MARSHALLER_DATA_FRAME_HEADER_T ptMarshallerHeader  = (PNETANA_MARSHALLER_DATA_FRAME_HEADER_T) &ptBuffer->abData[0];
  PMARSH_HANDLE_INSTANCE_T        ptInstance                 = (PMARSH_HANDLE_INSTANCE_T) pvUser;

  switch(ptMarshallerHeader->ulMethodID)
  {
  /***************************************************************************
   * netana_mngmt_exec_cmd (blink)
   ***************************************************************************/
  case NETANA_MARSHALLER_MNGMT_BLINK:
  {
    PMNG_BLINK_REQ_T            ptReq   = (PMNG_BLINK_REQ_T)(ptMarshallerHeader);
    void*                       pvOutParam = NULL;
    uint32_t                    ulOutSize  = 0;

    if(!ptInstance->tDRVFunctions.pfn_netana_mngmt_exec_cmd)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      /*// debug printout
        char szMSG[255]= {{0}};
        wsprintfA(szMSG, "netANALYZER is BLINKING");
        MessageBoxA( NULL,(LPCSTR)szMSG,
                (LPCSTR)"API BLINK",
                MB_ICONINFORMATION | MB_OK  | MB_DEFBUTTON2); //MB_CANCELTRYCONTINUE 
       */
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_mngmt_exec_cmd Blink");
      lRet = ptInstance->tDRVFunctions.pfn_netana_mngmt_exec_cmd(NETANA_MARSHALLER_MNGMT_BLINK, ptReq->tData.szDevice ,ptReq->tData.ulSize, pvOutParam, ulOutSize);
    }
  }
  break;

  /***************************************************************************
   * netana_mngmt_exec_cmd (Feature)
   ***************************************************************************/
  case NETANA_MARSHALLER_MNGMT_GETDEVFEATURE:
  {
    PMNG_FEATURE_CNF_T                  ptCnf     = (PMNG_FEATURE_CNF_T)(ptMarshallerHeader);
    NETANA_MNGMT_GET_DEV_FEATURE_OUT_T  tOutParam = {0};
    NETANA_MNGMT_GET_DEV_FEATURE_IN_T   tFeatureIn = {0};
    uint32_t                            ulOutSize = sizeof(NETANA_MNGMT_GET_DEV_FEATURE_OUT_T);
    if(!ptInstance->tDRVFunctions.pfn_netana_mngmt_exec_cmd)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_mngmt_exec_cmd GETDEVFEATURE");
      tFeatureIn.hDev = ptInstance->ptDevices->hDev;
      lRet = ptInstance->tDRVFunctions.pfn_netana_mngmt_exec_cmd(NETANA_MARSHALLER_MNGMT_GETDEVFEATURE,
          &tFeatureIn ,sizeof(tFeatureIn),
          &tOutParam, ulOutSize);
      if (lRet == NETANA_NO_ERROR)
      {
        ptCnf->tData.tOut = tOutParam;
        ptCnf->tHeader.ulDataSize = sizeof(ptCnf->tData);
      }
    }
  }
  break;

  /***************************************************************************
   * netana_get_error_describtion
   ***************************************************************************/
  case NETANA_MARSHALLER_MNGMT_SCAN:
  {
    lRet = NETANA_TRANSPORT_UNSUPPORTED_FUNCTION ;
  }
  break;

  default:
    /* Unknown/unsupported method ID */
    lRet = NETANA_TRANSPORT_UNSUPPORTED_FUNCTION ; //lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    ptMarshallerHeader->ulDataSize = 0;
    break;
  }
  return lRet;
}

/*****************************************************************************/
/*! Returns all local IPv4 addresses
 *   \param
 *     inout   aulIPAddress   array of IPAddress where found ips are stored
 *     inout   ulINSize      in size of allocated array / out numbers of found IPs
 *   \return RESULT_OK on success                                             */
/*****************************************************************************/
uint32_t GetAllLocalIPsAsInt(uint32_t* aulIPAddress, uint32_t* ulINSize)
{
  struct ifaddrs * ifAddrStruct = NULL;
  struct ifaddrs * ifa = NULL;

  uint32_t ulIpCnt = 0;
  uint32_t ulSize = *ulINSize;
  void * tmpAddrPtr = NULL;
  uint32_t ret = 0;
  *ulINSize = 0;

  ret = getifaddrs(&ifAddrStruct);
  for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next) {
    if ( ifa->ifa_addr != NULL && ifa->ifa_addr->sa_family==AF_INET && strcmp(ifa->ifa_name, "lo") != 0) { // check it is IP4
      // is a valid IP4 Address and not loopback
      tmpAddrPtr = &((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
      if (ulIpCnt < ulSize)
      {
        aulIPAddress[ulIpCnt] = *((uint32_t*)tmpAddrPtr);
        ulIpCnt++;
      }
      else break;
    }
  }
  if (ifAddrStruct!=NULL) freeifaddrs(ifAddrStruct);
  *ulINSize = ulIpCnt;
  return ret;
}



/*****************************************************************************/
/*! Returns Local IP addresses
 *   \param  referenc IPAddress receives local ip address
 *   \return RESULT_OK on success                                              */
/*****************************************************************************/
/*uint32_t GetLocalIPAsInt(uint32_t* IPAddress)
{
  uint32_t eRet = RESULT_OK;
  char       szHostName[256];

  memset(szHostName, 0x00, sizeof(szHostName));

  if (gethostname(szHostName, sizeof(szHostName)) == SOCKET_ERROR)
  {
    eRet = errno;
  } else
  {
    struct hostent *he = gethostbyname(szHostName);
    if (he == NULL)
    {
      eRet = errno;
    }
    else
    {
      struct in_addr addr;
      //char*  pszIP = NULL;
      memcpy(&addr, he->h_addr_list[0], sizeof(struct in_addr));
 *IPAddress = addr.s_addr; //.S_un.S_addr;

    }
  }

  return eRet;
}

 */

/************************************************************************************/
/*! GetSubnetMaskOfIp gets SubnetMask by IP of the interface
 *   \param
 *       pSubnetMask out: Reference to subnetmask of ip
 *       uiIP        in: numof elements of input / num of valid elemnts in paMacAddr    */
/************************************************************************************/
void GetSubnetMaskOfIP(uint32_t *pSubnetMask, uint32_t uiIp)
{
  struct ifaddrs * ifAddrStruct = NULL;
  struct ifaddrs * ifa = NULL;
  void * tmpAddrPtr=NULL;

  getifaddrs(&ifAddrStruct);

  for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next) {
    if (ifa->ifa_addr != NULL && ifa->ifa_addr->sa_family==AF_INET) { // check it is IP4
      // is a valid IP4 Address
      tmpAddrPtr = &((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
      if (uiIp == *((uint32_t*)tmpAddrPtr)){
        // found matching Ip
        memcpy((void*)pSubnetMask, (void*)&((struct sockaddr_in *)ifa->ifa_netmask)->sin_addr, 4);
        break;
      }
    }
  }
  if (ifAddrStruct!=NULL) freeifaddrs(ifAddrStruct);
  return;
}


/************************************************************************************/
/*! GetInterfaceNameOfIP gets InterfaceName by IP of the interface in ASCII
 *   \param
 *       szInterfaceName inout:  pointer to interfaceName buffer (char)
 *       ulSize          inout:  Size of the buffer / Size of the returned string
 *       uiIP            in:     specific ip   */
/************************************************************************************/
void GetInterfaceNameOfIP(char *szInterfaceName, uint32_t *ulINSize, uint32_t uiIp)
{
  struct ifaddrs * ifAddrStruct = NULL;
  struct ifaddrs * ifa = NULL;
  void * tmpAddrPtr=NULL;
  uint32_t ulSize = *ulINSize;
  *ulINSize = 0;

  getifaddrs(&ifAddrStruct);

  for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next) {
    if (ifa->ifa_addr != NULL && ifa->ifa_addr->sa_family==AF_INET) { // check it is IP4
      // is a valid IP4 Address
      tmpAddrPtr = &((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
      if (uiIp == *((uint32_t*)tmpAddrPtr)){
        // found matching Ip
        *ulINSize = ulSize;
        if (strlen(ifa->ifa_name) < ulSize)
          *ulINSize = strlen(ifa->ifa_name);
        memcpy(szInterfaceName, ifa->ifa_name, *ulINSize);
        break;
      }
    }
  }
  if (ifAddrStruct!=NULL) freeifaddrs(ifAddrStruct);
  return;
}

/************************************************************************************/
/*! GetMacAddress gets Mac Addresses by IP of the interface
 *   \param
 *       paMacAddr   out: pointer to macadr (tEthAddr MacAddr)
 *       uiIP        in: numof elements of input / num of valid elemnts in paMacAddr    */
/************************************************************************************/
void GetMacAddressOfIP(ETH_ADDRESS *paMacAddr, uint32_t uiIp)
{
  struct ifreq buffer;
  uint32_t ulIfNameSize = 64;
  char    szInterfaceName[64] = {0};
  GetInterfaceNameOfIP(szInterfaceName, &ulIfNameSize, uiIp);

  int s = socket(AF_INET, SOCK_DGRAM, 0);
  strcpy(buffer.ifr_name, szInterfaceName);
  ioctl(s, SIOCGIFHWADDR, &buffer);
  close(s);
  memcpy(paMacAddr, buffer.ifr_hwaddr.sa_data, 6);
}

/************************************************************************************/
/*! get Gateway Firmware string from OS_release file VERSION_ID /etc/os_release
 *   \param  szPath          [in]   Path to the file
 *   \param  szTargetBuff    [in]   pointer to buffer where the string is put
 *   \parma  ulTargetBuffLen [in]   length of target buffer
 *   \return Returns NETANA_NO_ERROR on succes or NETANA_FUNCTION_FAILED  */
/************************************************************************************/
int32_t GetVersionString(char* szPath, char* szTargetBuff, uint32_t ulTargetBuffLen)
{
  char* pcRes = NULL;
  char szOsLine[MAX_OS_INFO_LEN] = {0};
  uint32_t ulScanlen = 0;
  FILE* f = NULL;
  if (
      (szTargetBuff    == NULL) ||
      (ulTargetBuffLen == 0)
     )
  {
   return NETANA_FUNCTION_FAILED;
  }
  memset(szTargetBuff, 0, ulTargetBuffLen);
  ulScanlen = min(ulTargetBuffLen, MAX_OS_INFO_LEN);

  f = fopen(szPath, "r");
  if (f == NULL)
   return NETANA_FUNCTION_FAILED;

  while (1)
  {
   pcRes = fgets(szOsLine, ulScanlen, f);
   if (pcRes == NULL)
   {
     // if fgets returns NULL we reached end of file
     break;
   }
   // example text "VERSION_ID="1.0.1.8.passive-fieldbus-BETA"
   /* \"%[^\n\"]\" this expression tells scanf to extract a
    * string only ending with newlines or quotation marks and including
    * whitespaces in opposition to the default behavior where a whitespace terminates a string */
   sscanf(szOsLine,"VERSION_ID = \"%[^\n\"]\"", szTargetBuff);
  }
  fclose(f);
  return NETANA_NO_ERROR;
}

/************************************************************************************/
/*! get linux Image version of the version file /opt/version
 *   \param
 *       output uint32_t* pulMajor,     Major,
 *       output uint32_t* pulMinor,     Minor,
 *       output uint32_t* pulBuild,     Build,
 *       output uint32_t* pulRevision   Revision
 *       returns NETANA_NO_ERROR on succes or NETANA_FUNCTION_FAILED  */
/************************************************************************************/
uint32_t GetImageVersion(uint32_t* pulMajor, uint32_t* pulMinor, uint32_t* pulBuild, uint32_t* pulRevision)
{
  char s[MAX_VERSION_LEN] = {0};
  char* pcRes = NULL;
  FILE* f = NULL;

  if (
      (pulMajor    != NULL) &&
      (pulMinor    != NULL) &&
      (pulBuild    != NULL) &&
      (pulRevision != NULL)
  )
  {
    memset(pulMajor,    0, sizeof(uint32_t));
    memset(pulMinor,    0, sizeof(uint32_t));
    memset(pulBuild,    0, sizeof(uint32_t));
    memset(pulRevision, 0, sizeof(uint32_t));
  }
  else
    return NETANA_FUNCTION_FAILED;

  f = fopen(VERSION_FILE_PATH, "r");
  if (f == NULL)
    return NETANA_FUNCTION_FAILED;

  while (1)
  {
    pcRes = fgets(s, MAX_VERSION_LEN, f);
    if (pcRes == NULL)
    {
      // if fgets returns NULL we reached end of file
      break;
    }
    // example text "Version 1.0.4.0\0"
    sscanf(s,"Version %d.%d.%d.%d", pulMajor, pulMinor, pulBuild, pulRevision);
  }
  fclose(f);
  return NETANA_NO_ERROR;
}


/*****************************************************************************/
/*! FillDeviceInfoExtension fills deviceinfo extension with system 
 *      specific information
 *   \param ptDeviceInfo  pointer to deviceinformation                        */
/*****************************************************************************/
void FillDeviceInfoExtension(NETANA_DEVICE_INFORMATION_T* ptDeviceInfo, int iSock)
{
  // TODO: check to choos the correct ip not a random there could be more than one interface and likely more addresse per interface 
  uint32_t      ulIPAddress;
  uint32_t      ulSubnetMask = 0;

  //OSVERSIONINFO osinfo;
#ifndef TARGET_IOTGW
  struct utsname osinfo;
#endif

  ETH_ADDRESS   aEthAddr[10];
  unsigned long ulSize      = 10;
  long          lRet        = 0;
  int           iRet        = 0;

  /* fill extension */
  // local ip 

  ptDeviceInfo->ulExtendedInfoType = 0x00476245;                              //  "GbE"
  ptDeviceInfo->ulExtendedInfoSize = sizeof(ptDeviceInfo->tExtendedInfo);

  if (iSock == -1) {
    uint32_t ulInSize = 1;
    lRet = GetAllLocalIPsAsInt(&ulIPAddress, &ulInSize); // GetLocalIPAsInt(&ulIPAddress); //TCPConnectorGetLocalIPAsInt
    //printf("identifying as IP: %s\n", inet_ntoa(*(struct in_addr*)&ulIPAddress));
    if (!lRet || ulInSize == 0){     // if error --> skip copying
      memcpy(ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.abIpAddr, &ulIPAddress, 4);
    }
  } else {
    /* we have a socket so we try to get the real ip form it */
    struct sockaddr_in tSockaddr;
    int iAddrLen = sizeof(tSockaddr);  /* sockaddr_in is padded to size of sockaddr  */
    iRet = getsockname(iSock, (struct sockaddr *)&tSockaddr, &iAddrLen);
    //printf("connected on server IP: %s:%d\n", inet_ntoa(tSockaddr.sin_addr), ntohs(tSockaddr.sin_port));
    if (iRet == 0){     // if error --> skip copying
      memcpy(ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.abIpAddr, &tSockaddr.sin_addr, 4);
    }
  }
  // local subnetmask 
  GetSubnetMaskOfIP(&ulSubnetMask, ulIPAddress);
  if (ulSize != 0)   
    memcpy(ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.abSubnetMask, &ulSubnetMask, 4);

  // local macAddress 
  // todo: need mac addr of the connected ip addr
  ulSize = 10;
  GetMacAddressOfIP(aEthAddr, ulIPAddress); // could get 10 mac addresses but needs the correct
  if (ulSize != 0) 
    memcpy(ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.abMacAddr, aEthAddr[0], 6);     

  // ServerVersion 
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulServerVersionMajor    = VERSION_MAJOR;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulServerVersionMinor    = VERSION_MINOR;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulServerVersionBuild    = VERSION_BUILD;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulServerVersionRevision = VERSION_REVISION;


  NETANA_DRIVER_INFORMATION_T tDriverInfo = {0};
  TRACE_PRINT_TYPE(LOG_NETANAAPI,"netana_driver_information in FillDeviceInfoExtension for enum_device");
  netana_driver_information(sizeof(NETANA_DRIVER_INFORMATION_T),&tDriverInfo);
  // DriverVersion
  // filled from driverpart of device info
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulDrvVersionMajor = tDriverInfo.ulVersionMajor;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulDrvVersionMinor = tDriverInfo.ulVersionMinor;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulDrvVersionBuild = tDriverInfo.ulVersionBuild;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulDrvVersionRevision = tDriverInfo.ulVersionRevision;

  // Toolkit version fillde by driver
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulToolkitVersionMajor = tDriverInfo.ulToolkitVersionMajor;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulToolkitVersionMinor = tDriverInfo.ulToolkitVersionMinor;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulToolkitVersionBuild = tDriverInfo.ulToolkitVersionBuild;
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulToolkitVersionRevision = tDriverInfo.ulToolkitVersionRevision;

  /* Image version information of this remote device  */
  GetImageVersion(
      &ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulOSMajorVersion,
      &ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulOSMinorVersion,
      &ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulOSBuildNumber ,
      &ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulOSPlatformId
  );

  /* OS version string */
#ifdef TARGET_IOTGW
  GetVersionString(OS_RELEASE_PATH,
                   ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.szCSDVersion,
                   sizeof(ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.szCSDVersion));
#else
  uname(&osinfo);
  ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.ulOSVersionInfoSize = sizeof(osinfo);
  memcpy( ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.szCSDVersion, osinfo.version, sizeof(ptDeviceInfo->tExtendedInfo.tGBEExtendedInfo.szCSDVersion));
#endif
}

/* return socket associatet with this buffer; for ip in device information */
int getSocketFromBuff(HIL_MARSHALLER_BUFFER_T* ptBuffer){
  int iSock = -1;
  switch(0){
    default:{
      if (ptBuffer == NULL)
        break;
      HIL_MARSHALLER_DATA_T* ptMarshaller = ptBuffer->tMgmt.pvMarshaller;
      if (ptMarshaller == NULL)
        break;
      CONNECTOR_DATA_T tConData = ptMarshaller->atConnectors[ptBuffer->tMgmt.ulConnectorIdx];
      HIL_MARSHALLER_CONNECTOR_T tConn = tConData.tConn;
      TCP_CONN_INTERNAL_T* ptTcpData = (TCP_CONN_INTERNAL_T*)tConn.pvUser;
      if (ptTcpData == NULL)
        break;
      iSock = ptTcpData->hClient;
    }
  }
  return iSock;
}



/*****************************************************************************/
/*! Handle packets which includes a driver command
 *   \param ptBuffer  Reference to the received packet
 *                    Note: The given memory of the packet is also
 *                          used to save the confimation
 *   \param pvUser       Pointer to netANA Internal instance data
 *   \return NETANA_MARSHALLER_NO_ERROR  on success                                  */
/*****************************************************************************/
static int32_t HandleDriverCommand ( HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser)
{
  int32_t                         lRet;
  PNETANA_MARSHALLER_DATA_FRAME_HEADER_T ptMarshallerHeader  = (PNETANA_MARSHALLER_DATA_FRAME_HEADER_T) &ptBuffer->abData[0];
  PMARSH_HANDLE_INSTANCE_T        ptInstance          = (PMARSH_HANDLE_INSTANCE_T) pvUser;

  switch(ptMarshallerHeader->ulMethodID)
  {
  /***************************************************************************
   * netana_driver_information
   ***************************************************************************/
  case NETANA_MARSHALLER_DRV_METHODID_GETINFO:
  {
    PDRV_GETINFO_REQ_T            ptReq = (PDRV_GETINFO_REQ_T)(ptMarshallerHeader);
    NETANA_DRIVER_INFORMATION_T   tDriverInfo;

    if(!ptInstance->tDRVFunctions.pfn_netana_driver_information)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_driver_information");
      lRet = ptInstance->tDRVFunctions.pfn_netana_driver_information( sizeof(tDriverInfo), &tDriverInfo);
      if(NETANA_NO_ERROR == lRet)
      {
        uint32_t ulCopyLen = min(sizeof(tDriverInfo), ptReq->tData.ulSize);

        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= ulCopyLen )
        {
          memset(&ptReq->tData, 0, sizeof(tDriverInfo));
          memcpy(&ptReq->tData, &tDriverInfo, ulCopyLen);
          ptReq->tHeader.ulDataSize = ulCopyLen;
        }else
        {
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
      }
    }
  }
  break;

  /***************************************************************************
   * netana_get_error_describtion
   ***************************************************************************/
  case NETANA_MARSHALLER_DRV_METHODID_ERRORDESCR:
  {
    PDRV_ERRORDESCR_REQ_T   ptReq     = (PDRV_ERRORDESCR_REQ_T)(ptMarshallerHeader);
    void*                   pvErrDes  = OS_MALLOC(ptReq->tData.ulSize); //ErrorDescription
    char*                   szErrDes  = (char*)pvErrDes;

    if(!ptInstance->tDRVFunctions.pfn_netana_get_error_description)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_get_error_description ");
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_error_description( (int)ptReq->tData.ulError,  ptReq->tData.ulSize,  szErrDes);
      if(NETANA_NO_ERROR == lRet)
      {

        uint32_t ulStrLen= strlen(szErrDes);

        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= ulStrLen + 1 )
        {
          memset(&ptReq->tData, 0, (ulStrLen + 1));
          memcpy(&ptReq->tData, szErrDes, (ulStrLen + 1));
          ptReq->tHeader.ulDataSize = (ulStrLen + 1);
        }else
        {
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
      }
    }
  }
  break;

  /***************************************************************************
   * netana_enum_device
   ***************************************************************************/
  case NETANA_MARSHALLER_DRV_METHODID_ENUMDEV:
  {
    PDRV_ENUMDEV_REQ_T          ptReq       = (PDRV_ENUMDEV_REQ_T)(ptMarshallerHeader);
    NETANA_DEVICE_INFORMATION_T tDeviceInfo;


    if(!ptInstance->tDRVFunctions.pfn_netana_enum_device)
    {
      /* API Function not found */
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      /* this call is extended lenght because the device driver supports it */
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_enum_device %d", ptReq->tData.ulBoard);
      lRet = ptInstance->tDRVFunctions.pfn_netana_enum_device(ptReq->tData.ulBoard, sizeof(tDeviceInfo), &tDeviceInfo);
      if(NETANA_NO_ERROR == lRet)
      {
        unsigned long ulCopyLen   = 0;

        FillDeviceInfoExtension(&tDeviceInfo, getSocketFromBuff(ptBuffer));

        /* copy into sendbuffer*/
        ulCopyLen = min(sizeof(tDeviceInfo), ptReq->tData.ulSize);
        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= ulCopyLen )
        {
          /*set size of extended info */
          // sizeof(tDeviceInfo);

          memset(&ptReq->tData, 0, sizeof(tDeviceInfo));
          memcpy(&ptReq->tData, &tDeviceInfo, ulCopyLen);
          ptReq->tHeader.ulDataSize = ulCopyLen;
        }else
        {
          //not enough memory
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
      }// enum_device succes
    }// api function found
  }// case
  break;

  /***************************************************************************
   * netana_open_device
   ***************************************************************************/
  case NETANA_MARSHALLER_DRV_METHODID_OPENDEV:
  {
    PDRV_OPENDEV_REQ_T ptOpenReq  = (PDRV_OPENDEV_REQ_T)(ptMarshallerHeader);
    PDRV_OPENDEV_CNF_T ptOpenCnf  = (PDRV_OPENDEV_CNF_T)(ptMarshallerHeader);//{{0}}; // same buffer since there is only one, this is only for naming
    uint32_t           ulDataSize = ptMarshallerHeader->ulDataSize;

    uint32_t ulRecvDataSize=0;
    ulRecvDataSize = (uint32_t)(  strlen(ptOpenReq->tData.szBoardname)
        +1
        +sizeof(ptOpenReq->tData.ulBoardNameSize));


    ptMarshallerHeader->ulDataSize = 0;

    if(ulDataSize != ulRecvDataSize )
    {
      lRet = NETANA_INVALID_PARAMETER;

    } else if(!ptInstance->tDRVFunctions.pfn_netana_open_device)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;

    } else
    {

      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_open_device ");
      lRet = ptInstance->tDRVFunctions.pfn_netana_open_device( ptOpenReq->tData.szBoardname, &ptInstance->ptDevices->hDev);
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_open_device done lRet 0x%08X   Handle: 0x%X", lRet,ptInstance->ptDevices->hDev);
      if(lRet == NETANA_NO_ERROR || lRet == NETANA_DEVICE_STILL_OPEN)
      {
        ptOpenCnf->tData.uHandle.ulHandle = 0;

        HANDLE_SET_OBJTYPE(ptOpenCnf->tData.uHandle.ulHandle, NETANA_MARSHALLER_OBJECT_TYPE_DEVICE);
        HANDLE_SET_OBJIDX(ptOpenCnf->tData.uHandle.ulHandle, ptInstance->ptDevices->ulBoard);
        HANDLE_SET_VALID(ptOpenCnf->tData.uHandle.ulHandle);
        ptOpenCnf->tHeader.ulDataSize = sizeof(ptOpenCnf->tData);
      }
    }


  }
  break;

  /***************************************************************************
   * netana_close_device
   ***************************************************************************/
  case NETANA_MARSHALLER_DRV_METHODID_CLOSEDEV:
  {
    PDRV_CLOSEDEV_REQ_T ptCloseDevReq  = (PDRV_CLOSEDEV_REQ_T)(ptMarshallerHeader);
    uint32_t             ulDataSize = ptMarshallerHeader->ulDataSize;

    ptMarshallerHeader->ulDataSize = 0;

    if(ulDataSize != sizeof(ptCloseDevReq->tData))
    {
      lRet = NETANA_INVALID_PARAMETER;

    } else if(!ptInstance->tDRVFunctions.pfn_netana_close_device)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;

    } else
    {
      //close dev
      //clead handle in ptinstance
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_close_device with handle 0x%X", ptInstance->ptDevices->hDev);
      lRet = ptInstance->tDRVFunctions.pfn_netana_close_device(ptInstance->ptDevices->hDev);
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_close_device ret: 0x%X", lRet);
      if (lRet == 0)
      {
        ptInstance->ptDevices->hDev = 0;
      }
    }

  }
  break;

  default:
    /* Unknown/unsupported method ID */
    lRet = NETANA_TRANSPORT_UNSUPPORTED_FUNCTION ; //lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    ptMarshallerHeader->ulDataSize = 0;
    break;
  }

  return lRet;
}


/*****************************************************************************/
/*! Internal Callback data                                             */
/*****************************************************************************/
typedef struct CALLBACK_INTERNAL_Ttag
{
  //HIL_MARSHALLER_BUFFER_T*        ptBuffer;
  uint32_t                        ulConnIdx;
  HIL_MARSHALLER_DATA_T*          ptMarshaller;
  PMARSH_HANDLE_INSTANCE_T        ptInstance;  
  uint8_t                         bSequence;
  uint16_t                        sTransaction;
  uint16_t                        sDataType;
  uint32_t                        ulHandle;

} CALLBACK_INTERNAL_T, *PCALLBACK_INTERNAL_T;

/*****************************************************************************/
/*!StatusCallback
 *   \param ulCaptureState   State
 *   \param ulCaptureError   Error
 *   \param pvUser           Pointer to instance data
 *   \return NETANA_MARSHALLER_NO_ERROR  on success                                  */
/*****************************************************************************/
static void APIENTRY StatusCallback(uint32_t ulCaptureState, uint32_t ulCaptureError, void* pvUser)
{
  TRACE_ENTER_TYPE(LOG_CLB,"StatusCallback");
  TRACE_PRINT_TYPE(LOG_CLB|LOG_NETANAAPI,"enter StatusCallback CaptureState %d   ulCaptureError 0x%08X", ulCaptureState, ulCaptureError);
  //TRACE_PRINT2("State: %d Error: 0x%X",ulCaptureState,ulCaptureError);

  //sigset_t intmask;
  //sigfillset(&intmask);
  //TRACE_PRINT_TYPE(LOG_CLB,"Disable signals returned %d", sigprocmask(SIG_BLOCK, &intmask, NULL));

  long                            lRet                = NETANA_NO_ERROR;
  PCALLBACK_INTERNAL_T            ptCallbackInternal  = (PCALLBACK_INTERNAL_T)pvUser;
  //unsigned long                   ulConnector         = 0;
  //CONNECTOR_DATA_T*               ptConnector         = NULL;
  //HIL_MARSHALLER_DATA_T*          ptMarshaller        = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  //HIL_MARSHALLER_BUFFER_T*        ptBuffer            = NULL;
  CALLBACK_STATUS_REQ_T           tReq                = {{0}};
  PNETANA_MARSHALLER_DATA_FRAME_HEADER_T ptMarshallerHeader  = NULL;
  uint32_t                        ulHandle            = ptCallbackInternal->ulHandle;

  // write trace file if stop pending
  /*if(ulCaptureState == NETANA_CAPTURE_STATE_STOP_PENDING)
  {
    write_history_to_file( "CallbackTrace.csv",  &tCallbackHistory);
    write_history_to_file( "PortstatTrace.csv",  &tPortstatHistory);
  }*/

  /*we need a buffer */
  HIL_MARSHALLER_BUFFER_T*        ptBuffer;
  ptBuffer            = HilMarshallerGetBuffer(ptCallbackInternal->ptMarshaller, eMARSHALLER_TX_BUFFER, ptCallbackInternal->ulConnIdx );

  if (ptBuffer != NULL)
  {
    ptMarshallerHeader  = (PNETANA_MARSHALLER_DATA_FRAME_HEADER_T)&ptBuffer->abData[0];


    /*  Translate NETANA_CAPTURE_ERROR_NO_HOSTBUFFER to NETANA_CAPTURE_ERROR_ON_TARGET
                    so that error code is free to use on actual host */
    if (ulCaptureError == NETANA_CAPTURE_ERROR_NO_HOSTBUFFER)
      ulCaptureError = (uint32_t)NETANA_CAPTURE_ERROR_ON_TARGET;


    //put data in packet
    tReq.tData.ulCaptureError=ulCaptureError;
    tReq.tData.ulCaptureState=ulCaptureState;

    //generate marshallerframeheader
    tReq.tHeader.ulDataSize    = sizeof(tReq.tData);
    tReq.tHeader.ulHandle      = ulHandle;
    tReq.tHeader.ulError       = lRet;
    tReq.tHeader.ulHandle      = ptCallbackInternal->ulHandle;
    tReq.tHeader.ulMethodID    = NETANA_MARSHALLER_CALLBACK_METHODID_STATUS;
    tReq.tHeader.ulSequence    = 0;    //++ulSequence;       //if there was a sequence number to use we would use it here but this is similar to HandlePacket()

    /*asamble frame*/
    memset(ptBuffer->abData,0,sizeof(tReq));
    memcpy(ptBuffer->abData,&tReq,sizeof(tReq));  // same as ptCallbackInternal->ptBuffer->abData=&tReq;

    /* Enter data into answer */
    ptBuffer->tMgmt.ulUsedDataBufferLen       = ptMarshallerHeader->ulDataSize + sizeof(*ptMarshallerHeader);
    ptMarshallerHeader->ulError                                   = lRet;
    //SEQ_SET_REQUEST(ptMarshallerHeader->ulSequence);
    ptMarshallerHeader->ulSequence                                =  0;

    // generate transportheader
    ptBuffer->tTransport.bSequenceNr          = ptCallbackInternal->bSequence++;
    ptBuffer->tTransport.usTransaction        = ptCallbackInternal->sTransaction++;
    ptBuffer->tTransport.ulCookie             = HIL_TRANSPORT_COOKIE;
    ptBuffer->tTransport.usDataType           = ptCallbackInternal->sDataType;
    ptBuffer->tTransport.bChannel             = 0;
    ptBuffer->tTransport.bDevice              = 0;
    ptBuffer->tTransport.bState               = 0;
    ptBuffer->tTransport.usReserved           = 0;


    //if( tReq.tData.ulCaptureError) // debug breakpoint
    //uint32_t ulCaptureError = tReq.tData.ulCaptureError;


    TRACE_PRINT_TYPE(LOG_CLB,"pre HilMarshallerConnTxData in scb");
    /* Call send function, to send a answer  */
    HilMarshallerConnTxData(ptCallbackInternal->ptMarshaller, ptBuffer->tMgmt.ulConnectorIdx, ptBuffer);
    TRACE_PRINT_TYPE(LOG_CLB,"post HilMarshallerConnTxData in scb");
    //needs adjustment maybe chek on an example receive .. (sequenze number or last frame transmitted or ptbuffer save for later use)
  }
  else
  {
    TRACE_PRINT_TYPE(LOG_CLB,"ptBuffer was NULL in scb");
  }

  TRACE_PRINT_TYPE(LOG_CLB,"done StatusCallback CaptureState %d   ulCaptureError 0x%08X", ulCaptureState, ulCaptureError);
  //TRACE_PRINT_TYPE(LOG_CLB,"Enable all signals returned %d", sigprocmask(SIG_UNBLOCK, &intmask, NULL));
  TRACE_EXIT_TYPE(LOG_CLB,"StatusCallback\n");
}


unsigned short g_usDataCallbackCnt = 0;
struct timeval tv_lastTime = {0};


/*****************************************************************************/
/*TODO: check that acknowledge to callback by client 
  is not confused as a request or acknowledge to
  response of server confusion seems to origin in
  transaction and sequensnumber unchecked on server */
/*!DataCallback
 *   \param pvBuffer     Buffer with captured data
 *   \param ulDataSize   Lenght of data in buffer
 *   \param pvUser       Pointer to instance data
 *   \return NETANA_MARSHALLER_NO_ERROR  on success                                  */
/*****************************************************************************/

//extern uint32_t g_ulTempRxBufferKA;
//uint32_t g_ulTempRxBufferCB;
//extern uint32_t g_ulTempAckBuffer;

static void APIENTRY DataCallback(void* pvBuffer, uint32_t ulDataSize, void* pvUser) 
{
  //return;

  g_usDataCallbackCnt++;
  TRACE_ENTER_TYPE(LOG_CLB,"DataCallback");
  TRACE_PRINT_TYPE(LOG_CLB|LOG_NETANAAPI,"DataCallback %d",g_usDataCallbackCnt);


#ifdef _DBG
  /* TIMING OF DATACALLBACKS */
  static struct timeval tv_startcallback , tv_endcallback, tv_timeintevalcallback; // for cycletime
  struct timeval tv1, tv2;  // for send duration time
  tv_lastTime = tv_startcallback; // remember the last time the Datacallback was called
  gettimeofday(&tv_startcallback, NULL);
  //set_next_sample(&tCallbackHistory, tv_startcallback, 0xCA11BACC, &tPortstatHistory);

  /*   now we calculate the time that was in between the dataCallbacks
      current time - last time
      tv_timeintevalcallback = tv_startcallback - tv_lastTime;*/
  timersub(&tv_startcallback, &tv_lastTime, &tv_timeintevalcallback);
  uint64_t ullUSec = tv_timeintevalcallback.tv_sec * 1000000 + tv_timeintevalcallback.tv_usec;

  /* log if interval is more than 100 ms long */
  if (ullUSec > 100000 && tv_timeintevalcallback.tv_sec < 100) // prevent first time callback to trigger errorcondition
  {
    TRACE_PRINT("CALLBACK PAUSED VERY LONG #####################################################");
    TRACE_PRINT3("Callback interval sec: %d,%06d at calbacknr: %d", tv_timeintevalcallback.tv_sec, tv_timeintevalcallback.tv_usec, g_usDataCallbackCnt);
    /* write trace file */
    //write_history_to_file( "CallbackTrace.csv",  &tCallbackHistory);
    //write_history_to_file( "PortstatTrace.csv",  &tPortstatHistory);
  }
#endif

  uint32_t                        lRet                = NETANA_NO_ERROR;
  PCALLBACK_INTERNAL_T            ptCallbackInternal  = (PCALLBACK_INTERNAL_T)pvUser;
  //CALLBACK_DATA_REQ_T             tReq                = {{0}};
  unsigned long                   ulLength            = ulDataSize;

  void*                           pvBufferLatest      = pvBuffer;
  uint8_t*                        pbBufferLatest      = NULL;
  int                             iDataSizeLatest     = ulDataSize;
  int                             iDataSizeNow        = 0;
  HIL_MARSHALLER_BUFFER_T*        ptBuffer            = 0;
  PNETANA_MARSHALLER_DATA_FRAME_HEADER_T ptMarshallerHeader  = NULL;
  PCALLBACK_DATA_REQ_T            ptReq               = NULL;
  uint32_t                        ulDataBufferLen     = 0;

  //TRACE_PRINT1(" --> DATACALLBACK %d",g_usDataCallbackCnt);
  ptBuffer                                            = HilMarshallerGetBuffer(ptCallbackInternal->ptMarshaller, 
      eMARSHALLER_TX_BUFFER,
      ptCallbackInternal->ulConnIdx );
  TRACE_PRINT_TYPE(LOG_CLB,"getbuffer in DataCallback 0x%08X", (unsigned int)ptBuffer);
  if(ptBuffer == NULL)
  {
    fprintf(stderr,"HilMarshallerGetBuffer failed to alloc in datacallback\n");
  }
  else
  {

    //g_ulTempRxBufferCB = (uint32_t)ptBuffer;


    ptMarshallerHeader                                  = (PNETANA_MARSHALLER_DATA_FRAME_HEADER_T) &ptBuffer->abData[0];

    ptReq                                               = (PCALLBACK_DATA_REQ_T) &ptBuffer->abData[0];
    ulDataBufferLen                                     = ptBuffer->tMgmt.ulDataBufferLen;

    //put data in packet
    /*tReq.tData.ulCaptureError=ulCaptureError;
    tReq.tData.ulCaptureState=ulCaptureState;*/

    //generate marshallerframeheader

    while (iDataSizeLatest > 0)
    {
      TRACE_PRINT_TYPE(LOG_CLB,"iDataSizeLatest %d",iDataSizeLatest);
      iDataSizeNow = iDataSizeLatest;

      //check if buffer is sufficient
      if ((iDataSizeLatest + sizeof(*ptMarshallerHeader)) > ulDataBufferLen  )
        iDataSizeNow = ulDataBufferLen - sizeof(*ptMarshallerHeader) ;

      ptReq->tHeader.ulDataSize    = iDataSizeNow;
      ptReq->tHeader.ulError       = lRet;
      ptReq->tHeader.ulHandle      = ptCallbackInternal->ulHandle;
      ptReq->tHeader.ulMethodID    = NETANA_MARSHALLER_CALLBACK_METHODID_DATA;
      ptReq->tHeader.ulSequence    = 0;    //++ulSequence;       //if there was a sequence number to use we would use it here but this is similar to HandlePacket()

      /*cpy callbackdata into sendBuffer*/
      //performance check///////////////////////////////////////
      /*
      memset( &ptReq->tData, NULL,      iDataSizeNow);
      memcpy( &ptReq->tData, pvBufferLatest,  iDataSizeNow); */
      //ptCallbackInternal->ptBuffer->abData=pvBufferLatest;


      /* Enter data into answer */
      ptBuffer->tMgmt.ulUsedDataBufferLen       =  sizeof(*ptMarshallerHeader);
      //ptMarshallerHeader->ulError                                   = lRet;
      //SEQ_SET_REQUEST(ptMarshallerHeader->ulSequence);
      //ptMarshallerHeader->ulSequence                                =  0;

      // generate transportheader
      ptBuffer->tTransport.bSequenceNr          = ptCallbackInternal->bSequence++;
      ptBuffer->tTransport.usTransaction        = ptCallbackInternal->sTransaction++ | HIL_TRANSPORT_TRANSACTION_DEVICE;
      ptBuffer->tTransport.ulCookie             = HIL_TRANSPORT_COOKIE;
      ptBuffer->tTransport.usDataType           = ptCallbackInternal->sDataType;
      ptBuffer->tTransport.bChannel             = 0;
      ptBuffer->tTransport.bDevice              = 0;
      ptBuffer->tTransport.bState               = 0;
      ptBuffer->tTransport.usReserved           = g_usDataCallbackCnt;
      TRACE_PRINT_TYPE(LOG_COM,"bSequenceNr %d", ptBuffer->tTransport.bSequenceNr);
      TRACE_PRINT_TYPE(LOG_CLB,"g_usDataCallbackCnt %d",g_usDataCallbackCnt);

      /* Call send function, to send the data without copy of callbackdata*/
      // TRACE_PRINT1("Start send Sequence: %d", ptBuffer->tTransport.bSequenceNr);
#ifdef _DBG
      gettimeofday(&tv1, NULL);
#endif
      //set_next_sample(&tCallbackHistory, tv1, 0x00000001, &tPortstatHistory);
      TRACE_PRINT_TYPE(LOG_CLB,"pre HilMarshallerConnTxCallbackData in dcb");
      lRet = HilMarshallerConnTxCallbackData(ptCallbackInternal->ptMarshaller,
          ptBuffer->tMgmt.ulConnectorIdx,
          ptBuffer,
          pvBufferLatest,
          ulLength);
      TRACE_PRINT_TYPE(LOG_CLB,"post HilMarshallerConnTxCallbackData in dcb");
      if (lRet)
      {
        TRACE_PRINT_TYPE(LOG_CLB|LOG_ERR|LOG_COM,"error while sending datacallback");
        //fprintf(stderr,"error while sending datacallback");
        break;
      }

#ifdef _DBG
      gettimeofday(&tv2, NULL);
      //set_next_sample(&tCallbackHistory, tv2 , 0x00000002, &tPortstatHistory);

      uint64_t deltaT = (tv2.tv_sec * 1000000 + tv2.tv_usec) - (tv1.tv_sec * 1000000 + tv1.tv_usec);
      if(deltaT > 5000) // 5000 microsec == 5millisec
      {
        TRACE_PRINT_TYPE(LOG_CLB|LOG_COM,"send took %llu at callbacknr: %d", deltaT ,g_usDataCallbackCnt);
      }
#endif

      //if there is more data to send then set buffer to subsequent position for next loop
      pbBufferLatest  =   (uint8_t*)pvBufferLatest;
      pbBufferLatest  +=  iDataSizeNow;
      pvBufferLatest  =   (void*)pbBufferLatest;
      iDataSizeLatest -=  iDataSizeNow;
    }
  }
#ifdef _DBG
  gettimeofday(&tv_endcallback, NULL);
  //set_next_sample(&tCallbackHistory, tv_endcallback , 0x00000003, &tPortstatHistory);

  int64_t deltaT = (tv_endcallback.tv_sec * 1000000 + tv_endcallback.tv_usec) - (tv_startcallback.tv_sec * 1000000 + tv_startcallback.tv_usec);
  TRACE_PRINT_TYPE(LOG_CLB|LOG_COM|LOG_NETANAAPI,"Datacallback %d took %lld us", g_usDataCallbackCnt, deltaT);
  //TRACE_EXIT("DATACALLBACK");
#endif
  TRACE_EXIT_TYPE(LOG_CLB,"datacallback\n");
}



/*****************************************************************************/
/*! Handle packets which includes a Sysdevice command
 *   \param ptBuffer  Reference to the received packet
 *     Note: The given memory of the packet is also used to save the confirmation
 *   \param pvUser       Pointer to netANA Internal instance data
 *   \return NETANA_MARSHALLER_NO_ERROR  on success                                  */
/*****************************************************************************/
static int32_t HandleSysdeviceCommand (HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvUser)
{
  //TRACE_ENTER("HandleSysdeviceCommand");
  int32_t                         lRet = NETANA_NO_ERROR;
  PNETANA_MARSHALLER_DATA_FRAME_HEADER_T ptMarshallerHeader  = (PNETANA_MARSHALLER_DATA_FRAME_HEADER_T) &ptBuffer->abData[0];
  PMARSH_HANDLE_INSTANCE_T        ptInstance          = (PMARSH_HANDLE_INSTANCE_T) pvUser;
  //PMARSH_netANA_CHANNEL_DATA_T      ptChannel;
  //int tempidx;
  if((!ptBuffer) || (!pvUser))
  {
    // TRACE_PRINT("ptBuffer pvUser invalid");
    return HIL_MARSHALLER_E_INVALIDPARAMETER;
  }
  //// TRACE_PRINT1("Sequence: %d", ptBuffer->tTransport.bSequenceNr);

  //tempidx = HANDLE_GET_OBJSUBIDX(ptMarshallerHeader->ulHandle);

  if( (HANDLE_GET_OBJIDX(ptMarshallerHeader->ulHandle) > ptInstance->ulDeviceCnt)) //||
    //(HANDLE_GET_OBJSUBIDX(ptMarshallerHeader->ulHandle) != NETANA_MARSHALLER_SUBIDX_SYSTEMCHANNEL) )
  {
    // TRACE_PRINT("HANDLE_GET_OBJIDX invalid");
    ptMarshallerHeader->ulDataSize = 0;
    return NETANA_INVALID_HANDLE;
  }

  //ptChannel = &ptInstance->ptDevices[HANDLE_GET_OBJIDX(ptMarshallerHeader->ulHandle)].tSysDevice;

  switch(ptMarshallerHeader->ulMethodID)
  {
  /***************************************************************************
   * netana_device_info
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_INFO:
  {
    PDEV_INFO_REQ_T        ptReq = (PDEV_INFO_REQ_T)(ptMarshallerHeader);
    NETANA_DEVICE_INFORMATION_T tDeviceInfo = {{0}};

    if(!ptInstance->tDRVFunctions.pfn_netana_device_info)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_device_info ");
      lRet = ptInstance->tDRVFunctions.pfn_netana_device_info(ptInstance->ptDevices->hDev, sizeof(tDeviceInfo), &tDeviceInfo);
      if(NETANA_NO_ERROR == lRet)
      {
        uint32_t ulCopyLen = min(sizeof(tDeviceInfo), ptReq->tData.ulSize);

        FillDeviceInfoExtension(&tDeviceInfo, getSocketFromBuff(ptBuffer));   // system specific information about this systerm to be marshalled to host

        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= ulCopyLen )
        {
          memset(&ptReq->tData, 0, sizeof(tDeviceInfo));
          memcpy(&ptReq->tData, &tDeviceInfo, ulCopyLen);  // everything longer than ulCopyLen is truncated
          ptReq->tHeader.ulDataSize = ulCopyLen;
        }else
        {
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
      }
    }
  }
  break;

  /***************************************************************************
   * netana_get_portstat
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_PORTSTAT:
  {
    PDEV_PORTSTAT_REQ_T     ptReq = (PDEV_PORTSTAT_REQ_T)(ptMarshallerHeader);
    NETANA_PORT_STATE_T     tPortStat = {0};

    if(!ptInstance->tDRVFunctions.pfn_netana_get_portstat)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      //struct timeval tv1, tv2, tv_res;
      TRACE_PRINT1("pfn_netana_get_portstat port: %d", ptReq->tData.ulPort );
      /*gettimeofday(&tv1, NULL);
        set_next_sample(&tPortstatHistory, tv1, 0x10000000, &tCallbackHistory);*/
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_portstat(ptInstance->ptDevices->hDev,ptReq->tData.ulPort, sizeof(tPortStat), &tPortStat);
      /*gettimeofday(&tv2, NULL);
        set_next_sample(&tPortstatHistory, tv2, 0x20000000, &tCallbackHistory);
        timersub(&tv2, &tv1, &tv_res);
        uint64_t deltaT = (tv2.tv_sec * 1000000 + tv2.tv_usec) - (tv1.tv_sec * 1000000 + tv1.tv_usec);
        if(deltaT > 5000) // 1000 microsec == 1millisec
        {
          TRACE_PRINT2("portstat took %llu microsec at port: %d", deltaT ,ptReq->tData.ulPort);
        }*/
      if(NETANA_NO_ERROR == lRet)
      {
        TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_get_portstat success");
        uint32_t ulCopyLen = min(sizeof(tPortStat), ptReq->tData.ulSize);
        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= ulCopyLen )
        {
          memset(&ptReq->tData, 0, sizeof(tPortStat));
          memcpy(&ptReq->tData, &tPortStat, ulCopyLen);
          ptReq->tHeader.ulDataSize = ulCopyLen;
        }else
        {
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
      }
    }
  }
  break;

  /***************************************************************************
   * netana_get_state
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_GETSTATE:
  {
    //PDEV_GETSTATE_REQ_T     ptReq = (PDEV_GETSTATE_REQ_T)(ptMarshallerHeader);
    PDEV_GETSTATE_CNF_T     ptCnf = (PDEV_GETSTATE_CNF_T)(ptMarshallerHeader);
    uint32_t                ulCaptureState = 0;        /*< Returned capture state */
    uint32_t                ulCaptureError = 0;        /*< Returned capture error */

    if(!ptInstance->tDRVFunctions.pfn_netana_get_state)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_get_state ");
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_state(ptInstance->ptDevices->hDev, &ulCaptureState, &ulCaptureError);
      if(NETANA_NO_ERROR == lRet)
      {
        ptCnf->tData.ulCaptureError = ulCaptureError;
        ptCnf->tData.ulCaptureState = ulCaptureState;
        ptMarshallerHeader->ulDataSize = sizeof(ptCnf->tData);

      }else
      {
        ptMarshallerHeader->ulDataSize = 0;
      }
    }
  }
  break;

  /***************************************************************************
   * xSysdeviceGetMBXState
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_ACCESPHYREG:
  {
    PDEV_ACCESSPHYREG_REQ_T     ptReq   = (PDEV_ACCESSPHYREG_REQ_T)(ptMarshallerHeader);
    PDEV_ACCESSPHYREG_CNF_T     ptCnf   = (PDEV_ACCESSPHYREG_CNF_T)(ptMarshallerHeader);
    unsigned short              usValue = ptReq->tData.usValue;

    if(!ptInstance->tDRVFunctions.pfn_netana_access_phy_reg)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_access_phy_reg ");
      lRet = ptInstance->tDRVFunctions.pfn_netana_access_phy_reg( ptInstance->ptDevices->hDev,
          ptReq->tData.ulDirection,
          ptReq->tData.bPhyNum,
          ptReq->tData.bPhyReg,
          &usValue,
          ptReq->tData.ulTimeout);
      if(NETANA_NO_ERROR == lRet)
      {
        ptCnf->tData.usValue      = usValue;
        ptReq->tHeader.ulDataSize = sizeof(DEV_ACCESSPHYREG_CNF_DATA_T);
      }
      else
        ptMarshallerHeader->ulDataSize = 0;
    }
  }
  break;

  /***************************************************************************
   * netana_get_packet
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_GETPACKET:
  {
    PDEV_GETPACKET_REQ_T     ptReq   = (PDEV_GETPACKET_REQ_T)(ptMarshallerHeader);
    PDEV_GETPACKET_CNF_T     ptCnf   = (PDEV_GETPACKET_CNF_T)(ptMarshallerHeader);
    NETANA_PACKET            tPacket = {{0}};

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_get_packet)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_get_packet");
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_packet(  ptInstance->ptDevices->hDev,
          ptReq->tData.ulSize,
          &tPacket,
          ptReq->tData.ulTimeout);
      if(NETANA_NO_ERROR == lRet)
      {
        ptCnf->tData.tRecvPkt     = tPacket;
        ptReq->tHeader.ulDataSize = sizeof(DEV_GETPACKET_CNF_DATA_T);
      }
      else
        ptMarshallerHeader->ulDataSize = 0;
    }
  }
  break;

  /***************************************************************************
   * netana_put_packet
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_PUTPACKET:
  {
    PDEV_PUTPACKET_REQ_T     ptReq   = (PDEV_PUTPACKET_REQ_T)(ptMarshallerHeader);

    ptMarshallerHeader->ulDataSize = 0;

    if(!ptInstance->tDRVFunctions.pfn_netana_put_packet)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_put_packet");
      lRet = ptInstance->tDRVFunctions.pfn_netana_put_packet(  ptInstance->ptDevices->hDev,
          &ptReq->tData.tSendPkt,
          ptReq->tData.ulTimeout);
    }
  }
  break;


  /***************************************************************************
   * netana_get_mbx_state
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_GETMBXSTATE:
  {
    PDEV_MBXSTATE_CNF_T     ptCnf = (PDEV_MBXSTATE_CNF_T)(ptMarshallerHeader);
    uint32_t                ulRecvPktCount = 0;        /*< Returned capture state */
    uint32_t                ulSendPktCount = 0;        /*< Returned capture error */

    if(!ptInstance->tDRVFunctions.pfn_netana_get_mbx_state)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_get_mbx_state ");
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_mbx_state(ptInstance->ptDevices->hDev, &ulRecvPktCount, &ulSendPktCount);
      if(NETANA_NO_ERROR == lRet)
      {
        ptCnf->tData.ulRecvPktCount = ulRecvPktCount;
        ptCnf->tData.ulSendPktCount = ulSendPktCount;
        ptMarshallerHeader->ulDataSize = sizeof(ptCnf->tData);

      }else
      {
        ptMarshallerHeader->ulDataSize = 0;
      }
    }
  }
  break;


  /***************************************************************************
   * netana_get_gpio_mode
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_GETGPIOMODE:
  {
    PDEV_GETGPIOMODE_REQ_T     ptReq   = (PDEV_GETGPIOMODE_REQ_T)(ptMarshallerHeader);
    PDEV_GETGPIOMODE_CNF_T     ptCnf   = (PDEV_GETGPIOMODE_CNF_T)(ptMarshallerHeader);
    NETANA_GPIO_MODE_T         tMode  = {0};


    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_get_gpio_mode)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_access_phy_reg");
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_gpio_mode(  ptInstance->ptDevices->hDev,
          ptReq->tData.ulGPIO,
          &tMode);
      if(NETANA_NO_ERROR == lRet)
      {
        ptCnf->tData.tMode        = tMode;
        ptReq->tHeader.ulDataSize = sizeof(DEV_GETGPIOMODE_CNF_DATA_T);
      }
      else
        ptMarshallerHeader->ulDataSize = 0;
    }
  }
  break;

  /***************************************************************************
   * netana_set_gpio_mode
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_SETGPIOMODE:
  {
    PDEV_SETGPIOMODE_REQ_T     ptReq   = (PDEV_SETGPIOMODE_REQ_T)(ptMarshallerHeader);

    ptMarshallerHeader->ulDataSize = 0;

    if(!ptInstance->tDRVFunctions.pfn_netana_set_gpio_mode)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_set_gpio_mode");
      lRet = ptInstance->tDRVFunctions.pfn_netana_set_gpio_mode(  ptInstance->ptDevices->hDev,
          ptReq->tData.ulGPIO,
          &ptReq->tData.tMode);
    }
  }
  break;


  /***************************************************************************
   * netana_get_filter
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_GETFILTER:
  {
    PDEV_GETFILTER_REQ_T  ptReq           = (PDEV_GETFILTER_REQ_T)(ptMarshallerHeader);
    PDEV_GETFILTER_CNF_T  ptCnf           = (PDEV_GETFILTER_CNF_T)(ptMarshallerHeader);

    NETANA_FILTER_T       tFilterA        = {0};
    NETANA_FILTER_T       tFilterB        = {0};
    uint32_t              ulRelationShip  = 0;

    uint8_t abMaskA[512]   = {0};
    uint8_t abValueA[512] = {0};
    uint8_t abMaskB[512]   = {0};
    uint8_t abValueB[512] = {0};

    tFilterA.pbMask   = abMaskA;
    tFilterA.pbValue   = abValueA;
    tFilterB.pbMask   = abMaskB;
    tFilterB.pbValue   = abValueB;

    tFilterA.ulFilterSize = 512;
    tFilterB.ulFilterSize = 512;

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_get_filter)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_set_gpio_mode");
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_filter( ptInstance->ptDevices->hDev,
          ptReq->tData.ulPort,
          &tFilterA,
          &tFilterB,
          &ulRelationShip);
      if(NETANA_NO_ERROR == lRet)
      {
        uint32_t ulCopyLen = sizeof(DEV_GETFILTER_CNF_DATA_T) + tFilterA.ulFilterSize * 2 + tFilterB.ulFilterSize * 2;
        if( (ptBuffer->tMgmt.ulDataBufferLen - sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T)) >= ulCopyLen )
        {

          memset(&ptCnf->tData, 0, ulCopyLen);

          // this would transmitt void pointer with size dependign on architectur
          //ptCnf->tData.tFilterA       = tFilterA;
          //ptCnf->tData.tFilterB       = tFilterB;

          ptCnf->tData.ulFilterSizeA = tFilterA.ulFilterSize;
          ptCnf->tData.ulFilterSizeB = tFilterB.ulFilterSize;

          ptCnf->tData.ulRelationShip  = ulRelationShip;

          uint32_t uiOffsetData = sizeof(DEV_GETFILTER_CNF_DATA_T);
          uint32_t uiOffsetFA = tFilterA.ulFilterSize;
          uint32_t uiOffsetFB = tFilterB.ulFilterSize;

          char* pbCnfMaskA = (char*)&ptCnf->tData + uiOffsetData;
          char* pbCnfValueA = (char*)&ptCnf->tData + uiOffsetData + uiOffsetFA;
          char* pbCnfMaskB = (char*)&ptCnf->tData + uiOffsetData + uiOffsetFA * 2;
          char* pbCnfValueB = (char*)&ptCnf->tData + uiOffsetData + uiOffsetFA * 2 + uiOffsetFB;

          memcpy(pbCnfMaskA, tFilterA.pbMask, tFilterA.ulFilterSize);
          memcpy(pbCnfValueA, tFilterA.pbValue, tFilterA.ulFilterSize);
          memcpy(pbCnfMaskB, tFilterB.pbMask, tFilterB.ulFilterSize);
          memcpy(pbCnfValueB, tFilterB.pbValue, tFilterB.ulFilterSize);

          ptCnf->tHeader.ulDataSize = ulCopyLen;
        }
        else
        {
          lRet = NETANA_INVALID_PARAMETER;
          ptMarshallerHeader->ulDataSize = 0;
        }
      }
    }
  }
  break;

  /***************************************************************************
   * netana_set_filter
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_SETFILTER:
  {
    PDEV_SETFILTER_REQ_T  ptReq           = (PDEV_SETFILTER_REQ_T)(ptMarshallerHeader);

    // recreate filter structurs with pointers pointing to the received tata
    // casting through typedefs is not possible because of dynamic size of fields

    NETANA_FILTER_T       tFilterA        = {0};
    NETANA_FILTER_T       tFilterB        = {0};

    if (ptReq->tData.ulFilterSizeA > 0)
    {
      tFilterA.ulFilterSize = ptReq->tData.ulFilterSizeA;
      tFilterA.pbMask =  (uint8_t*)&ptReq->tData + sizeof(DEV_SETFILTER_REQ_DATA_T);
      tFilterA.pbValue = (uint8_t*)&ptReq->tData + sizeof(DEV_SETFILTER_REQ_DATA_T) + ptReq->tData.ulFilterSizeA;
    }
    if (ptReq->tData.ulFilterSizeB > 0)
    {
      tFilterB.ulFilterSize = ptReq->tData.ulFilterSizeB;
      tFilterB.pbMask =  (uint8_t*)&ptReq->tData + sizeof(DEV_SETFILTER_REQ_DATA_T) + ptReq->tData.ulFilterSizeA * 2;
      tFilterB.pbValue = (uint8_t*)&ptReq->tData + sizeof(DEV_SETFILTER_REQ_DATA_T) + ptReq->tData.ulFilterSizeA * 2 + ptReq->tData.ulFilterSizeB;
    }

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_set_filter)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_set_gpio_mode");
      lRet = ptInstance->tDRVFunctions.pfn_netana_set_filter( ptInstance->ptDevices->hDev,
          ptReq->tData.ulPort,
          &tFilterA,
          &tFilterB,
          ptReq->tData.ulRelationShip);
    }
  }
  break;


  /***************************************************************************
   *netana_start_capture
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_STARTCAPTURE:
  {
    PDEV_STARTCAPTURE_REQ_T       ptReq             = (PDEV_STARTCAPTURE_REQ_T)(ptMarshallerHeader);
    PDEV_STARTCAPTURE_CNF_T       ptCnf             = (PDEV_STARTCAPTURE_CNF_T)(ptMarshallerHeader);
    PFN_DATA_CALLBACK             pfnDataCallback   = NULL;
    PFN_STATUS_CALLBACK           pfnStatusCallback = NULL;
    void*                         pvCallbackInternal= NULL;
    NETANA_MARSHALLER_HANDLE_U*          puHandle          = NULL;
    static CALLBACK_INTERNAL_T    tCallbackInternal = {0} ;
    HIL_MARSHALLER_DATA_T*        ptMarshaller      = (HIL_MARSHALLER_DATA_T*)ptBuffer->tMgmt.pvMarshaller;

    //fill strukture for callback pvUser
    tCallbackInternal.ulConnIdx       = ptBuffer->tMgmt.ulConnectorIdx;     // this is the tx buffer which is given to transmitfunc    // index of owning connection
    tCallbackInternal.ptInstance      = ptInstance;     // instancehandle of Marshaller 
    tCallbackInternal.ptMarshaller    = ptMarshaller;   // datastruct of Marshaller needet for transmitfunc
    tCallbackInternal.sDataType       = ptBuffer->tTransport.usDataType;
    tCallbackInternal.bSequence       = 0;              // there is no other reason for sending unsolicited pakages but callbacks after startcapture
    tCallbackInternal.sTransaction    = HIL_TRANSPORT_TRANSACTION_DEVICE;         // device request
    tCallbackInternal.ulHandle        = ptReq->tHeader.ulHandle;

    puHandle     = (NETANA_MARSHALLER_HANDLE_U*)&tCallbackInternal.ulHandle;
    puHandle->tBfHandle.bObjectType   = NETANA_MARSHALLER_OBJECT_TYPE_CALLBACK; // should be new handle for callbackobjects

    //needs callbackobject
    pvCallbackInternal = &tCallbackInternal;

    /* if a Callback is wished by the calling ClientApplication, it is set here */
    //if (ptReq->tData.fnData) //always 
    pfnDataCallback   = DataCallback; 

    if (ptReq->tData.fnStatus)
      pfnStatusCallback = StatusCallback; 


    if(!ptInstance->tDRVFunctions.pfn_netana_start_capture )
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
      ptMarshallerHeader->ulDataSize = 0;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_start_capture");
      lRet = ptInstance->tDRVFunctions.pfn_netana_start_capture(ptInstance->ptDevices->hDev,
          ptReq->tData.ulCaptureMode,
          ptReq->tData.ulPortEnableMask,
          ptReq->tData.ulMacMode,
          ptReq->tData.ullReferenceTime,
          pfnStatusCallback,
          pfnDataCallback,
          pvCallbackInternal);      //pvUser holds ptCallback_internal
          if(NETANA_NO_ERROR == lRet)
          {
            ptCnf->tData.ulHandle = puHandle->ulHandle;
            ptMarshallerHeader->ulDataSize = sizeof(DEV_STARTCAPTURE_CNF_DATA_T);
            TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_start_capture done\n");
          }
          else
          {
            //fprintf(stderr,"pfn_netana_start_capture failed with error 0x%X\n", lRet);
            TRACE_PRINT_TYPE(LOG_NETANAAPI|LOG_ERR,"pfn_netana_start_capture 0x%X", lRet);
          }
    }
  }
  break;


  /***************************************************************************
   * netana_stop_capture
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_STOPCAPTURE:
  {
    if(!ptInstance->tDRVFunctions.pfn_netana_stop_capture)
    {


      lRet = NETANA_FUNCTION_NOT_AVAILABLE;

    } else
    {

      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_stop_capture hDev: 0x%08X",ptInstance->ptDevices->hDev);
      lRet = ptInstance->tDRVFunctions.pfn_netana_stop_capture( ptInstance->ptDevices->hDev);
      if (lRet != NETANA_NO_ERROR)
      {
        TRACE_PRINT_TYPE(LOG_NETANAAPI|LOG_ERR,"pfn_netana_stop_capture returned 0x%X",lRet);
      }
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_stop_capture done");
    }
  }
  break;


  /***************************************************************************
   * netana_set_gpio_output
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_SETGPIOOUTPUT:
  {
    PDEV_SETGPIOOUTPUT_REQ_T  ptReq           = (PDEV_SETGPIOOUTPUT_REQ_T)(ptMarshallerHeader);

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_set_gpio_output)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_set_gpio_output");
      lRet = ptInstance->tDRVFunctions.pfn_netana_set_gpio_output( ptInstance->ptDevices->hDev,
          ptReq->tData.ulGPIO,
          ptReq->tData.ulLevel);
    }
  }
  break;

  /***************************************************************************
   * netana_resync_time
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_RESYNCTIME:
  {
    PDEV_RESYNCTIME_REQ_T  ptReq           = (PDEV_RESYNCTIME_REQ_T)(ptMarshallerHeader);

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_resync_time)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_resync_time");
      lRet = ptInstance->tDRVFunctions.pfn_netana_resync_time(    ptInstance->ptDevices->hDev,
          ptReq->tData.ullReferenceTime);
    }
  }
  break;

  /***************************************************************************
   * netana_config_pi_controller
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_CONFIGPICTRL:
  {
    PDEV_CONFIGPICTRL_REQ_T  ptReq           = (PDEV_CONFIGPICTRL_REQ_T)(ptMarshallerHeader);

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_config_pi_controller)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_config_pi_controller");
      lRet = ptInstance->tDRVFunctions.pfn_netana_config_pi_controller( ptInstance->ptDevices->hDev,
          ptReq->tData.ulP,
          ptReq->tData.ulI );
    }
  }
  break;

  /***************************************************************************
   * netana_set_gpio_voltage
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_SETGPIOVOLTAGE:
  {
    PDEV_SETGPIOVOLTAGE_REQ_T  ptReq           = (PDEV_SETGPIOVOLTAGE_REQ_T)(ptMarshallerHeader);

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_set_gpio_voltage)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_set_gpio_voltage");
      // TRACE_PRINT1("Handle: 0x%X",ptInstance->ptDevices->hDev);
      // TRACE_PRINT1("gpioMask: 0x%X",ptReq->tData.ulGpioSelMsk);
      // TRACE_PRINT1("gpioVoltageSel: 0x%X",ptReq->tData.ulGpioVoltageSel);
      lRet = ptInstance->tDRVFunctions.pfn_netana_set_gpio_voltage( ptInstance->ptDevices->hDev,
          ptReq->tData.ulGpioSelMsk,
          ptReq->tData.ulGpioVoltageSel );
      // TRACE_PRINT1("set_gpio_voltage returned 0x%X\n",lRet);
    }
  }
  break;

  /***************************************************************************
   * netana_get_gpio_voltage
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_GETGPIOVOLTAGE:
  {
    PDEV_GETGPIOVOLTAGE_REQ_T  ptReq           = (PDEV_GETGPIOVOLTAGE_REQ_T)(ptMarshallerHeader);
    PDEV_GETGPIOVOLTAGE_CNF_T  ptCnf            = (PDEV_GETGPIOVOLTAGE_CNF_T)(ptMarshallerHeader);
    uint32_t                    ulGpioVoltageSel  = 0;

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_get_gpio_voltage)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_get_gpio_voltage");
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_gpio_voltage( ptInstance->ptDevices->hDev,
          ptReq->tData.ulGpio,
          &ulGpioVoltageSel);
      if(NETANA_NO_ERROR == lRet)
      {
        ptCnf->tData.ulGpioVoltageSel        = ulGpioVoltageSel;
        ptCnf->tHeader.ulDataSize = sizeof(DEV_GETGPIOVOLTAGE_CNF_DATA_T);
      }
      else
        ptMarshallerHeader->ulDataSize = 0;
    }
  }
  break;
  /***************************************************************************
   * netana_signal_driver_error
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_SIGNALDRIVERERROR:
  {
    PDEV_SIGNAL_DRIVER_ERROR_REQ_T  ptReq  = (PDEV_SIGNAL_DRIVER_ERROR_REQ_T)(ptMarshallerHeader);
    //printf("req pfn_netana_signal_driver_error\n");
    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_signal_driver_error)
    {
      //printf("pfn_netana_signal_driver_error not found in lib\n");
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_signal_driver_error");
      //printf("call pfn_netana_signal_driver_error with handle: 0x%X and error: 0x%X\n", ptInstance->ptDevices->hDev, ptReq->tData.ulError);
      lRet = ptInstance->tDRVFunctions.pfn_netana_signal_driver_error( ptInstance->ptDevices->hDev,
          ptReq->tData.ulError);
      /*if (lRet != 0)
            {
              printf("pfn_netana_signal_driver_error returned: 0x%X\n", lRet);
            }*/
    }
  }
  break;



  /***************************************************************************
   * netana_get_device_ident
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_GETDEVICEIDENT:
  {
    PDEV_GET_DEVICE_IDENT_REQ_T  ptReq           = (PDEV_GET_DEVICE_IDENT_REQ_T)(ptMarshallerHeader);
    PDEV_GET_DEVICE_IDENT_CNF_T  ptCnf            = (PDEV_GET_DEVICE_IDENT_CNF_T)(ptMarshallerHeader);
    NETANA_DEVICE_IDENT_T        tIdentInfo  = {0};

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_get_device_ident)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_get_device_ident");
      lRet = ptInstance->tDRVFunctions.pfn_netana_get_device_ident( ptInstance->ptDevices->hDev,
          sizeof(tIdentInfo),
          &tIdentInfo);
      if(NETANA_NO_ERROR == lRet)
      {
        ptCnf->tHeader.ulDataSize = min(ptReq->tData.ulDevIdentInfoSize, sizeof(DEV_GET_DEVICE_IDENT_CNF_DATA_T));
        memcpy(&ptCnf->tData.ptIdentInfo, &tIdentInfo, ptCnf->tHeader.ulDataSize);
      }
      else
        ptMarshallerHeader->ulDataSize = 0;
    }
  }
  break;


  /***************************************************************************
   * netana_check_device_ident
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_CHECKDEVICEIDENT:
  {
    PDEV_CHECK_DEVICE_IDENT_REQ_T  ptReq           = (PDEV_CHECK_DEVICE_IDENT_REQ_T)(ptMarshallerHeader);
    PDEV_CHECK_DEVICE_IDENT_CNF_T  ptCnf            = (PDEV_CHECK_DEVICE_IDENT_CNF_T)(ptMarshallerHeader);

    uint32_t ulDevIdentInfoSize = ptReq->tData.ulDevIdentInfoSize;
    //ptMarshallerHeader->ulDataSize = 0;

    if(!ptInstance->tDRVFunctions.pfn_netana_check_device_ident )
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    }
    else if (ptReq->tHeader.ulDataSize != ptReq->tData.ulDevIdentInfoSize + sizeof(ptReq->tData))
    {
      lRet = NETANA_INVALID_PARAMETER;
    }
    else
    {
      /* we need a memoryblock to work on so we dont destroy the transmitt buffer */
      uint8_t* pbDevIdentInfo  = (uint8_t*)OS_MALLOC(ulDevIdentInfoSize);
      if(pbDevIdentInfo)
      {
        memset(pbDevIdentInfo, 0, ulDevIdentInfoSize);
        memcpy(pbDevIdentInfo, &ptReq->tData +1, ulDevIdentInfoSize);

        TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_check_device_ident");
        lRet = ptInstance->tDRVFunctions.pfn_netana_check_device_ident( ptInstance->ptDevices->hDev,
            ulDevIdentInfoSize,
            pbDevIdentInfo);
        if(NETANA_NO_ERROR == lRet)
        {
          memcpy((&(ptCnf->tHeader)) + 1, pbDevIdentInfo, ulDevIdentInfoSize);
          ptCnf->tHeader.ulDataSize = ulDevIdentInfoSize;
        }
        else
          ptMarshallerHeader->ulDataSize = 0;

        OS_FREE(pbDevIdentInfo);
        pbDevIdentInfo = 0;
      }
      else
      {
        ptMarshallerHeader->ulDataSize = 0;
        lRet = NETANA_OUT_OF_MEMORY;
      }
    }
  }
  break;



  /***************************************************************************
   * netana_set_device_ident
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_SETDEVICEIDENT:
  {
    PDEV_FILE_DOWNLOAD_REQ_T       ptReq          = (PDEV_FILE_DOWNLOAD_REQ_T)(ptMarshallerHeader);
    PDEV_FILE_DOWNLOAD_CNF_T      ptCnf          = (PDEV_FILE_DOWNLOAD_CNF_T)(ptMarshallerHeader);

    ptMarshallerHeader->ulDataSize = 0;
    if(!ptInstance->tDRVFunctions.pfn_netana_check_device_ident)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    } else
    {
      // this is the first part (of 3) of the netana_set_device_ident function
      // first:  create file
      // second: download file until it is done call then setdeviceident api
      // abort:  abort download and delete file if client desires so


      TRACE_PRINT_TYPE(LOG_NETANAAPI,"set_device_ident (openfile file)");
      ptCnf->tData.ulMaxBlockSize = ptBuffer->tMgmt.ulDataBufferLen; //tTCPConnector->ulDataBufferSize in netANATCPServerDlg.cpp
      int hFile = -1;
      hFile = open (NETANA_LIC_PATH_NAME, O_RDWR | O_CREAT | O_SYNC, S_IRUSR | S_IRGRP | S_IROTH); // path to /lib/firmware/netanalyzer/lic.nxl
      if(hFile > -1)
      {
        tFileState.hFile = hFile;
        tFileState.iLastBlock = -1;
        tFileState.uiCurrentSize = 0;
        tFileState.uiTotalSize = ptReq->tData.ulFileLength;
        tFileState.uiBlockSize = ptCnf->tData.ulMaxBlockSize;
        ptMarshallerHeader->ulDataSize = sizeof(ptCnf->tData);
      }
      else
      {
        lRet = NETANA_FILE_CREATION_FAILED;
        break;
      }
    }
  }
  break;


  /***************************************************************************
   * netana_set_device_ident (download data)
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_DOWNLOADDATA:
  {
    PDEV_FILE_DOWNLOAD_DATA_REQ_T       ptReq          = (PDEV_FILE_DOWNLOAD_DATA_REQ_T)(ptMarshallerHeader);

    int32_t lCopyLen = ptReq->tHeader.ulDataSize - sizeof(ptReq->tData);

    TRACE_PRINT_TYPE(LOG_NETANAAPI,"set_device_ident (write file)");
    if(!ptInstance->tDRVFunctions.pfn_netana_set_device_ident)
    {
      lRet = NETANA_FUNCTION_NOT_AVAILABLE;
    }
    else if (    tFileState.hFile > -1
        && lCopyLen > 0
        && (int)ptReq->tData.ulBlockNo > tFileState.iLastBlock)
    {

      // this is the second part (of 3) of the netana_set_device_ident function
      // first:  create file
      // SECOND: download file until it is done call then setdeviceident api
      // abort:  abort download and delete file if client desires so
      int iWritten = 0;
      iWritten = write(tFileState.hFile, (&ptReq->tData) +1, lCopyLen);
      if (iWritten != lCopyLen)
        lRet = NETANA_FILE_WRITE_FAILED;
      else
      {
        tFileState.iLastBlock = ptReq->tData.ulBlockNo;
        tFileState.uiCurrentSize += iWritten;
        ptMarshallerHeader->ulDataSize = 0;
        if(tFileState.uiCurrentSize > tFileState.uiTotalSize)
          lRet = NETANA_FILE_WRITE_FAILED;
      }
    }
    else
    {
      lRet = NETANA_TRANSPORT_SEQUENCE;
      break;
    }
    if(tFileState.uiCurrentSize == tFileState.uiTotalSize)
    {
      // we have a complete file so we close it and call the set_idenet func
      close(tFileState.hFile);
      memset(&tFileState, 0, sizeof(tFileState));
      tFileState.hFile = -1;
      TRACE_PRINT_TYPE(LOG_NETANAAPI,"pfn_netana_set_device_ident");
      lRet = ptInstance->tDRVFunctions.pfn_netana_set_device_ident( ptInstance->ptDevices->hDev, "/netanalyzer/lic.nxl");
      //int iRemoved =
      remove(NETANA_LIC_PATH_NAME);
      //if (iRemoved != 0)
      //  lRet = NETANA_FILE_WRITE_FAILED;
    }
  }
  break;

  /***************************************************************************
   * netana_set_device_ident (download abort)
   ***************************************************************************/
  case NETANA_MARSHALLER_DEV_METHODID_DOWNLOADABORT:
  {
    PDEV_FILE_DOWNLOAD_ABORT_REQ_T       ptReq       = (PDEV_FILE_DOWNLOAD_ABORT_REQ_T)(ptMarshallerHeader);


    ptReq->tHeader.ulDataSize = 0;

    // this is the third part (of 3) of the netana_set_device_ident function
    // first:  create file
    // second: download file until it is done call then setdeviceident api
    // ABORT:  abort download and delete file if client desires so

    close(tFileState.hFile);
    memset(&tFileState, 0, sizeof(tFileState));
    tFileState.hFile = -1;
    //int iRemoved =
    remove(NETANA_LIC_PATH_NAME);
    //if (iRemoved != 0)
    //    lRet = NETANA_FILE_WRITE_FAILED;
  }
  break;


  default:
    /* Unknown/unsupported method ID */
    ptMarshallerHeader->ulDataSize = 0;
    lRet = NETANA_TRANSPORT_UNSUPPORTED_FUNCTION ;
    break;
  }
  //TRACE_EXIT("HandleSysdeviceCommand");
  return lRet;
}
