#include "MarshallerConfig.h"
#include "MarshallerInternal.h"
#include "netANA_MarshallerFrame.h"
#include "../version.h"
#include "sys/queue.h"
#include "../win2lin.h"

#include "../debug_trace.h"


CRITICAL_SECTION iLock; //global lock for ptbuffer memory allocation acces

#ifndef min
  #define min(a,b)  ((a > b)? b : a)
#endif

/*****************************************************************************/
/*! Calculate CCITT/ITU CRC-16 checksum.
*   Polynomial  : x^16 + x^12 + x^5 + 1 (0x1021)
*   Start value : 0xFFFF
*   Result      : XORed with 0xFFFF
*    \param pbData        Buffer to calculate CRC for
*    \param ulDataLength  Length of buffer
*    \return CRC-16 checksum                                                 *
// *****************************************************************************
static uint16_t CalculateCRC16 (const uint8_t* pbData, uint32_t ulDataLength)
{
  uint16_t usCRC;
  uint32_t ulOffset;

  usCRC = 0xFFFF;
  if (pbData != NULL && ulDataLength > 0)
  { // * Buffer address and data length are valid. *
    for (ulOffset = 0; ulOffset < ulDataLength; ++ulOffset)
    { // * Update CRC value for each byte in the buffer. *
      usCRC =  (uint16_t) ((usCRC >> 8) | (usCRC << 8));
      usCRC ^= pbData[ulOffset];
      usCRC ^= (usCRC & 0xFF) >> 4;
      usCRC ^= (usCRC << 8) << 4;
      usCRC ^= ((usCRC & 0xFF) << 4) << 1;
    }
    usCRC = (uint16_t) (~usCRC);
  }
  return (usCRC);
}
*/

/*****************************************************************************/
/*! Allocates the requested data buffers and inserts them in free list
*   of connector
*    \param pvMarshaller   Marshaller handle
*    \param ptConnector    Connector to allocate buffers for
*    \param ulRxBufferCnt  Number of buffers to allocate (equals number of parallel services)
*    \param ulRxBufferSize Size of the buffers in bytes
*    \param ulTxBufferCnt  Number of transmit buffers to allocate (for unsolicited/indication data)
*    \param ulTxBufferSize Size of the transmit buffers in bytes
*    \return true on success                                             */
/*****************************************************************************/
static bool AllocateBuffers(void* pvMarshaller, CONNECTOR_DATA_T* ptConnector, uint32_t ulRxBufferCnt, uint32_t ulRxBufferSize, uint32_t ulTxBufferCnt, uint32_t ulTxBufferSize)
{
  bool fRet = true;
  uint32_t  ulIdx;

  STAILQ_INIT(&ptConnector->tRxBuffer);
  STAILQ_INIT(&ptConnector->tTxBuffer); 
  STAILQ_INIT(&ptConnector->tAckBuffer);
  STAILQ_INIT(&ptConnector->tKeepAliveBuffer);

  /* Use twice the number of requested data buffers for Rx data,
     to make sure we have some reserve in case a buffer has not yet been released after the confirmation has been sent */
  for(ulIdx = 0; ulIdx < ulRxBufferCnt; ++ulIdx)
  {
    HIL_MARSHALLER_BUFFER_T* ptBuffer;

    if(NULL == (ptBuffer = OS_MALLOC(sizeof(*ptBuffer) + ulRxBufferSize)))
    {
      fRet = 0;
      break;
    } else
    {
      ptBuffer->tMgmt.ulConnectorIdx      = ptConnector->ulConnectorIdx;
      ptBuffer->tMgmt.pvMarshaller        = pvMarshaller;
      ptBuffer->tMgmt.ulDataBufferLen     = ulRxBufferSize;
      ptBuffer->tMgmt.eType               = eMARSHALLER_RX_BUFFER;
      ptBuffer->tMgmt.ulUsedDataBufferLen = 0;

      /* Enqueue in linked list */
      STAILQ_INSERT_TAIL(&ptConnector->tRxBuffer, ptBuffer, tList);
    }
  }

  for(ulIdx = 0; ulIdx < ulTxBufferCnt; ++ulIdx)
  {
    HIL_MARSHALLER_BUFFER_T* ptBuffer;

    if(NULL == (ptBuffer = OS_MALLOC(sizeof(*ptBuffer) + ulTxBufferSize)))
    {
      fRet = 0;
    	break;
  	} else
  	{
    	ptBuffer->tMgmt.ulConnectorIdx      = ptConnector->ulConnectorIdx;
    	ptBuffer->tMgmt.pvMarshaller        = pvMarshaller;
    	ptBuffer->tMgmt.ulDataBufferLen     = ulTxBufferSize;
    	ptBuffer->tMgmt.eType               = eMARSHALLER_TX_BUFFER;
    	ptBuffer->tMgmt.ulUsedDataBufferLen = 0;
    	/* Enqueue in linked list */
			STAILQ_INSERT_TAIL(&ptConnector->tTxBuffer, ptBuffer, tList);
  	}
  }

  /* Use one additional Buffer per direction for acknowledgement,
     to make sure we can answer while we don't have databuffers
     ready (number of parallel services exceeded) */
  for(ulIdx = 0; ulIdx < ulRxBufferCnt + ulTxBufferCnt + 2; ++ulIdx)
  {
    HIL_MARSHALLER_BUFFER_T* ptBuffer;

    if(NULL == (ptBuffer = OS_MALLOC(sizeof(*ptBuffer))))
    {
      fRet = false;
      break;
    } else
    {
      ptBuffer->tMgmt.ulConnectorIdx      = ptConnector->ulConnectorIdx;
      ptBuffer->tMgmt.pvMarshaller        = pvMarshaller;
      ptBuffer->tMgmt.ulDataBufferLen     = 0;
      ptBuffer->tMgmt.eType               = eMARSHALLER_ACK_BUFFER;
      ptBuffer->tMgmt.ulUsedDataBufferLen = 0;

      /* Enqueue in linked list */
      STAILQ_INSERT_TAIL(&ptConnector->tAckBuffer, ptBuffer, tList);
    }
  }

  if(fRet)
  {
    HIL_MARSHALLER_BUFFER_T* ptBuffer;

    if(NULL == (ptBuffer = OS_MALLOC(sizeof(*ptBuffer) + sizeof(HIL_TRANSPORT_KEEPALIVE_DATA_T))))
    {
      fRet = false;
    } else
    {
      ptBuffer->tMgmt.ulConnectorIdx      = ptConnector->ulConnectorIdx;
      ptBuffer->tMgmt.pvMarshaller        = pvMarshaller;
      ptBuffer->tMgmt.ulDataBufferLen     = sizeof(HIL_TRANSPORT_KEEPALIVE_DATA_T);
      ptBuffer->tMgmt.eType               = eMARSHALLER_KEEPALIVE_BUFFER;
      ptBuffer->tMgmt.ulUsedDataBufferLen = 0;

      /* Enqueue in linked list */
      STAILQ_INSERT_TAIL(&ptConnector->tKeepAliveBuffer, ptBuffer, tList);
    }
  }
  return fRet;
}

/*****************************************************************************/
/*! Deallocates all data buffers from a connector
*    \param pvMarshaller Marshaller handle
*    \param ptConnector  Connector to free buffers for                      */
/*****************************************************************************/
static void DeAllocateBuffers(void* pvMarshaller, CONNECTOR_DATA_T* ptConnector)
{
  /* Deallocate all buffers in linked lists */
  HIL_MARSHALLER_BUFFER_T* ptBuffer;

  while(NULL != (ptBuffer = STAILQ_FIRST(&ptConnector->tAckBuffer)))
  {
    STAILQ_REMOVE(&ptConnector->tAckBuffer, ptBuffer, HIL_MARSHALLER_BUFFER_Ttag, tList);

    OS_FREE(ptBuffer);
  }

  while(NULL != (ptBuffer = STAILQ_FIRST(&ptConnector->tRxBuffer)))
  {
    STAILQ_REMOVE(&ptConnector->tRxBuffer, ptBuffer, HIL_MARSHALLER_BUFFER_Ttag, tList);

    OS_FREE(ptBuffer);
  }

  while(NULL != (ptBuffer = STAILQ_FIRST(&ptConnector->tTxBuffer)))
	{
  	STAILQ_REMOVE(&ptConnector->tTxBuffer, ptBuffer, HIL_MARSHALLER_BUFFER_Ttag, tList);

	  OS_FREE(ptBuffer);
	}

  while(NULL != (ptBuffer = STAILQ_FIRST(&ptConnector->tKeepAliveBuffer)))
  {
    STAILQ_REMOVE(&ptConnector->tKeepAliveBuffer, ptBuffer, HIL_MARSHALLER_BUFFER_Ttag, tList);

    OS_FREE(ptBuffer);
  }
}

/*****************************************************************************/
/*! Free a buffer
*    \param ptBuffer Buffer to free                                         */
/*****************************************************************************/
void HilMarshallerFreeBuffer(HIL_MARSHALLER_BUFFER_T* ptBuffer)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)ptBuffer->tMgmt.pvMarshaller;
  CONNECTOR_DATA_T*      ptConn       = &ptMarshaller->atConnectors[ptBuffer->tMgmt.ulConnectorIdx];
  //int                    iLock;

  ptBuffer->tMgmt.ulUsedDataBufferLen = 0;
  TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerFreeBuffer entering iLock");
  EnterCriticalSection(&iLock);  // = OS_LOCK();
  TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerFreeBuffer entered iLock");
  // TRACE_PRINT("entered iLock in HilMarshallerFreeBuffer");

  switch(ptBuffer->tMgmt.eType)
  {
  case eMARSHALLER_KEEPALIVE_BUFFER:
    STAILQ_INSERT_TAIL(&ptConn->tKeepAliveBuffer, ptBuffer, tList);
    break;

  case eMARSHALLER_ACK_BUFFER:
    STAILQ_INSERT_TAIL(&ptConn->tAckBuffer, ptBuffer, tList);
    break;

  case eMARSHALLER_RX_BUFFER:
    STAILQ_INSERT_TAIL(&ptConn->tRxBuffer, ptBuffer, tList);
    break;

  case eMARSHALLER_TX_BUFFER:
    STAILQ_INSERT_TAIL(&ptConn->tTxBuffer, ptBuffer, tList);
    break;

  default:
    /* NOTE: This should never happen, only if someone free's a wrong buffer,
             or destroyed the buffer management area (programming error). */
    //ptConn = ptConn;
    break;
  }
  TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerFreeBuffer leaving iLock");
  LeaveCriticalSection(&iLock);

}

/*****************************************************************************/
/*! Get a buffer for incoming data from connector
*    \param pvMarshaller Marshaller handle
*    \param eType        Type of buffer to acquire
*    \param ulConnector  Connector index
*    \return NULL if no buffer is available, valid buffer otherwise          */
/*****************************************************************************/
HIL_MARSHALLER_BUFFER_T* HilMarshallerGetBuffer(void* pvMarshaller, MARSHALLER_BUFFER_TYPE_E eType, uint32_t ulConnector)
{
  HIL_MARSHALLER_DATA_T*   ptMarshaller     = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  CONNECTOR_DATA_T*        ptConn           = &ptMarshaller->atConnectors[ulConnector];
  HIL_MARSHALLER_BUFFER_T* ptBuffer         = NULL;
  struct MARSHALLER_BUFFER_HEAD* ptListHead = NULL;
  //int                      iLock; //globaly declared
  //TRACE_ENTER("HilMarshallerGetBuffer");

  switch(eType)
  {
  case eMARSHALLER_RX_BUFFER:
    ptListHead = &ptConn->tRxBuffer;
    break;

	case eMARSHALLER_TX_BUFFER:
	  ptListHead = &ptConn->tTxBuffer;
  	break;

  case eMARSHALLER_ACK_BUFFER:
    ptListHead = &ptConn->tAckBuffer;
    break;

  case eMARSHALLER_KEEPALIVE_BUFFER:
    ptListHead = &ptConn->tKeepAliveBuffer;
    break;

  default:
    /* NOTE: This should never happen, only if someone free's a wrong buffer,
             or destroyed the buffer management area (programming error). */
    break;
  }
  TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerGetBuffer entering iLock");
  EnterCriticalSection(&iLock);  //= OS_LOCK();
  TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerGetBuffer entered iLock");
  if( (NULL != ptListHead) &&
      (NULL != (ptBuffer = STAILQ_FIRST(ptListHead))) )
  {
    STAILQ_REMOVE(ptListHead, ptBuffer, HIL_MARSHALLER_BUFFER_Ttag, tList);
    ptBuffer->tMgmt.ulActualSendOffset  = 0;
    ptBuffer->tMgmt.ulUsedDataBufferLen = 0;
  }
  TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerGetBuffer leaving iLock");
  LeaveCriticalSection(&iLock);
  TRACE_EXIT("HilMarshallerGetBuffer");
  return ptBuffer;
}

/*****************************************************************************/
/*! Find a transport layer which can handle the requested data type
*    \param ptMarshaller Marshaller handle
*    \param usDataType   Datatype the transport layer is requested for
*    \return NULL if no transport is available, valid transport otherwise    */
/*****************************************************************************/
static TRANSPORT_LAYER_DATA_T* FindTransportLayer(const HIL_MARSHALLER_DATA_T* ptMarshaller, const uint16_t usDataType)
{
  TRANSPORT_LAYER_DATA_T* ptRet = NULL;
  uint32_t              ulIdx;

  for(ulIdx = 0; ulIdx < ptMarshaller->ulTransports; ++ulIdx)
  {
    if(usDataType == ptMarshaller->ptTransports[ulIdx].usDataType)
    {
      ptRet = &ptMarshaller->ptTransports[ulIdx];
      break;
    }
  }

  return ptRet;
}

/*****************************************************************************/
/*! Send an HIL Transport acknowledge
*    \param ptMarshaller Marshaller handle
*    \param ulConnector  Connector to send ACK to
*    \param ptHeader     Header of incoming packet
*    \param bState       State to set in acknowledge                        */
/*****************************************************************************/


uint32_t g_ulTempRxBufferKA;
//extern uint32_t g_ulTempRxBufferCB;
uint32_t g_ulTempAckBuffer;
uint32_t g_ulRxPid ;

HIL_MARSHALLER_BUFFER_T** g_ppTempRxBufferKA;

static void SendAcknowledge(HIL_MARSHALLER_DATA_T* ptMarshaller, uint32_t ulConnector, HIL_TRANSPORT_HEADER* ptHeader, unsigned char bState)
{
  TRACE_PRINT_TYPE(LOG_COM,"SendAcknowledge");
  uint32_t ulRet = 0;
  HIL_MARSHALLER_BUFFER_T* ptBuffer;
  /* If we don't get a buffer, the number of parallel services is exceeded.
     This is a host error, as it is sending data too fast and we are not able to do any acknowledge */
  ptBuffer = HilMarshallerGetBuffer(ptMarshaller, eMARSHALLER_ACK_BUFFER, ulConnector);
  TRACE_PRINT_TYPE(LOG_COM,"ptAckBuffer 0x%08X\n ", (uint32_t)ptBuffer);
  g_ulTempAckBuffer = (uint32_t)ptBuffer;
  if(NULL != ptBuffer)
  {
    ptBuffer->tTransport                = *ptHeader;
    ptBuffer->tTransport.bState         = bState;
    ptBuffer->tTransport.usDataType     = HIL_TRANSPORT_TYPE_ACKNOWLEDGE;
    ptBuffer->tMgmt.ulUsedDataBufferLen = 0;
    if(0 !=  (ulRet = HilMarshallerConnTxData(ptMarshaller, ulConnector, ptBuffer)))
    {
    	fprintf(stderr,"HilMarshallerConnTxData error 0x%08X \n",ulRet);
      /* Internal error, this should never happen, but if it happens, we need to free the Ack buffer again */
      HilMarshallerFreeBuffer(ptBuffer);
    }
  }
  else
  {
  	fprintf(stderr,"HilMarshallerGetBuffer failed in send ack\n");
  }
  //TRACE_EXIT("SendAcknowledge");
}

/*****************************************************************************/
/*! Reset internal connector receive state machine
*    \param ptConnector  Connector to reset                                 */
/*****************************************************************************/
static void ResetRxStateMachine(CONNECTOR_DATA_T* ptConnector)
{
	// TODO: critical section to lock against cleanup and parsing

  /*TRACE_PRINT("HilMarshallerConnRxData entering tcsRxDataLock");
  EnterCriticalSection(&ptConnector->tConn.tcsRxDataLock);
  TRACE_PRINT("HilMarshallerConnRxData entered tcsRxDataLock");*/

  if((ptConnector->eScanState != HIL_SEARCH_TELEGRAM_COOKIE) &&
     (ptConnector->eScanState != HIL_SCAN_DONE)              )
  {
    //ptConnector->eScanState = ptConnector->eScanState;
  }
  
  ptConnector->fMonitorTimeout    = false;
  ptConnector->ulElapsedTime      = 0;
  ptConnector->tRxHeader.ulCookie = 0;
  ptConnector->ulRxOffset         = 0;
  if(NULL != ptConnector->ptCurrentRxBuffer)
  {
    HilMarshallerFreeBuffer(ptConnector->ptCurrentRxBuffer);
  }
  TRACE_PRINT_TYPE(LOG_BUFF,"set rxbuffer to zero ResetRxStateMachine 0x%08X", (unsigned int)ptConnector->ptCurrentRxBuffer);
  ptConnector->ptCurrentRxBuffer  = NULL;
  ptConnector->eScanState         = HIL_SEARCH_TELEGRAM_COOKIE;

  /*TRACE_PRINT("HilMarshallerConnRxData leaving tcsRxDataLock");
  LeaveCriticalSection(&ptConnector->tConn.tcsRxDataLock);*/
}


/*****************************************************************************/
/*! Startup marshaller
*    \param ptParams       Marshaller parameters
*    \param ppvMarshHandle Returned Marshaller handle
*    \param pfnRequest     Function to call, when MarshallerMain should be called
*    \param pvUser         User parameter to pass on pfnRequest call
*    \return 0 on success                                             */
/*****************************************************************************/
uint32_t HilMarshallerStart(const HIL_MARSHALLER_PARAMS_T* ptParams, void** ppvMarshHandle, PFN_MARSHALLER_REQUEST pfnRequest, void* pvUser)
{
  uint32_t                               eRet         = 0;
  HIL_MARSHALLER_DATA_T*                   ptMarshaller = NULL;
  uint32_t                               ulIdx        = 0;
  const TRANSPORT_LAYER_CONFIG_T*          ptTransport  = NULL;
  const HIL_MARSHALLER_CONNECTOR_PARAMS_T* ptConnParams = NULL;

 //// TRACE_PRINT("init iLock");
  InitializeCriticalSection(&iLock);

  if(NULL == ppvMarshHandle)
    eRet = HIL_MARSHALLER_E_INVALIDPARAMETER;
  else
  {
    *ppvMarshHandle = NULL;
    if (NULL == (ptMarshaller = OS_MALLOC(sizeof(*ptMarshaller))))
      eRet = HIL_MARSHALLER_E_OUTOFMEMORY;
    else
    {
      memset(ptMarshaller, 0, sizeof(*ptMarshaller));
      STAILQ_INIT(&ptMarshaller->tPendingRequests);
      ptMarshaller->pfnRequest      = pfnRequest;
      ptMarshaller->pvUser          = pvUser;
      ptMarshaller->ulMaxConnectors = ptParams->ulMaxConnectors;
      ptMarshaller->ulTransports    = ptParams->ulTransportCnt;
      memcpy(ptMarshaller->szServerName, ptParams->szServerName, sizeof(ptMarshaller->szServerName));
      if(NULL == (ptMarshaller->atConnectors = OS_MALLOC(ptParams->ulMaxConnectors * sizeof(CONNECTOR_DATA_T))))
        eRet = HIL_MARSHALLER_E_OUTOFMEMORY;
      else
      {
        memset(ptMarshaller->atConnectors, 0, ptParams->ulMaxConnectors * sizeof(CONNECTOR_DATA_T));
        if(NULL == (ptMarshaller->ptTransports = OS_MALLOC(ptParams->ulTransportCnt * sizeof(TRANSPORT_LAYER_DATA_T))))
          eRet = HIL_MARSHALLER_E_OUTOFMEMORY;
        else
        {
          uint32_t ulConnIdx;
          memset(ptMarshaller->ptTransports, 0, ptParams->ulTransportCnt * sizeof(TRANSPORT_LAYER_DATA_T));

          /* alloc now for more paralell connection and no fragmentation at reconnection*/
          ptConnParams = &ptParams->ptConnectors[0]; // we need the first connector which should be tcp;

          for(ulConnIdx = 0; ulConnIdx < ptParams->ulMaxConnectors; ++ulConnIdx)
          {
            ptMarshaller->atConnectors[ulConnIdx].ulConnectorIdx  = ulConnIdx;
            //create mutex attribute variable
            pthread_mutexattr_t mAttr;
            //init mutex attribute
            pthread_mutexattr_init(&mAttr);
            // setup nonrecursive mutex for mutex attribute
            pthread_mutexattr_settype(&mAttr, PTHREAD_MUTEX_NORMAL);
            // Use the mutex attribute to create the mutex
            pthread_mutex_init(&ptMarshaller->atConnectors[ulConnIdx].tcsRxDataLock, &mAttr);
            // Mutex attribute can be destroy after initializing the mutex variable
            pthread_mutexattr_destroy(&mAttr);
            if(!AllocateBuffers(ptMarshaller,  &ptMarshaller->atConnectors[ulConnIdx],
                                               ptConnParams->ulDataBufferCnt,
                                               ptConnParams->ulDataBufferSize,
                                               ptConnParams->ulTxBufferCnt,
                                               ptConnParams->ulTxBufferSize))
            {
              eRet = HIL_MARSHALLER_E_OUTOFMEMORY;
              break;
            }
          }

          for(ulIdx = 0; eRet == 0 && ulIdx < ptParams->ulConnectorCnt; ++ulIdx)
          {
            ptConnParams = &ptParams->ptConnectors[ulIdx];
            if(ptConnParams->pfnConnectorInit)
              eRet = ptConnParams->pfnConnectorInit(ptConnParams, ptMarshaller);
          }
          if (0 != (gethostname((char*)ptParams->szServerName, sizeof(ptParams->szServerName)))){
          	eRet = errno;
          } else {
            memcpy(ptMarshaller->szServerName, ptParams->szServerName, sizeof(ptMarshaller->szServerName));
          }


          for(ulIdx = 0; eRet == 0 && ulIdx < ptParams->ulTransportCnt; ++ulIdx)
          {
            ptTransport = &ptParams->atTransports[ulIdx];
            if(ptTransport->pfnInit)
              eRet = ptTransport->pfnInit(ptMarshaller, ptTransport->pvConfig);
          }
        }
      }
    }
    if(0 == eRet)
      *ppvMarshHandle = ptMarshaller;
    else
      HilMarshallerStop(ptMarshaller);
  }
  return eRet;
}


/*****************************************************************************/
/*! Stop marshaller
*    \param pvMarshHandle  Marshaller handle                                 */
/*****************************************************************************/
void HilMarshallerStop(void* pvMarshHandle)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshHandle;
  if(NULL != ptMarshaller)
  {
    if(NULL != ptMarshaller->atConnectors)
    {
      uint32_t ulConn;

      /* cleanup all connector data */
      for(ulConn = 0; ulConn < ptMarshaller->ulMaxConnectors; ++ulConn)
      {
        CONNECTOR_DATA_T* ptConn = &ptMarshaller->atConnectors[ulConn];
        if(ptConn->fInUse)
        {
          ptConn->tConn.pfnDeinit(ptConn->tConn.pvUser);
        }
        DeleteCriticalSection(&ptConn->tcsRxDataLock);
        DeAllocateBuffers(ptMarshaller, ptConn);
      }
      OS_FREE(ptMarshaller->atConnectors);
      ptMarshaller->atConnectors = NULL;
    }
    if(NULL != ptMarshaller->ptTransports)
    {
      uint32_t ulTrans;

      for(ulTrans = 0; ulTrans < ptMarshaller->ulTransports; ++ulTrans)
      {
        TRANSPORT_LAYER_DATA_T* ptTransport = &ptMarshaller->ptTransports[ulTrans];

        if(ptTransport->pfnDeinit)
        {
          ptTransport->pfnDeinit(ptTransport->pvUser);
        }
      }

      OS_FREE(ptMarshaller->ptTransports);
      ptMarshaller->ptTransports = NULL;
    }

    OS_FREE(ptMarshaller);

    DeleteCriticalSection(&iLock);
    // TRACE_PRINT("iLock deleted");
  }
}

/*****************************************************************************/
/*! Register a connector at marshaller
*    \param pvMarshaller     Marshaller handle
*    \param pulConnectorIdx  Returned connector number
*    \param ptConn           Connector data
*    \return 0 on success                                             */
/*****************************************************************************/
uint32_t HilMarshallerRegisterConnector(void* pvMarshaller, uint32_t* pulConnectorIdx, HIL_MARSHALLER_CONNECTOR_T* ptConn)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller    = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  bool                   eRet            = 0;
  CONNECTOR_DATA_T*      ptConnectorData = NULL;
  uint32_t               ulConnIdx;

  /* Search free connector space */
  for(ulConnIdx = 0; ulConnIdx < ptMarshaller->ulMaxConnectors; ++ulConnIdx)
  {
    if(!ptMarshaller->atConnectors[ulConnIdx].fInUse)
    {
      ptConnectorData = &ptMarshaller->atConnectors[ulConnIdx];
      ptConnectorData->ulConnectorIdx  = ulConnIdx;
      break;
    }
  }

  if(NULL == ptConnectorData)
  {
    /* No more connectors allowed */
    eRet = HIL_MARSHALLER_E_OUTOFRESOURCES;

  } /*// this is done now on initialization of marshaller to prevent insane memory fragmentation at each connection
  else if(!AllocateBuffers(pvMarshaller,
                             ptConnectorData,
                             ptConn->ulDataBufferCnt,
                             ptConn->ulDataBufferSize,
                             ptConn->ulTxBufferCnt,
                             ptConn->ulTxBufferSize))
  {
    // Out of memory
    eRet = HIL_MARSHALLER_E_OUTOFMEMORY;
  } */
  else
  {

    //InitializeCriticalSection(&ptConn->tcsRxDataLock);
    //TRACE_PRINT1("InitializeCriticalSection tcsRxDataLock in HilMarshallerRegisterConnector 0x%08X",&ptConnectorData->tcsRxDataLock);

    /* Initialize RX state machine */
    //EnterCriticalSection(&ptConnectorData->tcsRxDataLock);
    ResetRxStateMachine(ptConnectorData);
    //LeaveCriticalSection(&ptConnectorData->tcsRxDataLock);

    /* Initialize conector data */
    ptConnectorData->fInUse          = true;
    ptConnectorData->tConn           = *ptConn;
    *pulConnectorIdx                 = ulConnIdx;
  }

  return eRet;
}

/*****************************************************************************/
/*! Unregister a connector at marshaller
*    \param pvMarshaller     Marshaller handle
*    \param ulConnectorIdx   Connector number                               */
/*****************************************************************************/
void HilMarshallerUnregisterConnector(void* pvMarshaller, uint32_t ulConnectorIdx)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshaller;

  if(ulConnectorIdx < ptMarshaller->ulMaxConnectors)
  {
    CONNECTOR_DATA_T* ptConnectorData = &ptMarshaller->atConnectors[ulConnectorIdx];

    //TRACE_PRINT1("DeleteCriticalSection tcsRxDataLock in HilMarshallerUnregisterConnector 0x%08X",&ptConnectorData->tcsRxDataLock);
    //DeleteCriticalSection(&ptConnectorData->tcsRxDataLock);

    //DeAllocateBuffers(pvMarshaller, ptConnectorData);

    ptConnectorData->fInUse = false;
    //memset(&ptConnectorData->tConn, 0, sizeof(ptConnectorData->tConn));
  }
}

/*****************************************************************************/
/*! Called by connector when new data has arrived
*    \param pvMarshaller     Marshaller handle
*    \param ulConnector      Connector number
*    \param pbData           Incoming data
*    \param ulDataCnt        Number of bytes in incoming data buffer
*    \return 0 on success                                             */
/*****************************************************************************/

uint32_t HilMarshallerConnRxData(void* pvMarshaller, uint32_t ulConnector, uint8_t* pbData, uint32_t ulDataCnt)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  bool             eRet         = HIL_MARSHALLER_E_INVALIDPARAMETER;

  if (ulConnector < ptMarshaller->ulMaxConnectors
  &&  ptMarshaller->atConnectors[ulConnector].ulMode != HIL_MARSHALLER_MODE_DISABLED)
  {
    CONNECTOR_DATA_T* ptConnector = &ptMarshaller->atConnectors[ulConnector];
    int               fDone       = 0;    /* Leave handler */
    unsigned long     ulRxDataIdx = 0;

    eRet = 0;
    ptConnector->ulElapsedTime    = 0;      /* Reschedule timeout handling */

    TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerConnRxData entering tcsRxDataLock");
    EnterCriticalSection(&ptConnector->tcsRxDataLock);
    TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerConnRxData entered tcsRxDataLock");

    /*-----------------------------------------*/
    /* Start scanning of the input data        */
    /*-----------------------------------------*/
    do
    {
    	// TRACE_PRINT1("RxData Scan State: %d", ptConnector->eScanState);
      switch(ptConnector->eScanState)
      {
        case HIL_SEARCH_TELEGRAM_COOKIE:
        {
          /* Parse input buffer */
          unsigned char* pabCookie = (unsigned char*)&ptConnector->tRxHeader.ulCookie;

          for ( ulRxDataIdx = 0; ulRxDataIdx < ulDataCnt; ulRxDataIdx++)
          {
            pabCookie[ptConnector->ulRxOffset] = pbData[ulRxDataIdx];
            if( ++ptConnector->ulRxOffset >= sizeof(ptConnector->tRxHeader.ulCookie))
            {
              /* Check if we have a complete cookie */
              if( HIL_TRANSPORT_COOKIE == ptConnector->tRxHeader.ulCookie)
              {
                /* Yes, store the cookie in the header */
                ulDataCnt = ulDataCnt - (ulRxDataIdx + 1);
                pbData    = &pbData[ulRxDataIdx + 1];

                /* Set next state */
                ptConnector->eScanState      = HIL_SEARCH_TELEGRAM_HEADER;
                ptConnector->fMonitorTimeout = true;
                //// TRACE_PRINT("set next state HIL_SEARCH_TELEGRAM_HEADER");
                break;
              }else
              {
                  /* Still no cookie, move the data and insert next character. */
                /* Set cookie buffer index to next insertable character. */
                  memmove(pabCookie, &pabCookie[1], 3);
                  ptConnector->ulRxOffset = 3;
              }
            }
          }

          if( HIL_SEARCH_TELEGRAM_COOKIE == ptConnector->eScanState)
              fDone = 1;

          break;
        }

        case HIL_SEARCH_TELEGRAM_HEADER:
        {
          /* We searching a telegram header, cookie is already available */
          /* Check if we have more date */
          if ( 0 == ulDataCnt)
          {
            fDone = 1;
          } else
          {
            /* Append at least the header length if available */
            unsigned long  ulCopyLength = 0;
            unsigned char* pbHeader     = (unsigned char*)&ptConnector->tRxHeader;

            ulCopyLength = min(ulDataCnt,
                               sizeof(HIL_TRANSPORT_HEADER) - ptConnector->ulRxOffset);

            memcpy( &pbHeader[ptConnector->ulRxOffset],
                    pbData,
                    ulCopyLength);

            ptConnector->ulRxOffset += ulCopyLength;

            /* Check if we have more data */
            if(ptConnector->ulRxOffset < sizeof(HIL_TRANSPORT_HEADER))
            {
              /* We need more data */
              fDone = 1;

            } else if (HIL_TRANSPORT_TYPE_ACKNOWLEDGE == ptConnector->tRxHeader.usDataType)
            {
              /* Update the Rx data count and Rx data pointer for handling the remaining bytes */
              ulDataCnt -= ulCopyLength;
              pbData     = &pbData[ulCopyLength];
              TRACE_PRINT_TYPE(LOG_BUFF,"set rxbuffer to zero in HilMarshallerConnRxData HIL_SEARCH_TELEGRAM_HEADER");
              ptConnector->ptCurrentRxBuffer = NULL;
              // TRACE_PRINT1("reset statemachine (received ack sq: %d)", ptConnector->tRxHeader.bSequenceNr);

              ResetRxStateMachine(ptConnector);
              /* If there are bytes left, start a new cookie search using these bytes. Otherwise terminate the receive cycle. */
              if (ulDataCnt == 0)
                fDone = 1;
              break;
            } else
            {
              /* We need a buffer */

              HIL_MARSHALLER_BUFFER_T* ptBuffer;

              if(HIL_TRANSPORT_TYPE_KEEP_ALIVE == ptConnector->tRxHeader.usDataType)
              {
              	// TRACE_PRINT("get buffer for eMARSHALLER_KEEPALIVE_BUFFER");
                ptBuffer = HilMarshallerGetBuffer(ptMarshaller, eMARSHALLER_KEEPALIVE_BUFFER, ulConnector);

              } else
              {
              	// TRACE_PRINT("get buffer for eMARSHALLER_RX_BUFFER");
                ptBuffer = HilMarshallerGetBuffer(ptMarshaller, eMARSHALLER_RX_BUFFER, ulConnector);
              }

              if(NULL == ptBuffer)
              {
                /* Send negative Ack */
              	fprintf(stderr,"no buffer for packet\n");
                SendAcknowledge(ptMarshaller, ulConnector, &ptConnector->tRxHeader, HIL_TSTATE_RESOURCE_ERROR);
                ResetRxStateMachine(ptConnector);

              } else if(ptBuffer->tMgmt.ulDataBufferLen < ptConnector->tRxHeader.ulLength)
              {
              	fprintf(stderr,"telegram too long for buffer\n");
                /* Send negative ACK (telegram too long for buffer) */
                SendAcknowledge(ptMarshaller, ulConnector, &ptConnector->tRxHeader, HIL_TSTATE_BUFFEROVERFLOW_ERROR);

                /* Release Buffer */
                HilMarshallerFreeBuffer(ptBuffer);
                ResetRxStateMachine(ptConnector);

              } else
              {
                /* We have a complete Header, wait for packet data complete */
                ulDataCnt -= ulCopyLength;
                pbData    = &pbData[ulCopyLength];

                /* Store header */
                ptBuffer->tTransport                = ptConnector->tRxHeader;
                ptBuffer->tMgmt.ulUsedDataBufferLen = 0; /* Set actual telegram data length */

                /* Set next scanner state */
                ptConnector->ptCurrentRxBuffer = ptBuffer;
                //// TRACE_PRINT("set next state HIL_WAIT_TELEGRAM_DATA");
                ptConnector->eScanState        = HIL_WAIT_TELEGRAM_DATA;
              }
            }
          }
        }
        break;

        case HIL_WAIT_TELEGRAM_DATA:
        {
          /* We waiting for telegram data, wait until all data are available */
          unsigned long         ulCopyLen    = 0;
          HIL_TRANSPORT_HEADER* ptHeader     = &ptConnector->ptCurrentRxBuffer->tTransport;
          unsigned long         ulDataOffset = ptConnector->ulRxOffset - sizeof(HIL_TRANSPORT_HEADER);

          if(0 == ptHeader->ulLength)
          {
            /* We have all data */
          	//// TRACE_PRINT("set next state HIL_CHECK_TELEGRAM (no data)");
            ptConnector->eScanState = HIL_CHECK_TELEGRAM;

          /* We have packet data, wait until all data are available */
          } else if(0 != ulDataCnt)
          {
            HIL_MARSHALLER_BUFFER_T* ptBuffer = ptConnector->ptCurrentRxBuffer;

              /* Check if all data must be copied or if we have more data than necessary */
            ulCopyLen = ulDataCnt;
              if( (ulDataCnt + ulDataOffset) > ptHeader->ulLength)
              {
                  /* Just copy the necessary data and keep the rest for a new cookie ssearch */
              ulCopyLen = ptHeader->ulLength - ulDataOffset;
              }

            memcpy(&ptBuffer->abData[ulDataOffset], pbData, ulCopyLen);
            ptConnector->ulRxOffset             += ulCopyLen;
            ptBuffer->tMgmt.ulUsedDataBufferLen += ulCopyLen;
          }

          if(ptConnector->ulRxOffset < (ptHeader->ulLength + sizeof(*ptHeader)))
          {
              /* We have to wait for more data */
              fDone = 1;
          } else
          {
              /* We have a complete telegram */

              /* Check if we have data left */
              ulDataCnt -= ulCopyLen;
              pbData    = &pbData[ulCopyLen];

            /* We have all data */
            //// TRACE_PRINT("set next state HIL_CHECK_TELEGRAM (found all data)");
            ptConnector->eScanState = HIL_CHECK_TELEGRAM;
          }
        }
        break;

        case HIL_CHECK_TELEGRAM:
        {
          HIL_TRANSPORT_HEADER* ptHeader = &ptConnector->ptCurrentRxBuffer->tTransport;

          /* We have a complete telegram */
          /* Check for Acknowledge */
          switch(ptHeader->usDataType)
          {
          case HIL_TRANSPORT_TYPE_ACKNOWLEDGE:
          	// TRACE_PRINT("checking HIL_TRANSPORT_TYPE_ACKNOWLEDGE");
            break;

          case HIL_TRANSPORT_TYPE_QUERYSERVER:
          {
          	//// TRACE_PRINT("checking HIL_TRANSPORT_TYPE_QUERYSERVER");
            HIL_MARSHALLER_BUFFER_T* ptBuffer = ptConnector->ptCurrentRxBuffer;

            if(NULL == ptBuffer)
              ptBuffer = HilMarshallerGetBuffer(pvMarshaller, eMARSHALLER_TX_BUFFER, ulConnector);

            if(NULL == ptBuffer)
            {
              SendAcknowledge(ptMarshaller, ulConnector, &ptConnector->tRxHeader, HIL_TSTATE_RESOURCE_ERROR);

            } else
            {
              PHIL_TRANSPORT_ADMIN_QUERYSERVER_DATA_T ptServerData = (PHIL_TRANSPORT_ADMIN_QUERYSERVER_DATA_T)ptBuffer->abData;
              uint32_t                              ulIdx;
              SendAcknowledge(ptMarshaller, ulConnector, &ptConnector->tRxHeader, HIL_TRANSPORT_STATE_OK);
              
              /* Fill in data */
              ptBuffer->tTransport = ptConnector->ptCurrentRxBuffer->tTransport;

              ptServerData->ulStructVersion    = 1;
              memcpy(ptServerData->szServerName, ptMarshaller->szServerName, sizeof(ptServerData->szServerName));
              ptServerData->ulVersionMajor     = VERSION_MAJOR;
              ptServerData->ulVersionMinor     = VERSION_MINOR;
              ptServerData->ulVersionBuild     = VERSION_BUILD;
              ptServerData->ulVersionRevision  = VERSION_REVISION;
              ptServerData->ulFeatures         = HIL_TRANSPORT_FEATURES_KEEPALIVE;
              ptServerData->ulParallelServices = ptConnector->tConn.ulDataBufferCnt;
              ptServerData->ulBufferSize       = ptConnector->tConn.ulDataBufferSize;
              ptServerData->ulDatatypeCnt      = ptMarshaller->ulTransports;

              for(ulIdx = 0; ulIdx < ptMarshaller->ulTransports; ++ulIdx)
                ptServerData->ausDataTypes[ulIdx] = ptMarshaller->ptTransports[ulIdx].usDataType;

              /* Add the Keep Alive transport type to the list. */
              ptServerData->ausDataTypes[ulIdx] = HIL_TRANSPORT_TYPE_KEEP_ALIVE;
              ptServerData->ulDatatypeCnt++;

              /* Calculate the actual response data length. */
              ptBuffer->tMgmt.ulUsedDataBufferLen = (uint8_t*) ptServerData->ausDataTypes - (uint8_t*) ptServerData
                                                  + (ptServerData->ulDatatypeCnt) * sizeof (ptServerData->ausDataTypes[0]);

              if(0 != HilMarshallerConnTxData(pvMarshaller,
                                                     ulConnector,
                                                     ptBuffer))
              {
                HilMarshallerFreeBuffer(ptBuffer);
                TRACE_PRINT_TYPE(LOG_BUFF,"set rxbuffer to zero in HilMarshallerConnRxData HIL_CHECK_TELEGRAM");
                ptConnector->ptCurrentRxBuffer = NULL;
              } else
              {
                /* Prevent buffer from being freed by ResetRxStateMachine() while not transmitted completely. */
                  TRACE_PRINT_TYPE(LOG_BUFF,"set rxbuffer to zero in HilMarshallerConnRxData HIL_CHECK_TELEGRAM prevent bufferfree");
                ptConnector->ptCurrentRxBuffer = NULL;
              }
            }
          }
          break;

          /*TODO: Implement Administration commands (QUERY_DEVICE) */

          case HIL_TRANSPORT_TYPE_KEEP_ALIVE:
            {
              TRACE_PRINT_TYPE(LOG_COM,"check HIL_TRANSPORT_TYPE_KEEP_ALIVE\n");
              PHIL_TRANSPORT_KEEPALIVE_DATA_T ptKeepAlive = (PHIL_TRANSPORT_KEEPALIVE_DATA_T)ptConnector->ptCurrentRxBuffer->abData;
              unsigned char                   bState      = HIL_TRANSPORT_STATE_OK;
              bool                     fSendAnswer = false;
              g_ppTempRxBufferKA = &ptConnector->ptCurrentRxBuffer;
              g_ulTempRxBufferKA = (uint32_t)ptConnector->ptCurrentRxBuffer;

              //TCP_CONN ptConnector->tConn.pvUser


              //printf("ptConnector->ptCurrentRxBuffer: 0x%X\n",(unsigned int)ptConnector->ptCurrentRxBuffer);
              //printf("ptTempRxBuffer 0x%X\n", (unsigned int)ptTempRxBuffer);
              if(ptHeader->ulLength != sizeof(*ptKeepAlive))
              {
                /* Illegal length of keepalive packet */
                bState = HIL_TSTATE_LENGTH_INCOMPLETE;
                TRACE_PRINT_TYPE(LOG_COM,"keepalive HIL_TSTATE_LENGTH_INCOMPLETE\n");

              } else if(0 == ptKeepAlive->ulComID)
              {
                /* New Keepalive ID requested */

                uint32_t ulNewId = 0;
                struct timeval tv;
                gettimeofday(&tv, NULL);
                ulNewId = tv.tv_sec + tv.tv_usec / 1000; // milisec

                if(0 == ulNewId)
                  ++ptConnector->ulKeepaliveID;

                if(ulNewId == ptConnector->ulKeepaliveID)
                {
                  ptConnector->ulKeepaliveID = ~ulNewId;
                } else
                {
                  ptConnector->ulKeepaliveID = ulNewId;
                }
                TRACE_PRINT_TYPE(LOG_COM,"New Keepalive ID requested %d for Conn: %d\n", ptConnector->ulKeepaliveID, ptConnector->ulConnectorIdx);


                ptKeepAlive->ulComID       = ptConnector->ulKeepaliveID;
                fSendAnswer                = true;

              } else if(ptKeepAlive->ulComID != ptConnector->ulKeepaliveID)
              {
                /* ComID does not match, so just return a negative Acknowledge */
                //fprintf(stderr, "ComID does not match, so just return a negative Acknowledge\n");
                //fprintf(stderr,"thread 0x%X Conn: %d   recvd ptKeepAlive->ulComID %d   expected ptConnector->ulKeepaliveID %d\n", (unsigned int)pthread_self(), ptConnector->ulConnectorIdx, ptKeepAlive->ulComID , ptConnector->ulKeepaliveID);
                bState = HIL_TSTATE_KEEP_ALIVE_ERROR;
              } else
              {
                /* Everything is fine */
                  TRACE_PRINT_TYPE(LOG_COM,"good keepaliveId  %d of Conn: %d\n",ptKeepAlive->ulComID, ptConnector->ulConnectorIdx);
                ptKeepAlive->ulComID       = ptConnector->ulKeepaliveID;
                fSendAnswer                = true;
                bState = HIL_TRANSPORT_STATE_OK;
              }
              TRACE_PRINT_TYPE(LOG_COM,"send pos ka ack");
              g_ulRxPid = pthread_self();
              TRACE_PRINT_TYPE(LOG_COM,"ptConnector->ptCurrentRxBuffer: 0x%08X\n",(unsigned int)ptConnector->ptCurrentRxBuffer);
              TRACE_PRINT_TYPE(LOG_BUFF,"ptTempRxBuffer 0x%08X\n", (unsigned int)g_ulTempRxBufferKA);
              SendAcknowledge(ptMarshaller, ulConnector, &ptConnector->tRxHeader, bState);
              TRACE_PRINT_TYPE(LOG_BUFF,"ptConnector->ptCurrentRxBuffer: 0x%08X\n",(unsigned int)ptConnector->ptCurrentRxBuffer);
              TRACE_PRINT_TYPE(LOG_BUFF,"ptTempRxBuffer 0x%08X\n", (unsigned int)g_ulTempRxBufferKA);
              TRACE_PRINT_TYPE(LOG_COM,"send answer fSendAnswer %d\n", fSendAnswer);
              if(!fSendAnswer)
              {
                TRACE_PRINT_TYPE( LOG_COM|LOG_BUFF,"freebuffer (nosend)\n");
                HilMarshallerFreeBuffer(ptConnector->ptCurrentRxBuffer);
                ptConnector->ptCurrentRxBuffer = NULL;
                TRACE_PRINT_TYPE(LOG_BUFF,"ptConnector->ptCurrentRxBuffer: 0x%08X\n",(unsigned int)ptConnector->ptCurrentRxBuffer);

              } else if(0 != HilMarshallerConnTxData(pvMarshaller,
                                                            ulConnector,
                                                            ptConnector->ptCurrentRxBuffer))
              {
                HilMarshallerFreeBuffer(ptConnector->ptCurrentRxBuffer);
                TRACE_PRINT_TYPE(LOG_BUFF,"set rxbuffer to zero in HilMarshallerConnRxData HIL_TRANSPORT_TYPE_KEEP_ALIVE");
                ptConnector->ptCurrentRxBuffer = NULL;
              } else
              {
                /* Prevent buffer from being freed by ResetRxStateMachine() while not transmitted completely. */
                  TRACE_PRINT_TYPE(LOG_BUFF,"set rxbuffer to zero in HilMarshallerConnRxData HIL_TRANSPORT_TYPE_KEEP_ALIVE preventbufferfree");
                ptConnector->ptCurrentRxBuffer = NULL;
              }
            }
            break;

          default:
            {
              // TRACE_PRINT("check default");
              TRANSPORT_LAYER_DATA_T* ptTransport = FindTransportLayer(ptMarshaller, ptHeader->usDataType);
              if(NULL == ptTransport)
              {
                SendAcknowledge(ptMarshaller, ulConnector, &ptConnector->tRxHeader, HIL_TSTATE_DATA_TYPE_UNKNOWN);

                HilMarshallerFreeBuffer(ptConnector->ptCurrentRxBuffer);
                TRACE_PRINT_TYPE(LOG_BUFF,"set rxbuffer to zero in HilMarshallerConnRxData DEFAULT");
                ptConnector->ptCurrentRxBuffer = NULL;

              } else
              {
                //int                      iLock;
                HIL_MARSHALLER_BUFFER_T* ptBuffer = ptConnector->ptCurrentRxBuffer;
                TRACE_PRINT_TYPE(LOG_COM,"send ack for pending request");
                SendAcknowledge(ptMarshaller, ulConnector, &ptConnector->tRxHeader, HIL_TRANSPORT_STATE_OK);

                /* Enqueue this request into list, and let user handle it in it's own task
                   We need to set the current Rx Buffer to NULL, so that ResetRxStateMachine won't
                   free it. */
                //TRACE_PRINT("set rxbuffer to zero in HilMarshallerConnRxData userresponsibillity");
                ptConnector->ptCurrentRxBuffer = NULL;
                TRACE_PRINT_TYPE(LOG_LOCK,"tPendingRequests entering iLock");
                EnterCriticalSection(& iLock);// = OS_LOCK();
                TRACE_PRINT_TYPE(LOG_LOCK,"tPendingRequests entered iLock");
                STAILQ_INSERT_TAIL(&ptMarshaller->tPendingRequests, ptBuffer, tList);
                TRACE_PRINT_TYPE(LOG_LOCK,"tPendingRequests exiting iLock");
                LeaveCriticalSection(&iLock); //OS_UNLOCK(iLock);
                TRACE_ENTER_TYPE(LOG_COM,"pfnRequest");
                ptMarshaller->pfnRequest(ptMarshaller, ptMarshaller->pvUser);
                TRACE_EXIT_TYPE(LOG_COM,"pfnRequest");
              }
            }
            break;
          }

          /* Reset state machine */
          //TRACE_ENTER("done chekcing reset statemachine");
          ResetRxStateMachine(ptConnector);

          /* Check if we have processed all incoming data */
          if( 0 == ulDataCnt)
          {
            /* Start with scan for cookie */
            fDone = 1;
          }
        }
        break;

        default:
          ;
        break;
      } /* end switch state */

    } while (0 == fDone);

    TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerConnRxData leaving tcsRxDataLock");
    LeaveCriticalSection(&ptConnector->tcsRxDataLock);
  }

  return eRet;
}

/*****************************************************************************/
/*! Called by transport when new data should be send to line
*    \param pvMarshaller     Marshaller handle
*    \param ulConnector      Connector number
*    \param ptBuffer         Outgoing data
*    \return 0 on success                                             */
/*****************************************************************************/
uint32_t HilMarshallerConnTxData(void* pvMarshaller, uint32_t ulConnector, HIL_MARSHALLER_BUFFER_T* ptBuffer)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  CONNECTOR_DATA_T*      ptConn       = &ptMarshaller->atConnectors[ulConnector];
  uint32_t 				       ulRet = 0;
  /*if (ptBuffer == 0)
  {
  	return 1;
  }*/
  TRACE_PRINT_TYPE(LOG_BUFF,"befor buffer length HilMarshallerConnTxData 0x%08X \n", (unsigned int)ptBuffer);
  ptBuffer->tTransport.ulLength = ptBuffer->tMgmt.ulUsedDataBufferLen;

  if(ptBuffer->tTransport.ulLength > 0)
  {
  	// no more checksum since medium is save
    ptBuffer->tTransport.usChecksum = 0; /* CalculateCRC16(ptBuffer->abData, ptBuffer->tTransport.ulLength);*/
  }
  //TRACE_ENTER("pfnTransmit");
  ulRet = 	ptConn->tConn.pfnTransmit(ptBuffer, ptConn->tConn.pvUser);
  if (ulRet != 0)
  {
    ptConn->tConn.pfnShutdown(ptConn->tConn.pvUser);
  }

  //TRACE_EXIT("pfnTransmit");
  return ulRet;
}

/*****************************************************************************/
/*! Called by transport when new data should be send to line
 *  like HilMarshallerConnTxData but with additional pointer to buffer for
 *  direct read no copy and no crc creation
*    \param pvMarshaller     Marshaller handle
*    \param ulConnector      Connector number
*    \param ptBuffer         Outgoing data
*    \return 0 on success                                             */
/*****************************************************************************/
uint32_t HilMarshallerConnTxCallbackData(void* pvMarshaller, uint32_t ulConnector, HIL_MARSHALLER_BUFFER_T* ptBuffer, void* pvNetANABuffer,unsigned long ulLength)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  CONNECTOR_DATA_T*      ptConn       = &ptMarshaller->atConnectors[ulConnector];
  uint32_t 							 ulRet = 0;

  if (ptBuffer == 0)
  {
  	return 1;
  }

  ptBuffer->tTransport.ulLength = sizeof(NETANA_MARSHALLER_DATA_FRAME_HEADER_T) + ulLength;
  
  
  ptBuffer->tTransport.usChecksum = 0;
  /*//no checksum for datacallbacks 
  if(ptBuffer->tTransport.ulLength > 0)
  {
    ptBuffer->tTransport.usChecksum = CalculateCRC16(ptBuffer->abData,
                                                     ptBuffer->tTransport.ulLength);
  }*/
  //TRACE_ENTER("pfnTransmitData");

  ulRet = ptConn->tConn.pfnTransmitData(ptBuffer, pvNetANABuffer, ulLength, ptConn->tConn.pvUser); //send data from buffer
  if (ulRet != 0 )
  {
    ptConn->tConn.pfnShutdown(ptConn->tConn.pvUser);
  }

  //TRACE_EXIT("pfnTransmitData");
  return ulRet;
}

/*****************************************************************************/
/*! Called by connector data has been sent
*    \param pvMarshaller     Marshaller handle
*    \param ulConnector      Connector number
*    \param ptBuffer         Outgoing data buffer
*    \return 0 on success                                             */
/*****************************************************************************/
uint32_t HilMarshallerConnTxComplete(void* pvMarshaller, uint32_t ulConnector, HIL_MARSHALLER_BUFFER_T* ptBuffer)
{
	//TRACE_ENTER("HilMarshallerConnTxComplete");
  TRACE_PRINT_TYPE(LOG_BUFF,"freebuffer in txcomplete 0x%08X\n",(uint32_t)ptBuffer);
  HilMarshallerFreeBuffer(ptBuffer);
  //TRACE_EXIT("HilMarshallerConnTxComplete");
  return 0;
}

/*****************************************************************************/
/*! Called by transport layer, during initialization.
*    \param pvMarshaller     Marshaller handle
*    \param ptLayerData      Layer registration data
*    \return 0 on success                                             */
/*****************************************************************************/
uint32_t HilMarshallerRegisterTransport(void* pvMarshaller, const TRANSPORT_LAYER_DATA_T* ptLayerData)
{
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  bool eRet;

  if(0 == ptLayerData->usDataType)
  {
    eRet = HIL_MARSHALLER_E_INVALIDPARAMETER;

  } else if(NULL != FindTransportLayer(ptMarshaller, ptLayerData->usDataType))
  {
    /* Another Transport layer is already registered for this datatype (configuration error) */
    eRet = HIL_MARSHALLER_E_ALREADYREGISTERED;
  } else
  {
    uint32_t ulIdx;

    eRet = HIL_MARSHALLER_E_OUTOFRESOURCES;

    /* Search first free array element */
    for(ulIdx = 0; ulIdx < ptMarshaller->ulTransports; ++ulIdx)
    {
      TRANSPORT_LAYER_DATA_T* ptLayer = &ptMarshaller->ptTransports[ulIdx];

      if(0 == ptLayer->usDataType)
      {
        *ptLayer = *ptLayerData;
        eRet = 0;
        break;
      }
    }
  }

  return eRet;
}

/*****************************************************************************/
/*! Called by transport layer, during uninitialization.
*    \param pvMarshaller     Marshaller handle
*    \param usDataType       Datatype the layer was registered at           */
/*****************************************************************************/
void HilMarshallerUnregisterTransport(void* pvMarshaller, uint16_t usDataType)
{
  HIL_MARSHALLER_DATA_T*  ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  TRANSPORT_LAYER_DATA_T* ptLayer      = FindTransportLayer(ptMarshaller, usDataType);

  if(ptLayer != NULL)
  {
    memset(ptLayer, 0, sizeof(*ptLayer));
  }
}

/*****************************************************************************/
/*! Cyclic timer event, which needs to be called by user for timeout management
*    \param pvMarshaller     Marshaller handle                              */
/*****************************************************************************/
void HilMarshallerTimer(void* pvMarshaller)
{
  uint32_t              ulIdx;
  HIL_MARSHALLER_DATA_T*  ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshaller;

  /* Check all transports for polling functions */
  for(ulIdx = 0; ulIdx < ptMarshaller->ulTransports; ++ulIdx)
  {
    TRANSPORT_LAYER_DATA_T* ptLayer = &ptMarshaller->ptTransports[ulIdx];

    if(ptLayer->pfnPoll)
      ptLayer->pfnPoll(ptLayer->pvUser);
  }

  /* Check all connectors for polling functions */
  for(ulIdx = 0; ulIdx < ptMarshaller->ulMaxConnectors; ++ulIdx)
  {
    CONNECTOR_DATA_T* ptConn = &ptMarshaller->atConnectors[ulIdx];

    /* Timeout management for all connector Rx state machines */
    /* Check if the RX state machine is active */
    if(ptConn->fMonitorTimeout)
    {
      /* Incremet the elapsed time */
      ptConn->ulElapsedTime += 10;

      if( ptConn->tConn.ulTimeout < ptConn->ulElapsedTime)
      {
        /* we shut down socket first so ther is nothing receved anymore and rxMachines is not entered
         * then we reset the machine and
         * */
        TRACE_PRINT_TYPE(LOG_LOCK, "Entering tcsRxDataLock in timer");
        EnterCriticalSection(&ptConn->tcsRxDataLock);
        TRACE_PRINT_TYPE(LOG_LOCK, "Entered tcsRxDataLock in timer");
        TRACE_PRINT_TYPE(LOG_COM|LOG_THREADS|LOG_BUFF,"timer ResetRxStateMachine shutdown Conn: %d\n", ulIdx);
        ptConn->tConn.pfnShutdown(ptConn->tConn.pvUser); // does something like ptConn->tConn.pfnDeinit(ptConn->tConn.pvUser); // but not the listening thread
        TRACE_PRINT_TYPE(LOG_THREADS,"TimerThreadid 0x%08X RxThreadid 0x%08X",(uint32_t)pthread_self(), g_ulRxPid);
        ResetRxStateMachine( ptConn);

        // TRACE_PRINT("ResetRxStateMachine leaving tcsRxDataLock");
        TRACE_PRINT_TYPE(LOG_LOCK, "Leaving tcsRxDataLock in timer");
        LeaveCriticalSection(&ptConn->tcsRxDataLock);

        // we dont need to unregister the connector data (ptConn) here this is done in clientthread termination
        // HilMarshallerUnregisterConnector(pvMarshaller, ulIdx);

      }
    }

    if(ptConn->fInUse && ptConn->tConn.pfnPoll)
      ptConn->tConn.pfnPoll(ptConn->tConn.pvUser);
  }
}
/*****************************************************************************/
/*! Main marshaller module. This must be called by user, every time it receives
*   the pfnRequest callback.
*    \param pvMarshaller     Marshaller handle
*    \return 0 on success
*    \and TLR_E_FAIL if no message retrieved from the pending requests list  */
/*****************************************************************************/
uint32_t HilMarshallerMain(void* pvMarshaller)
{
  bool               eRet            = 0;
  HIL_MARSHALLER_DATA_T*   ptMarshaller    = (HIL_MARSHALLER_DATA_T*) pvMarshaller;
  //int                      iLock           = 0;
  HIL_MARSHALLER_BUFFER_T* ptBuffer        = NULL;
  TRANSPORT_LAYER_DATA_T*  ptTransport     = NULL;
  CONNECTOR_DATA_T*        ptConn          = NULL;

  if (ptMarshaller == NULL)
    eRet = true;
  else
  {
    TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerMain entering iLock checking request queue");
    EnterCriticalSection(&iLock);  // = OS_LOCK();
    TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerMain entered iLock checking request queue");
    ptBuffer = STAILQ_FIRST(&ptMarshaller->tPendingRequests);
    TRACE_PRINT_TYPE(LOG_LOCK,"HilMarshallerMain leaving iLock checking request queue");
    LeaveCriticalSection(&iLock);     // OS_UNLOCK(iLock);
    if (ptBuffer == NULL)
      eRet = true;
    else
    {
      ptTransport = FindTransportLayer(ptMarshaller, ptBuffer->tTransport.usDataType);
      ptConn      = &ptMarshaller->atConnectors[ptBuffer->tMgmt.ulConnectorIdx];
      if (ptTransport == NULL || ptConn == NULL)
        eRet = true;
      else
      {
        TRACE_PRINT_TYPE(LOG_LOCK,"entering iLock in HilMarshallerMain for removing buffer from request queue");
        EnterCriticalSection(&iLock); //iLock = OS_LOCK();
        TRACE_PRINT_TYPE(LOG_LOCK,"entered iLock in HilMarshallerMain now removing request from list");
        STAILQ_REMOVE(&ptMarshaller->tPendingRequests, ptBuffer, HIL_MARSHALLER_BUFFER_Ttag, tList);
        TRACE_PRINT_TYPE(LOG_LOCK,"leaving iLock in HilMarshallerMain for removing buffer from request queue");
        LeaveCriticalSection(&iLock);//OS_UNLOCK(iLock);

        ptTransport->pfnHandler(ptMarshaller, ptBuffer, ptTransport->pvUser);
      }
    }
  }
  return eRet;
}


/*****************************************************************************/
/*! HilMarshallerSetMode() sets the mode (unrestricted / restricted / disabled)
*   either of a single connector or of all connectors.
*   \param pvMarshaller     Marshaller handle
*   \param ulMode           see MARSHALLER_MODE_xxx constants above
*   \param ulConnectorID    connector index or MARSHALLER_CONNECTORS_ALL
*   \return 0        on success
*   \ HIL_MARSHALLER_E_INVALIDPARAMETER  if mode invalid
*   \ HIL_MARSHALLER_E_OUTOFRESOURCES    if connector reference invalid      */
/*****************************************************************************/

uint32_t HilMarshallerSetMode(void*      pvMarshaller,
                                uint32_t ulMode,
                                uint32_t ulConnectorID)

{
  uint32_t             eRet         = 0;
  HIL_MARSHALLER_DATA_T* ptMarshaller = (HIL_MARSHALLER_DATA_T*)pvMarshaller;
  uint32_t             ulIndex;
  uint32_t             ulMinConnectorID = ulConnectorID;
  uint32_t             ulMaxConnectorID = ulConnectorID;

  /* check the scope of the command (single connector / all connectors) */
  if (ulConnectorID == HIL_MARSHALLER_CONNECTORS_ALL)
  { /* change mode of all connectors */
    ulMinConnectorID = 0;
    ulMaxConnectorID = ptMarshaller->ulMaxConnectors;
  }
  else
  { /* check the given connector index */
    if (ulConnectorID > ptMarshaller->ulMaxConnectors)
      eRet = HIL_MARSHALLER_E_OUTOFRESOURCES;
  }
  if (eRet == 0)

  {
    switch (ulMode)
    {
      case HIL_MARSHALLER_MODE_ENABLED:
      { /* set mode for a single connector or for all connectors */
        for (ulIndex = ulMinConnectorID; ulIndex < ulMaxConnectorID; ulIndex++)
          ptMarshaller->atConnectors[ulIndex].ulMode = ulMode;
        break;
      }
      case HIL_MARSHALLER_MODE_DISABLED:
      { /* set mode for a single connector or for all connectors */
        for (ulIndex = ulMinConnectorID; ulIndex < ulMaxConnectorID; ulIndex++)
          ptMarshaller->atConnectors[ulIndex].ulMode = ulMode;
        break;
      }
      default:
      { /* invalid mode parameter */
        eRet = HIL_MARSHALLER_E_INVALIDPARAMETER;
        break;
      }
    }
  }
  return (eRet);
}
