/**************************************************************************************
 
   Copyright (c) Hilscher GmbH. All Rights Reserved.
 
 **************************************************************************************
 
   Filename:
    $Workfile: netANATransport.h $
   Last Modification:
    $Author: MichaelT $
    $Modtime: $
    $Revision: 1034 $
   
   Targets:
     Win32/ANSI   : yes
     Win32/Unicode: yes (define _UNICODE)
     WinCE        : yes
 
   Description:
    Defines for the "netANA Modul" of the "Marshaller" device side 
       
   Changes:
 
     Version   Date        Author   Description
     ----------------------------------------------------------------------------------
     1         25.05.2009  PL       intitial version
 
**************************************************************************************/

/*****************************************************************************/
/*! \file netANATransport.h
*   netANA marshalling via Hilscher Transport Protocol                         */
/*****************************************************************************/
// #pragma once
#ifndef __NETANATRANSPORT__H
#define __NETANATRANSPORT__H

/*****************************************************************************/
/*! \addtogroup NETX_MARSHALLER_netANA
*   \{                                                                       */
/*****************************************************************************/

#ifdef __cplusplus
  extern "C" {
#endif  /* __cplusplus */

#include "MarshallerConfig.h"
#include "netANAAPI_Wrapper.h"

/* Init information for the netANA Transport */
typedef struct netANA_TRANSPORT_CONFIG_Ttag
{
  DRIVER_FUNCTIONS  tDRVFunctions; /*!  Function list of netANA API   */  
} netANA_TRANSPORT_CONFIG;

/* Initialize a Transport */
uint32_t netANATransportInit(void* pvMarshaller, void* pvConfig);

#ifdef __cplusplus
  }
#endif  /* __cplusplus */

/*****************************************************************************/
/*! \}                                                                       */
/*****************************************************************************/

#endif /* __NETANAXTRANSPORT__H */
