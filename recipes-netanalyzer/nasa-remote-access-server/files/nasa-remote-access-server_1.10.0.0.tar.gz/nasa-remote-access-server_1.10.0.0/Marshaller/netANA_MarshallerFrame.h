/**************************************************************************************
 
   Copyright (c) Hilscher GmbH. All Rights Reserved.
 
 **************************************************************************************
 
   Filename:
    $Workfile: OS_Dependent.h $
   Last Modification:
    $Author: sebastiand $
    $Modtime: 4.05.07 15:17 $
    $Revision: 1776 $
   
   Targets:
     Win32/ANSI   : yes
     Win32/Unicode: yes (define _UNICODE)
     WinCE        : yes
 
   Description:
    Definitions of data structures for marshaller data
       
   Changes:
 
     Version   Date        Author   Description
     ----------------------------------------------------------------------------------
     2         25.06.2010  SD       Change:
                                     - changed types (for 64-bit support)
     1         07.07.2006  MT       intitial version
 
**************************************************************************************/

#ifndef __NETANA_MARSHALLERFRAME__H
#define __NETANA_MARSHALLERFRAME__H

#include "../SDK/netana_user.h"

#define NETANA_MARSHALLER_SUBIDX_SYSTEMCHANNEL        0xFF             /*!< Currently not in use */

#define NETANA_MARSHALLER_COM_METHODID_SERVERVERSION        0x00000000 /*!< Class Factory: MethodID for querying ServerVersion                   */
#define NETANA_MARSHALLER_COM_METHODID_CREATEINSTANCE       0x00000001 /*!< Class Factory: MethodID for Creating/Getting a handle to a new object_Type (DriverObject) */

#define NETANA_MAX_INFO_NAME_LENGTH                 16
#define NETANA_FULL_PATH_NAME_LENGTH                260  /* this must match MAX_PATH from windows */

#define DEV_FILE_DOWNLOAD_REQ                         0x00001E62
#define DEV_FILE_DOWNLOAD_CNF                         0x00001E63
#define DEV_FILE_DOWNLOAD_DATA_REQ                    0x00001E64
#define DEV_FILE_DOWNLOAD_DATA_CNF                    0x00001E65

#define DEV_FILE_DOWNLOAD_ABORT_REQ                   0x00001E66
#define DEV_FILE_DOWNLOAD_ABORT_CNF                   0x00001E67

#define DEV_PACKET_SEQ_NR_MASK                        0x0000003f      /*!< Packet sequence number mask */
#define DEV_PACKET_SEQ_MASK                           0x000000c0      /*!< Mask for the sequence bits */
#define DEV_PACKET_SEQ_NONE                           0x00000000      /*!< No packet sequence */
#define DEV_PACKET_SEQ_FIRST                          0x00000080      /*!< First packet of a sequence */
#define DEV_PACKET_SEQ_MIDDLE                         0x000000c0      /*!< Packet in a sequence */
#define DEV_PACKET_SEQ_LAST                           0x00000040      /*!< Last packet of a sequence */


/*****************************************************************************/
/*! netANALYZER MethodIDs   */
/*****************************************************************************/

#define NETANA_MARSHALLER_OBJECT_TYPE_COMMUNICATION   0x00
#define NETANA_MARSHALLER_OBJECT_TYPE_DRIVER          0x01
#define NETANA_MARSHALLER_OBJECT_TYPE_DEVICE          0x02
#define NETANA_MARSHALLER_OBJECT_TYPE_CALLBACK        0x03
#define NETANA_MARSHALLER_OBJECT_TYPE_MNGMT           0x04

#define NETANA_MARSHALLER_DRV_METHODID_GETINFO              0x00000001 /*!< Driver Object: netana_driver_information    */
#define NETANA_MARSHALLER_DRV_METHODID_ERRORDESCR           0x00000002 /*!< Driver Object: netana_get_error_description */
#define NETANA_MARSHALLER_DRV_METHODID_ENUMDEV              0x00000003 /*!< Driver Object: netana_enum_device           */
#define NETANA_MARSHALLER_DRV_METHODID_OPENDEV              0x00000004 /*!< Driver Object: netana_open_device           */
#define NETANA_MARSHALLER_DRV_METHODID_CLOSEDEV             0x00000005 /*!< Driver Object: netana_close_device          */

#define NETANA_MARSHALLER_DEV_METHODID_INFO                 0x00000001 /*!< Device Object: netana_device_info           */
#define NETANA_MARSHALLER_DEV_METHODID_PORTSTAT	            0x00000002 /*!< Device Object: netana_get_portstat          */
#define NETANA_MARSHALLER_DEV_METHODID_GETSTATE	            0x00000003 /*!< Device Object: netana_get_state             */
#define NETANA_MARSHALLER_DEV_METHODID_ACCESPHYREG	        0x00000004 /*!< Device Object: netana_access_phy_reg        */
#define NETANA_MARSHALLER_DEV_METHODID_SETFILELIST	        0x00000005 /*!< Device Object: netana_set_filelist          */
#define NETANA_MARSHALLER_DEV_METHODID_GETGPIOMODE	        0x00000006 /*!< Device Object: netana_get_gpio_mode         */
#define NETANA_MARSHALLER_DEV_METHODID_SETGPIOMODE	        0x00000007 /*!< Device Object: netana_set_gpio_mode         */
#define NETANA_MARSHALLER_DEV_METHODID_GETFILTER            0x00000008 /*!< Device Object: netana_get_filter            */
#define NETANA_MARSHALLER_DEV_METHODID_SETFILTER            0x00000009 /*!< Device Object: netana_set_filter            */
#define NETANA_MARSHALLER_DEV_METHODID_FILEINFO	            0x0000000A /*!< Device Object: netana_file_info             */
#define NETANA_MARSHALLER_DEV_METHODID_STARTCAPTURE	        0x0000000B /*!< Device Object: netana_start_capture         */
#define NETANA_MARSHALLER_DEV_METHODID_STOPCAPTURE	        0x0000000C /*!< Device Object: netana_stop_capture          */
#define NETANA_MARSHALLER_DEV_METHODID_SETGPIOOUTPUT        0x0000000D /*!< Device Object: netana_set_gpio_output       */
#define NETANA_MARSHALLER_DEV_METHODID_RESYNCTIME           0x0000000E /*!< Device Object: netana_resync_time           */
#define NETANA_MARSHALLER_DEV_METHODID_CONFIGPICTRL         0x0000000F /*!< Device Object: netana_config_pi_controller  */
#define NETANA_MARSHALLER_DEV_METHODID_SETGPIOVOLTAGE       0x00000010 /*!< Device Object: netana_set_gpio_voltage      */
#define NETANA_MARSHALLER_DEV_METHODID_GETGPIOVOLTAGE       0x00000011 /*!< Device Object: netana_get_gpio_voltage      */
#define NETANA_MARSHALLER_DEV_METHODID_SETDEVICEIDENT       0x00000012 /*!< Device Object: netanaMa_set_device_ident    */
#define NETANA_MARSHALLER_DEV_METHODID_DOWNLOADDATA         0x00000013 /*!< Device Object: download data into file      */
#define NETANA_MARSHALLER_DEV_METHODID_DOWNLOADABORT        0x00000014 /*!< Device Object: abort download               */ 
#define NETANA_MARSHALLER_DEV_METHODID_GETDEVICEIDENT       0x00000015 /*!< Device Object: netanaMa_get_device_ident    */
#define NETANA_MARSHALLER_DEV_METHODID_CHECKDEVICEIDENT     0x00000016 /*!< Device Object: netanaMa_check_device_ident  */
#define NETANA_MARSHALLER_DEV_METHODID_SIGNALDRIVERERROR    0x00000017 /*!< Device Object: netanaMa_signal_driver_error */
#define NETANA_MARSHALLER_DEV_METHODID_GETPACKET            0x00000018 /*!< Device Object: netana_get_packet            */
#define NETANA_MARSHALLER_DEV_METHODID_PUTPACKET            0x00000019 /*!< Device Object: netana_put_packet            */
#define NETANA_MARSHALLER_DEV_METHODID_GETMBXSTATE          0x0000001A /*!< Device Object: netana_get_mbx_state         */


#define NETANA_MARSHALLER_CALLBACK_METHODID_STATUS          0x00000001 /*!< Callback Object: StatusCallback             */
#define NETANA_MARSHALLER_CALLBACK_METHODID_DATA            0x00000002 /*!< Callback Object: DataCallback               */
#define NETANA_MARSHALLER_CALLBACK_METHODID_SCAN            0x00000003 /*!< Callback Object: DataCallback               */

#define NETANA_MARSHALLER_MNGMT_BLINK                       0x00000001 /*!< Managment Object: netana_mngmt_exec_cmd: blink                */
#define NETANA_MARSHALLER_MNGMT_SCAN                        0x00000002 /*!< Managment Object: netana_mngmt_exec_cmd: scan                 */
#define NETANA_MARSHALLER_MNGMT_SETDEVCLASS                 0x00000003 /*!< Managment Object: netana_mngmt_exec_cmd: set device class filter  */
#define NETANA_MARSHALLER_MNGMT_GETDEVFEATURE	              0x00000004 /*!< Managment Object: netana_mngmt_exec_cmd: get device features      */

/*****************************************************************************/
/*! Marshaller handle definition (not valid for old device implementation)   */
/*****************************************************************************/
#define MSK_MARSHALLER_HANDLE_VALID         0x80000000
#define SRT_MARSHALLER_HANDLE_VALID         31
#define MSK_MARSHALLER_HANDLE_OBJECTSUBIDX  0x00FF0000
#define SRT_MARSHALLER_HANDLE_OBJECTSUBIDX  16
#define MSK_MARSHALLER_HANDLE_OBJECTIDX     0x0000FF00
#define SRT_MARSHALLER_HANDLE_OBJECTIDX     8
#define MSK_MARSHALLER_HANDLE_OBJECTTYPE    0x000000FF
#define SRT_MARSHALLER_HANDLE_OBJECTTYPE    0

#define MSK_MARSHALLER_SEQUENCE_REQUEST     0x00000001
#define SRT_MARSHALLER_SEQUENCE_REQUEST     0
#define MSK_MARSHALLER_SEQUENCE_SUPPORTED   0x00000002
#define SRT_MARSHALLER_SEQUENCE_SUPPORTED   1
#define MSK_MARSHALLER_SEQUENCE_NUMBER      0xFFFF0000
#define SRT_MARSHALLER_SEQUENCE_NUMBER      16

/*! Marshaller handle definition (not valid for old device implementation)   */
/*****************************************************************************/

/*****************************************************************************/
/*! Marshaller handle definition (not valid for old device implementation)   */
/*****************************************************************************/
typedef union NETANA_MARSHALLER_HANDLE_Utag
{
  struct NETANA_MARSHALLER_HANDLE_BF_Ttag
  {
    uint32_t bObjectType    : 8; /*!< Type of the Object see NETANA_MARSHALLER_OBJECT_TYPE_XXX defines       */
    uint32_t bObjectIdx     : 8; /*!< Idx of the Object, i.e. Board number                            */
    uint32_t bObjectSubIdx  : 8; /*!< SubIdx of the Object (0..6 for Channels, 0 for Sysdevice/Driver */
    uint32_t bReserved      : 7; /*!< SubIdx of the Object (0..6 for Channels, 0 for Sysdevice/Driver */
    uint32_t fValid         : 1; /*!< 1 to show this is a valid handle                                */
    
  } tBfHandle;
  uint32_t ulHandle;   /*!< Returned handle from DriverOpen/ChannelOpen/SysDeviceOpen functions */
  
} NETANA_MARSHALLER_HANDLE_U, *PNETANA_MARSHALLER_HANDLE_U;


typedef union NETANA_MARSHALLER_SEQUENCE_Utag
{
  struct NETANA_MARSHALLER_SEQUENCE_BF_Ttag
  {
    uint32_t fRequest       :1;   /*!< 1=Request, 0 = Answer                                  */
    uint32_t fSeqNrSupport  :1;   /*!< Sequence number supported                              */
    uint32_t uiReserved     :14;  /*!< Reserved for future use. Set to 0                      */
    uint32_t usSequenceNr   :16;  /*!< Sequence number, used to associate answer with request */
  } tBfSequence;
  uint32_t ulSequence;   /*!< Sequence number, to associate request/answer                  */
} NETANA_MARSHALLER_SEQUENCE_U, *PNETANA_MARSHALLER_SEQUENCE_U;



typedef struct NETANA_MARSHALLER_DATA_FRAME_HEADER_Ttag
{
  uint32_t ulHandle;    /*!< Marshaller handle                                             */
  uint32_t ulMethodID;  /*!< ID of the method to execute                                   */
  uint32_t ulSequence;  /*!< Sequence number, to associate request/answer                  */
  uint32_t ulError;     /*!< Error, used on Answer, to indicate function return value      */
  uint32_t ulDataSize;  /*!< Length of following data                                      */
  
} NETANA_MARSHALLER_DATA_FRAME_HEADER_T, *PNETANA_MARSHALLER_DATA_FRAME_HEADER_T;


/*****************************************************************************
  _____                                      _           _   _             
 / ____|                                    (_)         | | (_)            
| |     ___  _ __ ___  _ __ ___  _   _ _ __  _  ___ __ _| |_ _  ___  _ __  
| |    / _ \| '_ ` _ \| '_ ` _ \| | | | '_ \| |/ __/ _` | __| |/ _ \| '_ \ 
| |___| (_) | | | | | | | | | | | |_| | | | | | (_| (_| | |_| | (_) | | | |
 \_____\___/|_| |_| |_|_| |_| |_|\__,_|_| |_|_|\___\__,_|\__|_|\___/|_| |_|
*****************************************************************************/


/*****************************************************************************/
/*! Cummunication - Create instance request                                  */
/*****************************************************************************/
typedef struct COM_CREATEINSTANCE_REQ_DATA_Ttag
{
  uint32_t ulObjectType;  /*!< Object type to generate (see NETANA_MARSHALLER_OBJECT_TYPE_XXX defines */

} COM_CREATEINSTANCE_REQ_DATA_T, *PCOM_CREATEINSTANCE_REQ_DATA_T;

typedef struct COM_CREATEINSTANCE_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T tHeader;
  COM_CREATEINSTANCE_REQ_DATA_T   tData;

} COM_CREATEINSTANCE_REQ_T, *PCOM_CREATEINSTANCE_REQ_T;

/*****************************************************************************/
/*! Communication - Create instance confirmation                             */
/*****************************************************************************/
typedef struct COM_CREATEINSTANCE_CNF_DATA_Ttag
{
  NETANA_MARSHALLER_HANDLE_U uHandle;  /*!< Handle returned for future use. This handle must be used to communicate with the created object */
  
} COM_CREATEINSTANCE_CNF_DATA_T, *POM_CREATEINSTANCE_CNF_DATA_T;

typedef struct COM_CREATEINSTANCE_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  COM_CREATEINSTANCE_CNF_DATA_T    tData;

} COM_CREATEINSTANCE_CNF_T, *PCOM_CREATEINSTANCE_CNF_T;

/*****************************************************************************/
/*! Communication - Query netANA marshaller version confirmation               */
/*****************************************************************************/
typedef struct COM_SERVERVERSION_CNF_DATA_Ttag
{
  uint32_t ulVersion;  /*!< Returned version */
 
} COM_SERVERVERSION_CNF_DATA_T, *PCOM_SERVERVERSION_CNF_DATA_T;

typedef struct COM_SERVERVERSION_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  COM_SERVERVERSION_CNF_DATA_T     tData;
  
} COM_SERVERVERSION_CNF_T, *PCOM_SERVERVERSION_CNF_T;


/*****************************************************************************
  ____           _                            ___    _        _                 _   
 |  _ \   _ __  (_) __   __   ___   _ __     / _ \  | |__    (_)   ___    ___  | |_ 
 | | | | | '__| | | \ \ / /  / _ \ | '__|   | | | | | '_ \   | |  / _ \  / __| | __|
 | |_| | | |    | |  \ V /  |  __/ | |      | |_| | | |_) |  | | |  __/ | (__  | |_ 
 |____/  |_|    |_|   \_/    \___| |_|       \___/  |_.__/  _/ |  \___|  \___|  \__|
                                                           |__/                     
*****************************************************************************/

/*****************************************************************************/
/*! Driver - netana_driver_information request                                   */
/*****************************************************************************/
typedef struct DRV_GETINFO_REQ_DATA_Ttag
{
  uint32_t ulSize; /*!< Number of byte to return in confirmation */
  
} DRV_GETINFO_REQ_DATA_T, *PDRV_GETINFO_REQ_DATA_T;

typedef struct DRV_GETINFO_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_GETINFO_REQ_DATA_T   tData;
  
} DRV_GETINFO_REQ_T, *PDRV_GETINFO_REQ_T;


/*****************************************************************************/
/*! Driver - netana_driver_information confirmation                    */
/*****************************************************************************/
typedef struct DRV_GETINFO_CNF_DATA_Ttag
{
   NETANA_DRIVER_INFORMATION_T tDriverInfo;            /*!< device info structure       */  
} DRV_GETINFO_CNF_DATA_T, *PDRV_GETINFO_CNF_DATA_T;

typedef struct DRV_GETINFO_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_GETINFO_CNF_DATA_T          tData;
  
} DRV_GETINFO_CNF_T, *PDRV_GETINFO_CNF_T;




/*****************************************************************************/
/*! Driver - netana_get_error_description request                                       */
/*****************************************************************************/
typedef struct DRV_ERRORDESCR_REQ_DATA_Ttag
{
  uint32_t ulSize;  /*!< length of ErrorDesciptionString */
  uint32_t ulError; /*!< Errorcode */

} DRV_ERRORDESCR_REQ_DATA_T, *PDRV_ERRORDESCR_REQ_DATA_T;

typedef struct DRV_ERRORDESCR_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_ERRORDESCR_REQ_DATA_T        tData;
  
} DRV_ERRORDESCR_REQ_T, *PDRV_ERRORDESCR_REQ_T;


/*****************************************************************************/
/*! Driver - netana_get_error_description confirm                                       */
/*****************************************************************************/
typedef struct DRV_ERRORDESCR_CNF_DATA_Ttag
{
  char* szErrorDescription; /*!< Error describing string */

} DRV_ERRORDESCR_CNF_DATA_T, *PDRV_ERRORDESCR_CNF_DATA_T;

typedef struct DRV_ERRORDESCR_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_ERRORDESCR_CNF_DATA_T       tData;
  
} DRV_ERRORDESCR_CNF_T, *PDRV_ERRORDESCR_CNF_T;



/*****************************************************************************/
/*! Driver - netana_enum_device request                                       */
/*****************************************************************************/
typedef struct DRV_ENUMDEV_REQ_DATA_Ttag
{
  uint32_t ulBoard;  /*!< Board number */
  uint32_t ulSize;   /*!< Size of the returned board information (in confirmation) */
  
} DRV_ENUMDEV_REQ_DATA_T, *PDRV_ENUMDEV_REQ_DATA_T;

typedef struct DRV_ENUMDEV_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_ENUMDEV_REQ_DATA_T          tData;
  
} DRV_ENUMDEV_REQ_T, *PDRV_ENUMDEV_REQ_T;

/*****************************************************************************/
/*! Driver - netana_enum_device confirmation                    */
/*****************************************************************************/
typedef struct DRV_ENUMDEV_CNF_DATA_Ttag
{
   NETANA_DEVICE_INFORMATION_T tDeviceInfo;            /*!< device info structure       */  
} DRV_ENUMDEV_CNF_DATA_T, *PDRV_ENUMDEV_CNF_DATA_T;

typedef struct DRV_ENUMDEV_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_ENUMDEV_CNF_DATA_T          tData;
  
} DRV_ENUMDEV_CNF_T, *PDRV_ENUMDEV_CNF_T;

/*****************************************************************************/
/*! Driver - netana_open_device request                                     */
/*****************************************************************************/
typedef struct DRV_OPENDEV_REQ_DATA_Ttag
{
  uint32_t ulBoardNameSize;    /*!< Board  name size */
  char          szBoardname[NETANA_MAX_INFO_NAME_LENGTH];       /*!< Board name */ 

} DRV_OPENDEV_REQ_DATA_T, *PDRV_OPENDEV_REQ_DATA_T;

typedef struct DRV_OPENDEV_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_OPENDEV_REQ_DATA_T          tData;
  
} DRV_OPENDEV_REQ_T, *PDRV_OPENDEV_REQ_T;

/*****************************************************************************/
/*! Driver - netana_open_device confirm              */
/*****************************************************************************/
typedef struct DRV_OPENDEV_CNF_DATA_Ttag
{
  NETANA_MARSHALLER_HANDLE_U uHandle;    /*!< Handle to device */

} DRV_OPENDEV_CNF_DATA_T, *PDRV_OPENDEV_CNF_DATA_T;

typedef struct DRV_OPENDEV_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_OPENDEV_CNF_DATA_T          tData;
  
} DRV_OPENDEV_CNF_T, *PDRV_OPENDEV_CNF_T;


/*****************************************************************************/
/*! Driver - netana_close_device request                                     */
/*****************************************************************************/
typedef struct DRV_CLOSEDEV_REQ_DATA_Ttag
{
  uint32_t hDevice;    /*!< Board  name size */
  
} DRV_CLOSEDEV_REQ_DATA_T, *PDRV_CLOSEDEV_REQ_DATA_T;

typedef struct DRV_CLOSEDEV_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DRV_CLOSEDEV_REQ_DATA_T         tData;
  
} DRV_CLOSEDEV_REQ_T, *PDRV_CLOSEDEV_REQ_T;


/*****************************************************************************
      _                  _               
   __| |   ___  __   __ (_)   ___    ___         
  / _` |  / _ \ \ \ / / | |  / __|  / _ \      
 | (_| | |  __/  \ V /  | | | (__  |  __/     
  \__,_|  \___|   \_/   |_|  \___|  \___|                
                                            
          _        _                 _   
   ___   | |__    (_)   ___    ___  | |_ 
  / _ \  | '_ \   | |  / _ \  / __| | __|
 | (_) | | |_) |  | | |  __/ | (__  | |_ 
  \___/  |_.__/   / |  \___|  \___|  \__|
                |__/                     
*****************************************************************************/


/*****************************************************************************/
/*! device - netana_device_info request                          */
/*****************************************************************************/
typedef struct DEV_INFO_REQ_DATA_Ttag
{
  uint32_t ulSize;                               /*!< Size of the return structure   */
  
} DEV_INFO_REQ_DATA_T, *PDEV_INFO_REQ_DATA_T;

typedef struct DEV_INFO_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DEV_INFO_REQ_DATA_T         tData;
  
} DEV_INFO_REQ_T, *PDEV_INFO_REQ_T;


/*****************************************************************************/
/*! device - netana_device_info confirmation                   */
/*****************************************************************************/
typedef struct DEV_INFO_CNF_DATA_Ttag
{
  NETANA_DEVICE_INFORMATION_T tDeviceInfo;            /*!< device info structure       */  
} DEV_INFO_CNF_DATA_T, *PDEV_INFO_CNF_DATA_T;

typedef struct DEV_INFO_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DEV_INFO_CNF_DATA_T             tData;
  
} DEV_INFO_CNF_T, *PDEV_INFO_CNF_T;


/*****************************************************************************/
/*! device - netana_get_portstat request                              */
/*****************************************************************************/
typedef struct DEV_PORTSTAT_REQ_DATA_Ttag
{
 uint32_t ulPort;              /*!< port to get status from      */
 uint32_t ulSize;              /*!< size of Portstatus structure */

} DEV_PORTSTAT_REQ_DATA_T, *PDEV_PORTSTAT_REQ_DATA_T;

typedef struct DEV_PORTSTAT_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DEV_PORTSTAT_REQ_DATA_T         tData;
  
} DEV_PORTSTAT_REQ_T, *PDEV_PORTSTAT_REQ_T;


/*****************************************************************************/
/*! device - netana_get_portstat confirmation data                    */
/*****************************************************************************/
typedef struct DEV_PORTSTAT_CNF_DATA_Ttag
{
  NETANA_PORT_STATE_T tPortStat;            /*!< Port statistics structure       */
  
} DEV_PORTSTAT_CNF_DATA_T, *PINFO_DEV_CNF_DATA_T;

typedef struct DEV_PORTSTAT_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DEV_PORTSTAT_CNF_DATA_T         tData;
  
} DEV_PORTSTAT_CNF_T, *PDEV_PORTSTAT_CNF_T;

/*****************************************************************************/
/*! device - netana_get_state request                                        */
/*****************************************************************************/
typedef struct DEV_GETSTATE_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  
} DEV_GETSTATE_REQ_T, *PDEV_GETSTATE_REQ_T;



/*****************************************************************************/
/*! device - netana_get_state confirm data                       */
/*****************************************************************************/
typedef struct DEV_GETSTATE_CNF_DATA_Ttag
{
  uint32_t   ulCaptureState;	      /*< Returned capture state */
  uint32_t   ulCaptureError;	      /*< Returned capture error */

} DEV_GETSTATE_CNF_DATA_T, *PDEV_GETSTATE_CNF_DATA_T;
typedef struct DEV_GETSTATE_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DEV_GETSTATE_CNF_DATA_T         tData;
  
} DEV_GETSTATE_CNF_T, *PDEV_GETSTATE_CNF_T;



/*****************************************************************************/
/*! device - netana_access_phy_reg request data                          */
/*****************************************************************************/
typedef struct DEV_ACCESSPHYREG_REQ_DATA_Ttag
{
  uint32_t  ulDirection;	     /*< Read from PHY */
  unsigned char  bPhyNum; 	       /*< Phy / Port number (0..3)*/
  unsigned char  bPhyReg;          /*< Register to read / write (0..31)*/
  unsigned short usValue;	         /*< Write value if Direction is NETANA_PHY_DIRECTION_WRITE
                                       Returned value if Direction is NETANA_PHY_DIRECTION_READ  */
  unsigned short ulTimeout;	       /*< Timeout in ms to wait for access to complete */

} DEV_ACCESSPHYREG_REQ_DATA_T, *PDEV_ACCESSPHYREG_REQ_DATA_T;

/*****************************************************************************/
/*! device - netana_access_phy_reg request                                   */
/*****************************************************************************/
typedef struct DEV_ACCESSPHYREG_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;
  DEV_ACCESSPHYREG_REQ_DATA_T         tData;
} DEV_ACCESSPHYREG_REQ_T, *PDEV_ACCESSPHYREG_REQ_T;



/*****************************************************************************/
/*! device - netana_access_phy_reg confirm data                          */
/*****************************************************************************/
typedef struct DEV_ACCESSPHYREG_CNF_DATA_Ttag
{
  unsigned short usValue;	        /*< Write value if Direction is NETANA_PHY_DIRECTION_WRITE
                                   Returned value if Direction is NETANA_PHY_DIRECTION_READ  */
} DEV_ACCESSPHYREG_CNF_DATA_T, *PDEV_ACCESSPHYREG_CNF_DATA_T;

/*****************************************************************************/
/*! device - netana_access_phy_reg confirm                                   */
/*****************************************************************************/
typedef struct DEV_ACCESSPHYREG_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;
  DEV_ACCESSPHYREG_CNF_DATA_T         tData;
  
} DEV_ACCESSPHYREG_CNF_T, *PDEV_ACCESSPHYREG_CNF_T;





/*****************************************************************************/
/*! device - netana_get_packet request                                    */
/*****************************************************************************/
typedef struct DEV_GETPACKET_REQ_DATA_Ttag
{
  uint32_t ulSize;                                /*!< Mailbox size */
  uint32_t ulTimeout;                             /*!< Timeout */
} DEV_GETPACKET_REQ_DATA_T, *PDEV_GETPACKET_REQ_DATA_T;

typedef struct DEV_GETPACKET_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_GETPACKET_REQ_DATA_T        tData;
} DEV_GETPACKET_REQ_T, *PDEV_GETPACKET_REQ_T;


/*****************************************************************************/
/*! device - netana_get_packet confirm                                    */
/*****************************************************************************/
typedef struct DEV_GETPACKET_CNF_DATA_Ttag
{
  NETANA_PACKET  tRecvPkt;                                /*!< structure receive packet */
} DEV_GETPACKET_CNF_DATA_T, *PDEV_GETPACKET_CNF_DATA_T;

typedef struct DEV_GETPACKET_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_GETPACKET_CNF_DATA_T        tData;
} DEV_GETPACKET_CNF_T, *PDEV_GETPACKET_CNF_T;


/*****************************************************************************/
/*! device - netana_put_packet request                                    */
/*****************************************************************************/
typedef struct DEV_PUTPACKET_REQ_DATA_Ttag
{
  NETANA_PACKET   tSendPkt;              /*!< structure of send packet */
  uint32_t        ulTimeout;             /*!< Timeout */
} DEV_PUTPACKET_REQ_DATA_T, *PDEV_PUTPACKETE_REQ_DATA_T;

typedef struct DEV_PUTPACKET_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_PUTPACKET_REQ_DATA_T        tData;
} DEV_PUTPACKET_REQ_T, *PDEV_PUTPACKET_REQ_T;


/*****************************************************************************/
/*! device - netana_get_mbx_state request                                    */
/*****************************************************************************/
typedef struct DEV_MBXSTATE_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
} DEV_MBXSTATE_REQ_T, *PDEV_MBXSTATE_REQ_T;


/*****************************************************************************/
/*! device - netana_get_mbx_state confirm                                    */
/*****************************************************************************/
typedef struct DEV_MBXSTATE_CNF_DATA_Ttag
{
  uint32_t ulRecvPktCount;
  uint32_t ulSendPktCount;
} DEV_MBXSTATE_CNF_DATA_T, *PDEV_MBXSTATE_CNF_DATA_T;

typedef struct DEV_MBXSTATE_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_MBXSTATE_CNF_DATA_T        tData;
} DEV_MBXSTATE_CNF_T, *PDEV_MBXSTATE_CNF_T;




/*****************************************************************************/
/*! device - netana_get_gpio_mode request                                    */
/*****************************************************************************/
typedef struct DEV_GETGPIOMODE_REQ_DATA_Ttag
{
  uint32_t ulGPIO;                                /*!< Number of the GPIO*/

} DEV_GETGPIOMODE_REQ_DATA_T, *PDEV_GETGPIOMODE_REQ_DATA_T;

typedef struct DEV_GETGPIOMODE_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_GETGPIOMODE_REQ_DATA_T        tData;

} DEV_GETGPIOMODE_REQ_T, *PDEV_GETGPIOMODE_REQ_T;



/*****************************************************************************/
/*! device - netana_get_gpio_mode confirm                                    */
/*****************************************************************************/
typedef struct DEV_GETGPIOMODE_CNF_DATA_Ttag
{
  NETANA_GPIO_MODE_T tMode;                                /*!< structure of configuration*/

} DEV_GETGPIOMODE_CNF_DATA_T, *PDEV_GETGPIOMODE_CNF_DATA_T;

typedef struct DEV_GETGPIOMODE_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_GETGPIOMODE_CNF_DATA_T        tData;

} DEV_GETGPIOMODE_CNF_T, *PDEV_GETGPIOMODE_CNF_T;



/*****************************************************************************/
/*! device - netana_set_gpio_mode request                                    */
/*****************************************************************************/
typedef struct DEV_SETGPIOMODE_REQ_DATA_Ttag
{
  uint32_t       ulGPIO;                                /*!< Number of the GPIO    */
  NETANA_GPIO_MODE_T  tMode;                                 /*!< structure of configuration*/

} DEV_SETGPIOMODE_REQ_DATA_T, *PDEV_SETGPIOMODE_REQ_DATA_T;

typedef struct DEV_SETGPIOMODE_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_SETGPIOMODE_REQ_DATA_T        tData;

} DEV_SETGPIOMODE_REQ_T, *PDEV_SETGPIOMODE_REQ_T;


/*****************************************************************************/
/*! device - netana_set_gpio_output request                                    */
/*****************************************************************************/
typedef struct DEV_SETGPIOOUTPUT_REQ_DATA_Ttag
{
  uint32_t ulGPIO;      /*!< Number of the GPIO    */
  uint32_t ulLevel;     /*!< Level */
} DEV_SETGPIOOUTPUT_REQ_DATA_T, *PDEV_SETGPIOOUTPUT_REQ_DATA_T;

typedef struct DEV_SETGPIOOUTPUT_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_SETGPIOOUTPUT_REQ_DATA_T        tData;

} DEV_SETGPIOOUTPUT_REQ_T, *PDEV_SETGPIOOUTPUT_REQ_T;


/*****************************************************************************/
/*! device - netana_set_gpio_voltage request                                    */
/*****************************************************************************/
typedef struct DEV_SETGPIOVOLTAGE_REQ_DATA_Ttag
{
  uint32_t ulGpioSelMsk;
  uint32_t ulGpioVoltageSel;

} DEV_SETGPIOVOLTAGE_REQ_DATA_T, *PDEV_SETGPIOVOLTAGE_REQ_DATA_T;

typedef struct DEV_SETGPIOVOLTAGE_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_SETGPIOVOLTAGE_REQ_DATA_T        tData;

} DEV_SETGPIOVOLTAGE_REQ_T, *PDEV_SETGPIOVOLTAGE_REQ_T;


/*****************************************************************************/
/*! device - netana_get_gpio_voltage request                                 */
/*****************************************************************************/
typedef struct DEV_GETGPIOVOLTAGE_REQ_DATA_Ttag
{                   
  uint32_t ulGpio;

} DEV_GETGPIOVOLTAGE_REQ_DATA_T, *PDEV_GETGPIOVOLTAGE_REQ_DATA_T;

typedef struct DEV_GETGPIOVOLTAGE_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_GETGPIOVOLTAGE_REQ_DATA_T        tData;

} DEV_GETGPIOVOLTAGE_REQ_T, *PDEV_GETGPIOVOLTAGE_REQ_T;

/*****************************************************************************/
/*! device - netana_get_gpio_voltage confirm                                    */
/*****************************************************************************/
typedef struct DEV_GETGPIOVOLTAGE_CNF_DATA_Ttag
{
  uint32_t ulGpioVoltageSel;                                /*!< structure of configuration*/

} DEV_GETGPIOVOLTAGE_CNF_DATA_T, *PDEV_GETGPIOVOLTAGE_CNF_DATA_T;

typedef struct DEV_GETGPIOVOLTAGE_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_GETGPIOVOLTAGE_CNF_DATA_T        tData;

} DEV_GETGPIOVOLTAGE_CNF_T, *PDEV_GETGPIOVOLTAGE_CNF_T;



/*****************************************************************************/
/*! device - netana_get_filter request data                     */
/*****************************************************************************/
typedef struct DEV_GETFILTER_REQ_DATA_Ttag
{
  uint32_t ulPort ;           /*<Ethernet portfilter number */
} DEV_GETFILTER_REQ_DATA_T, *PDEV_GETFILTER_REQ_DATA_T;

/*****************************************************************************/
/*! device - netana_get_filter request                          */
/*****************************************************************************/
typedef struct DEV_GETFILTER_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_GETFILTER_REQ_DATA_T          tData;

} DEV_GETFILTER_REQ_T, *PDEV_GETFILTER_REQ_T;

/*****************************************************************************/
/*! device - netana_get_filter confirm data                     */
/*****************************************************************************/
typedef struct DEV_GETFILTER_CNF_DATA_Ttag
{
  uint32_t ulFilterSizeA ;        /*<filter A */
  uint32_t ulFilterSizeB ;        /*<filter B */
  //NETANA_FILTER_T tFilterA ;           /*<filter A*/
  //NETANA_FILTER_T tFilterB ;           /*<filter B */
  uint32_t ulRelationShip;        /*<relationship of both filters (bitmask) */
  /*
  MaskA [ulFilterSizeA] // dynamically added to send frame
  ValueA[ulFilterSizeA] 
  MaskB [ulFilterSizeB]
  ValueB[ulFilterSizeB] 
  */

} DEV_GETFILTER_CNF_DATA_T, *PDEV_GETFILTER_CNF_DATA_T;

/*****************************************************************************/
/*! device - netana_get_filter confirm                         */
/*****************************************************************************/
typedef struct DEV_GETFILTER_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_GETFILTER_CNF_DATA_T          tData;

} DEV_GETFILTER_CNF_T, *PDEV_GETFILTER_CNF_T;



/*****************************************************************************/
/*! device - netana_set_filter request data                     */
/*****************************************************************************/
typedef struct DEV_SETFILTER_REQ_DATA_Ttag
{
  uint32_t ulPort ;               /*<Ethernet portfilter number */
  uint32_t ulFilterSizeA ;        /*<filter A */
  uint32_t ulFilterSizeB ;        /*<filter B */
  uint32_t ulRelationShip;        /*<relationship of both filters (bitmask) */
  /* 
  MaskA [ulFilterSizeA] // dynamically added to send frame
  ValueA[ulFilterSizeA] 
  MaskB [ulFilterSizeB]
  ValueB[ulFilterSizeB] 
  */
} DEV_SETFILTER_REQ_DATA_T, *PDEV_SETFILTER_REQ_DATA_T;

/*****************************************************************************/
/*! device - netana_set_filter request                          */
/*****************************************************************************/
typedef struct DEV_SETFILTER_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_SETFILTER_REQ_DATA_T          tData;

} DEV_SETFILTER_REQ_T, *PDEV_SETFILTER_REQ_T;


/*****************************************************************************/
/*! device - netana_file_info request data                     */
/*****************************************************************************/
typedef struct DEV_FILEINFO_REQ_DATA_Ttag
{
  uint32_t ulFileInfoSize ;           /*< Size of the passed structure in tFileInfo */

} DEV_FILEINFO_REQ_DATA_T, *PDEV_FILEINFO_REQ_DATA_T;

/*****************************************************************************/
/*! device - netana_file_info request                                        */
/*****************************************************************************/
typedef struct DEV_FILEINFO_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_FILEINFO_REQ_DATA_T           tData;

} DEV_FILEINFO_REQ_T, *PDEV_FILEINFO_REQ_T;

/*****************************************************************************/
/*! device - netana_file_info confirm data                                   */
/*****************************************************************************/
typedef struct DEV_FILEINFO_CNF_DATA_Ttag
{
  NETANA_FILE_INFORMATION_T tFileInfo;	           /*<	Returned File information */

} DEV_FILEINFO_CNF_DATA_T, *PDEV_FILEINFO_CNF_DATA_T;

/*****************************************************************************/
/*! device - netana_file_info confirm                                        */
/*****************************************************************************/
typedef struct DEV_FILEINFO_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_FILEINFO_CNF_DATA_T          tData;

} DEV_FILEINFO_CNF_T, *PDEV_FILEINFO_CNF_T;


/*****************************************************************************/
/*! device - netana_set_device_ident request                                 */
/*****************************************************************************/
typedef  struct DEV_FILE_DOWNLOAD_REQ_DATA_Ttag
{
  uint32_t                            ulMaxBlockSize;                               /* maximum possible download size by requestor */
  uint32_t                            ulFileLength;                                 /* file size to download */
  uint16_t                           usFileNameLength;                             /* length of NUL-terminated file name that will follow */
  char                                     szFullFileName[NETANA_FULL_PATH_NAME_LENGTH]; /* a NUL-terminated file name will follow here */
} DEV_FILE_DOWNLOAD_REQ_DATA_T;

typedef struct DEV_FILE_DOWNLOAD_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;                  /* packet header */
  DEV_FILE_DOWNLOAD_REQ_DATA_T             tData;                  /* packet data */
} DEV_FILE_DOWNLOAD_REQ_T, *PDEV_FILE_DOWNLOAD_REQ_T;

 
/*****************************************************************************/
/*! device - netana_set_device_ident confirm                                 */
/*****************************************************************************/
typedef  struct DEV_FILE_DOWNLOAD_CNF_DATA_Ttag
{
  uint32_t                             ulMaxBlockSize;         /* download block size selected */
}  DEV_FILE_DOWNLOAD_CNF_DATA_T;

typedef  struct DEV_FILE_DOWNLOAD_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
  DEV_FILE_DOWNLOAD_CNF_DATA_T              tData;                  /* packet data */
} DEV_FILE_DOWNLOAD_CNF_T, *PDEV_FILE_DOWNLOAD_CNF_T; 

/******************************************************************************
 * Packet: RCX_FILE_DOWNLOAD_DATA_REQ/RCX_FILE_DOWNLOAD_DATA_CNF
 *
 *          This packet transfers the file data of a previously successful DEV_FILE_DOWNLOAD_CNF_DATA_Ttag
 */
/***** request packet *****/

typedef struct DEV_FILE_DOWNLOAD_DATA_REQ_DATA_Ttag
{
  uint32_t                             ulBlockNo;              /* block number */
  /* data block follows here */
} DEV_FILE_DOWNLOAD_DATA_REQ_DATA_T;

typedef struct DEV_FILE_DOWNLOAD_DATA_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
  DEV_FILE_DOWNLOAD_DATA_REQ_DATA_T         tData;                  /* packet data */
} DEV_FILE_DOWNLOAD_DATA_REQ_T, *PDEV_FILE_DOWNLOAD_DATA_REQ_T;

/***** confirmation packet *****/
typedef  struct DEV_FILE_DOWNLOAD_DATA_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
}  DEV_FILE_DOWNLOAD_DATA_CNF_T, *PDEV_FILE_DOWNLOAD_DATA_CNF_T;


/******************************************************************************
 * Packet: RCX_FILE_DOWNLOAD_ABORT_REQ/RCX_FILE_DOWNLOAD_ABORT_CNF
 *
 *          This packet aborts a currently running file download
 */
/***** request packet *****/
typedef  struct DEV_FILE_DOWNLOAD_ABORT_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
} DEV_FILE_DOWNLOAD_ABORT_REQ_T, *PDEV_FILE_DOWNLOAD_ABORT_REQ_T;

/***** confirmation packet *****/
typedef struct DEV_FILE_DOWNLOAD_ABORT_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
} DEV_FILE_DOWNLOAD_ABORT_CNF_T, *PDEV_FILE_DOWNLOAD_ABORT_CNF_T;


/*****************************************************************************/
/*! device - netana_get_device_ident request                                 */
/*****************************************************************************/
typedef struct DEV_GET_DEVICE_IDENT_REQ_DATA_Ttag
{
  uint32_t         ulDevIdentInfoSize;
} DEV_GET_DEVICE_IDENT_REQ_DATA_T;

typedef struct DEV_GET_DEVICE_IDENT_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
  DEV_GET_DEVICE_IDENT_REQ_DATA_T           tData; 
} DEV_GET_DEVICE_IDENT_REQ_T, *PDEV_GET_DEVICE_IDENT_REQ_T;

/*****************************************************************************/
/*! device - netana_get_device_ident confirm                                 */
/*****************************************************************************/
typedef struct DEV_GET_DEVICE_IDENT_CNF_DATA_Ttag
{
  NETANA_DEVICE_IDENT_T ptIdentInfo;
} DEV_GET_DEVICE_IDENT_CNF_DATA_T;

typedef struct DEV_GET_DEVICE_IDENT_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
  DEV_GET_DEVICE_IDENT_CNF_DATA_T           tData; 
} DEV_GET_DEVICE_IDENT_CNF_T, *PDEV_GET_DEVICE_IDENT_CNF_T;


/*****************************************************************************/
/*! device - netana_check_device_ident request                               */
/*****************************************************************************/
typedef struct DEV_CHECK_DEVICE_IDENT_REQ_DATA_Ttag
{
  uint32_t ulDevIdentInfoSize;
} DEV_CHECK_DEVICE_IDENT_REQ_DATA_T;

typedef struct DEV_CHECK_DEVICE_IDENT_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
  DEV_CHECK_DEVICE_IDENT_REQ_DATA_T         tData; 
} DEV_CHECK_DEVICE_IDENT_REQ_T, *PDEV_CHECK_DEVICE_IDENT_REQ_T;



/*****************************************************************************/
/*! device - netana_check_device_ident confirm                               */
/*****************************************************************************/

typedef struct DEV_CHECK_DEVICE_IDENT_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T     tHeader;                  /* packet header */
  /* transmitt data of requested size from 
  DEV_CHECK_DEVICE_IDENT_REQ_DATA_T.ulDevIdentInfoSize */
} DEV_CHECK_DEVICE_IDENT_CNF_T, *PDEV_CHECK_DEVICE_IDENT_CNF_T;


/*****************************************************************************/
/*! device - netana_start_capture request data                     */
/*****************************************************************************/
#pragma pack(1) //needet for the 64 bit value to leave no gab between the surrounding 32 bit values 
typedef  struct DEV_STARTCAPTURE_REQ_DATA_Ttag
{

  uint32_t ulCaptureMode;	          /*<Capture mode */
  uint32_t ulPortEnableMask;         /*<Bitmask of enabled Ethernet ports. Each bit represents a port. */
  uint32_t ulMacMode;                /*<Mac mode */
  uint64_t ullReferenceTime;	  /*< Capture reference time in nanoseconds. */
  uint32_t fnStatus;	                /*<	No Statuscallback if NULL  */
  uint32_t fnData;	                  /*< No DataCallback if NULL */

} DEV_STARTCAPTURE_REQ_DATA_T, *PDEV_STARTCAPTURE_REQ_DATA_T;
#pragma pack()
/*****************************************************************************/
/*! device - netana_start_capture request                                        */
/*****************************************************************************/
typedef struct DEV_STARTCAPTURE_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_STARTCAPTURE_REQ_DATA_T       tData;

} DEV_STARTCAPTURE_REQ_T, *PDEV_STARTCAPTURE_REQ_T;


/*****************************************************************************/
/*! device - netana_start_capture confirm data                     */
/*****************************************************************************/

typedef struct DEV_STARTCAPTURE_CNF_DATA_Ttag
{
  uint32_t ulHandle;	          /*<Handle of Callback Object */

} DEV_STARTCAPTURE_CNF_DATA_T, *PDEV_STARTCAPTURE_CNF_DATA_T;

/*****************************************************************************/
/*! device - netana_start_capture confirm                                        */
/*****************************************************************************/
typedef struct DEV_STARTCAPTURE_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_STARTCAPTURE_CNF_DATA_T       tData;

} DEV_STARTCAPTURE_CNF_T, *PDEV_STARTCAPTURE_CNF_T;


/*****************************************************************************/
/*! Device - netana_resync_time request Data                                 */
/*****************************************************************************/
#pragma pack(1) //needet for the 64 bit value to leave no gab between the surrounding 32 bit values 
typedef struct DEV_RESYNCTIME_REQ_DATA_Ttag
{
  uint64_t ullReferenceTime;    /*!< Capture reference time in nanoseconds. */
} DEV_RESYNCTIME_REQ_DATA_T, *PDEV_RESYNCTIME_REQ_DATA_T;
#pragma pack()

/*****************************************************************************/
/*! Device - netana_resync_time request                                      */
/*****************************************************************************/
typedef struct DEV_RESYNC_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  DEV_RESYNCTIME_REQ_DATA_T         tData;
  
} DEV_RESYNCTIME_REQ_T, *PDEV_RESYNCTIME_REQ_T;


/*****************************************************************************/
/*! device - netanaMa_config_pi_controller reqest data                     */
/*****************************************************************************/

typedef struct DEV_CONFIGPICTRL_REQ_DATA_Ttag
{
  uint32_t ulP;            /*!< Proportional part */
  uint32_t ulI;            /*!< Integral part */
} DEV_CONFIGPICTRL_REQ_DATA_T, *PDEV_CONFIGPICTRL_REQ_DATA_T;

/*****************************************************************************/
/*! device - netanaMa_config_pi_controller request                                        */
/*****************************************************************************/
typedef struct DEV_CONFIGPICTRL_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_CONFIGPICTRL_REQ_DATA_T       tData;
} DEV_CONFIGPICTRL_REQ_T, *PDEV_CONFIGPICTRL_REQ_T;


/*****************************************************************************/
/*! device - netanaMa_signal_driver_error reqest data                     */
/*****************************************************************************/
typedef struct DEV_SIGNAL_DRIVER_ERROR_REQ_DATA_Ttag
{
  uint32_t ulError;          
} DEV_SIGNAL_DRIVER_ERROR_REQ_DATA_T, *PDEV_SIGNAL_DRIVER_ERROR_REQ_DATA_T;

/*****************************************************************************/
/*! device - netanaMa_signal_driver_error request                                        */
/*****************************************************************************/
typedef struct DEV_SIGNAL_DRIVER_ERROR_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  DEV_SIGNAL_DRIVER_ERROR_REQ_DATA_T       tData;
} DEV_SIGNAL_DRIVER_ERROR_REQ_T, *PDEV_SIGNAL_DRIVER_ERROR_REQ_T;


/*****************************************************************************
  _____      _ _ _                _    
 / ____|    | | | |              | |   
| |     __ _| | | |__   __ _  ___| | __
| |    / _` | | | '_ \ / _` |/ __| |/ /
| |___| (_| | | | |_) | (_| | (__|   < 
 \_____\__,_|_|_|_.__/ \__,_|\___|_|\_\
  ___    _       _                 _   
 / _ \  | |__   (_)   ___    ___  | |_ 
| | | | | '_ \  | |  / _ \  / __| | __|
| |_| | | |_) | | | |  __/ | (__  | |_ 
 \___/  |_.__/ _/ |  \___|  \___|  \__|
              |__/                     
******************************************************************************/

/*****************************************************************************/
/*!	Callback - PFN_STATUS_CALLBACK request                                          */
/*****************************************************************************/
typedef struct CALLBACK_STATUS_REQ_DATA_Ttag
{
  uint32_t ulCaptureState;         /*!< State of Capturing */
  uint32_t ulCaptureError;         /*!< Error indication of firmware */
  
} CALLBACK_STATUS_REQ_DATA_T, *PCALLBACK_STATUS_REQ_DATA_T;

typedef struct CALLBACK_STATUS_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T    tHeader;
  CALLBACK_STATUS_REQ_DATA_T        tData;
  
} CALLBACK_STATUS_REQ_T, *PCALLBACK_STATUS_REQ_T;

/*****************************************************************************/
/*! Callback - PFN_DATA_CALLBACK request                                           */
/*****************************************************************************/
typedef struct CALLBACK_DATA_REQ_DATA_Ttag
{
  uint32_t           ulDataLen;       /*!< Size of the data-in buffer */
  NETANA_FRAME_HEADER_T   tData;           /*!< Captured data*/

} CALLBACK_DATA_REQ_DATA_T, *PCALLBACK_DATA_REQ_DATA_T;

typedef struct CALLBACK_DATA_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T   tHeader;
  CALLBACK_DATA_REQ_DATA_T         tData;
  
} CALLBACK_DATA_REQ_T, *PCALLBACK_DATA_REQ_T;





/***************************************************************************************
 *  __  __                                                   _
 * |  \/  |                                                 | |
 * | \  / | __ _ _ __   __ _  __ _  ___ _ __ ___   ___ _ __ | |_
 * | |\/| |/ _` | '_ \ / _` |/ _` |/ _ \ '_ ` _ \ / _ \ '_ \| __|
 * | |  | | (_| | | | | (_| | (_| |  __/ | | | | |  __/ | | | |_
 * |_|  |_|\__,_|_| |_|\__,_|\__, |\___|_| |_| |_|\___|_| |_|\__|
 *                            __/ |
 *                           |___/
 ****************************************************************************************/



/*****************************************************************************/
/*! Management- netana_mngmt_exec_cmd (BLINK)  request                       */
/*****************************************************************************/
typedef struct MNG_BLINK_REQ_DATA_Ttag
{
  uint8_t       szDevice[NETANA_MAX_DEVICENAMESIZE];
  uint32_t      ulSize;
  
} MNG_BLINK_REQ_DATA_T, *PMNG_BLINK_REQ_DATA_T;

typedef struct MNG_BLINK_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  MNG_BLINK_REQ_DATA_T   tData;
} MNG_BLINK_REQ_T, *PMNG_BLINK_REQ_T;


/*****************************************************************************/
/*! Management- netana_mngmt_exec_cmd (DEVICE_CLASS)  request                       */
/*****************************************************************************/
typedef struct MNG_DEVCLASSS_REQ_DATA_Ttag
{
  uint8_t       szDevice;
  uint32_t      ulSize;
} MNG_DEVCLASS_REQ_DATA_T, *PMNG_DEVCLASS_REQ_DATA_T;

typedef struct MNG_DEVCLASS_REQ_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  MNG_DEVCLASS_REQ_DATA_T   tData;
} MNG_DEVCLASS_REQ_T, *PMNG_DEVCLASS_REQ_T;


/*****************************************************************************/
/*! Management- netana_mngmt_exec_cmd (GET_DEV_FEATURE)  confirm                       */
/*****************************************************************************/
typedef struct MNG_FEATURE_CNF_DATA_Ttag
{
  NETANA_MNGMT_GET_DEV_FEATURE_OUT_T tOut;
} MNG_FEATURE_CNF_DATA_T, *PMNG_FEATURE_CNF_DATA_T;

typedef struct MNG_FEATURE_CNF_Ttag
{
  NETANA_MARSHALLER_DATA_FRAME_HEADER_T  tHeader;
  MNG_FEATURE_CNF_DATA_T   tData;
} MNG_FEATURE_CNF_T, *PMNG_FEATURE_CNF_T;


#endif//__NETANA_MARSHALLERFRAME__H
