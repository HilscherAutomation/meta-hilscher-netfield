/**************************************************************************************
 
   Copyright (c) Hilscher GmbH. All Rights Reserved.
 
 **************************************************************************************
 
   Filename:
    $Workfile: OS_netANAModul.h $
   Last Modification:
    $Author: sebastiand $
    $Modtime: $
    $Revision: 1776 $
   
   Targets:
     Win32/ANSI   : yes
     Win32/Unicode: yes (define _UNICODE)
     WinCE        : yes
 
   Description:
    netANA function pointers for netANA marshalling module
       
   Changes:
 
     Version   Date        Author   Description
     ----------------------------------------------------------------------------------
     2         25.06.2010  SD       Change:
                                     - changed types of driver functions (for 64-bit support)
     1         25.05.2009  PL       intitial version
 
**************************************************************************************/

#ifndef __netANAAPI_WRAPPPER__H
#define __netANAAPI_WRAPPPER__H

/*****************************************************************************/
/*! \file netANAAPI_Wrapper.h
*   netANA function pointers for netANA marshalling module                       */
/*****************************************************************************/

#ifdef __cplusplus
  extern "C" {
#endif

#include "../SDK/netana_user.h"
#include <netana/libnetana.h> // "/usr/local/include/netana/libnetana.h"

#define NETANA_API_NAME         "netANALYZER_API.dll"
#define NETANA_LIC_PATH_NAME 		"/lib/firmware/netanalyzer/lic.nxl"
#define NETANA_FILE_NAME_LENGTH    256    /*!< Maximum length of file name */

/*****************************************************************************/
/*! \addtogroup NETX_MARSHALLER_netANA
*   \{                                                                       */
/*****************************************************************************/


typedef int32_t(APIENTRY *PFN_netana_driver_information   )(uint32_t ulDrvInfoSize, NETANA_DRIVER_INFORMATION_T* ptDrvInfo);
typedef int32_t(APIENTRY *PFN_netana_enum_device          )(uint32_t ulCardNr, uint32_t ulDevInfoSize, NETANA_DEVICE_INFORMATION_T* ptDevInfo);
typedef int32_t(APIENTRY *PFN_netana_open_device          )(char* szDevice, NETANA_HANDLE* phDev);
typedef int32_t(APIENTRY *PFN_netana_start_capture        )(NETANA_HANDLE hDev,             uint32_t ulCaptureMode, 
                                                            uint32_t ulPortEnableMask,      uint32_t ulMacMode, 
                                                            uint64_t ullReferenceTime,      PFN_STATUS_CALLBACK pfnStatus,  
                                                            PFN_DATA_CALLBACK pfnData,      void* pvUser);
typedef int32_t(APIENTRY *PFN_netana_stop_capture         )(NETANA_HANDLE hDev);
typedef int32_t(APIENTRY *PFN_netana_close_device         )(NETANA_HANDLE hDev);
typedef int32_t(APIENTRY *PFN_netana_get_error_description)(int32_t iError, uint32_t ulBufferSize, char* szBuffer);
typedef int32_t(APIENTRY *PFN_netana_device_info          )(NETANA_HANDLE hDev, uint32_t ulDevInfoSize, NETANA_DEVICE_INFORMATION_T* ptDevInfo);
typedef int32_t(APIENTRY *PFN_netana_get_portstat         )(NETANA_HANDLE hDev, uint32_t ulPort, uint32_t ulSize, NETANA_PORT_STATE_T* ptStatus);
typedef int32_t(APIENTRY *PFN_netana_get_state            )(NETANA_HANDLE hDev, uint32_t* pulCaptureState, uint32_t* pulCaptureError);
typedef int32_t(APIENTRY *PFN_netana_access_phy_reg       )(NETANA_HANDLE hDev, uint32_t ulDirection, 
                                                            uint8_t bPhyNum,    uint8_t bPhyReg,  
                                                            uint16_t* pusValue, uint32_t ulTimeout);
typedef int32_t(APIENTRY *PFN_netana_get_gpio_mode        )(NETANA_HANDLE hDev, uint32_t ulGpio, NETANA_GPIO_MODE_T* ptMode);
typedef int32_t(APIENTRY *PFN_netana_set_gpio_mode        )(NETANA_HANDLE hDev, uint32_t ulGpio, NETANA_GPIO_MODE_T* ptMode);
typedef int32_t(APIENTRY *PFN_netana_get_filter           )(NETANA_HANDLE hDev, uint32_t ulPort, 
                                                            NETANA_FILTER_T* ptFilterA, NETANA_FILTER_T* ptFilterB, 
                                                            uint32_t* pulRelationShip);
typedef int32_t(APIENTRY *PFN_netana_set_filter           )(NETANA_HANDLE hDev, uint32_t ulPort, 
                                                            NETANA_FILTER_T* ptFilterA, NETANA_FILTER_T* ptFilterB, 
                                                            uint32_t ulRelationShip);
typedef int32_t(APIENTRY *PFN_netana_set_gpio_output      )(NETANA_HANDLE hDev, uint32_t ulGpio, uint32_t ulLevel);
typedef int32_t(APIENTRY *PFN_netana_resync_time          )(NETANA_HANDLE hDev, uint64_t ullReferenceTime);
typedef int32_t(APIENTRY *PFN_netana_config_pi_controller )(NETANA_HANDLE hDev, uint32_t ulP, uint32_t ulI);

typedef int32_t(APIENTRY *PFN_netana_mngmt_exec_cmd       )( uint32_t ulCommandId,
                                                             void*  ptInputParameter,  uint32_t ulInputParameterSize,
                                                             void*  ptOutputParameter, uint32_t ulOutputParameterSize);
typedef int32_t (APIENTRY *PFN_netana_set_gpio_voltage    )(NETANA_HANDLE hDev, uint32_t ulGpioSelMsk, uint32_t ulGpioVoltageSel);
typedef int32_t (APIENTRY *PFN_netana_get_gpio_voltage    )(NETANA_HANDLE hDev, uint32_t ulGpio, uint32_t* pulGpioVoltageSel);
typedef int32_t (APIENTRY *PFN_netana_set_device_ident    )(NETANA_HANDLE hDev, char* szFileName);
typedef int32_t (APIENTRY *PFN_netana_get_device_ident    )(NETANA_HANDLE hDev, uint32_t ulDevIdentInfoSize, NETANA_DEVICE_IDENT_T *ptIdentInfo);
typedef int32_t (APIENTRY *PFN_netana_check_device_ident  )(NETANA_HANDLE hDev, uint32_t ulDevIdentInfoSize, uint8_t* pbDevIdentInfo);
typedef int32_t (APIENTRY *PFN_netana_signal_driver_error )(NETANA_HANDLE hDev, uint32_t ulError);

typedef int32_t(APIENTRY *PFN_netana_get_packet           )(NETANA_HANDLE hDev, uint32_t ulSize, NETANA_PACKET* ptRecvPkt, uint32_t ulTimeout);
typedef int32_t(APIENTRY *PFN_netana_put_packet           )(NETANA_HANDLE hDev, NETANA_PACKET*  ptSendPkt, uint32_t ulTimeout);
typedef int32_t(APIENTRY *PFN_netana_get_mbx_state        )(NETANA_HANDLE hDev, uint32_t* pulRecvPktCount, uint32_t* pulSendPktCount);


typedef struct DRIVER_FUNCTIONStag
{
  PFN_netana_driver_information     pfn_netana_driver_information;
  PFN_netana_enum_device            pfn_netana_enum_device;
  PFN_netana_open_device            pfn_netana_open_device; 
  PFN_netana_start_capture          pfn_netana_start_capture; 
  PFN_netana_stop_capture           pfn_netana_stop_capture;     
  PFN_netana_close_device           pfn_netana_close_device;   
  PFN_netana_get_error_description  pfn_netana_get_error_description;
  PFN_netana_device_info            pfn_netana_device_info;
  PFN_netana_get_portstat           pfn_netana_get_portstat;
  PFN_netana_get_state              pfn_netana_get_state;
  PFN_netana_access_phy_reg         pfn_netana_access_phy_reg;
  PFN_netana_get_gpio_mode          pfn_netana_get_gpio_mode;
  PFN_netana_set_gpio_mode          pfn_netana_set_gpio_mode;
  PFN_netana_get_filter             pfn_netana_get_filter;
  PFN_netana_set_filter             pfn_netana_set_filter;
  PFN_netana_set_gpio_output        pfn_netana_set_gpio_output;
  PFN_netana_resync_time            pfn_netana_resync_time;
  PFN_netana_config_pi_controller   pfn_netana_config_pi_controller;
  PFN_netana_mngmt_exec_cmd         pfn_netana_mngmt_exec_cmd;
  PFN_netana_set_gpio_voltage       pfn_netana_set_gpio_voltage;
  PFN_netana_get_gpio_voltage       pfn_netana_get_gpio_voltage;
  PFN_netana_set_device_ident       pfn_netana_set_device_ident;
  PFN_netana_get_device_ident       pfn_netana_get_device_ident;
  PFN_netana_check_device_ident     pfn_netana_check_device_ident;
  PFN_netana_signal_driver_error    pfn_netana_signal_driver_error;
  PFN_netana_get_packet             pfn_netana_get_packet;
  PFN_netana_put_packet             pfn_netana_put_packet;
  PFN_netana_get_mbx_state          pfn_netana_get_mbx_state;
} DRIVER_FUNCTIONS, *PDRIVER_FUNCTIONS;

typedef struct NETX_ANALYZER_DLL_INFO_Ttag
{
  void*                                     hDll;                                                    /*!< DLL handle                                           */
  char*                                     szError;                                                 /*!< DLL load error                                       */
  char                                   		szFileName[NETANA_FILE_NAME_LENGTH];                     /*!< File name of the DLL                                 */
  DRIVER_FUNCTIONS                          tFncTable;                                               /*!< Function table                                       */
} NETX_ANALYZER_DLL_INFO_T, *PNETX_ANALYZER_DLL_INFO_T;

extern NETX_ANALYZER_DLL_INFO_T s_tAPIInfo;

#ifdef __cplusplus
  }
#endif

/*****************************************************************************/
/*! \}                                                                       */
/*****************************************************************************/

#endif /*  __netANAAPI_WRAPPPER__H */
