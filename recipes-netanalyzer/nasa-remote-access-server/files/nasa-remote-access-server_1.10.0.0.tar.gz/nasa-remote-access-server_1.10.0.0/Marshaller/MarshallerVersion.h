/******************************************************************************
  File          : MarshallerTask.h
-------------------------------------------------------------------------------
  Author        : Hilscher GmbH

  Copyright     : (c) 2009 Hilscher GmbH. All rights reserved.
                  Redistribution or use without without Hilscher's express
                  written permission is prohibited.

  Project       : netX Marshaller
-------------------------------------------------------------------------------
  Description   : Version information for netX Marshaller
-------------------------------------------------------------------------------
  Changes:

  Date         Author          Modification
  ----------   -------------   ------------------------------------------------
  2009-09-14   M. Streubel     Added MARSHALLER_VERSION_TEXT.
  2009-09-01   M. Streubel     Version change to 2.0.x.0.
  2009-07-28   M. Streubel     File created.
******************************************************************************/


#ifndef __MARSHALLER_VERSION_H
#define __MARSHALLER_VERSION_H



/*****************************************************************************/
/* Include Files Required                                                    */
/*****************************************************************************/


/* none */



/*****************************************************************************/
/* Symbol Definitions                                                        */
/*****************************************************************************/


#define NETANA_MARSHALLER_VERSION_MAJOR            1
#define NETANA_MARSHALLER_VERSION_MINOR            0
#define NETANA_MARSHALLER_VERSION_BUILD            0
#define NETANA_MARSHALLER_VERSION_REVISION         0
#define NETANA_MARSHALLER_VERSION_TEXT             "1.0.0.0"

#define NETANA_MARSHALLER_DATE_YEAR                2013
#define NETANA_MARSHALLER_DATE_MONTH               1
#define NETANA_MARSHALLER_DATE_DAY                 23



/*****************************************************************************/
/* Class, Type, and Structure Definitions                                    */
/*****************************************************************************/


/* none */


/*****************************************************************************/
/* Global Variables                                                          */
/*****************************************************************************/


/* none */



/*****************************************************************************/
/* Macros                                                                    */
/*****************************************************************************/


/* none */



/*****************************************************************************/
/* Functions                                                                 */
/*****************************************************************************/


/* none */



#endif /* __MARSHALLER_VERSION_H */
