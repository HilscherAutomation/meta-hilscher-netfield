/*
 * version.h
 *
 *  Created on: 23.10.2013
 *      Author: janadam
 */

#ifndef VERSION_H_
#define VERSION_H_

#define VERSION_MAJOR       1
#define VERSION_MINOR       10
#define VERSION_BUILD       0
#define VERSION_REVISION    0

#endif /* VERSION_H_ */
